<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/recipe-card.php';

$stmt = db()->query("SELECT id, title, slug, description, image_url, prep_time_minutes, cook_time_minutes, difficulty FROM recipes WHERE status='published' ORDER BY created_at DESC LIMIT 3");
$featured = $stmt->fetchAll();

$pageTitle = 'Cook with what you have';
require __DIR__ . '/includes/head.php';
?>
<div class="landing">
  <?php require __DIR__ . '/includes/public-nav.php'; ?>

  <section class="hero">
    <div class="hero-copy">
      <span class="badge badge-peach"><?= icon('sparkle', 15) ?> SMARTER MEALS, LESS WASTE</span>
      <h1>Cook with<br><em>what you have.</em></h1>
      <p>Turn the ingredients in your pantry into delicious possibilities, with smart matching that makes everyday cooking feel effortless.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url(is_logged_in() ? 'match.php' : 'login.php') ?>"><?= icon('sparkle', 18) ?><span>Find My Recipes</span></a>
        <a class="btn btn-secondary" href="<?= url('browse.php') ?>"><span>Explore Recipes</span> <?= icon('arrow', 17) ?></a>
      </div>
      <div class="hero-proof">
        <div class="mini-avatars"><span>M</span><span>J</span><span>L</span></div>
        <p><strong>2,400+ home cooks</strong><br>making more with less</p>
      </div>
    </div>
    <div class="hero-visual">
      <div class="image-frame">
        <img src="https://images.unsplash.com/photo-1601226809638-4ab838bb4d97?auto=format&fit=crop&w=1200&q=85" alt="A home cook preparing a warm meal">
        <div class="floating-card match-float">
          <div class="match-ring small-ring"><strong>94%</strong></div>
          <div><strong>Excellent match</strong><small>You have 5 of 6 ingredients</small></div>
        </div>
        <div class="floating-card pantry-float">
          <span class="round-icon"><?= icon('pantry') ?></span>
          <div><strong>Your pantry</strong><small>12 ingredients ready</small></div>
        </div>
      </div>
    </div>
  </section>

  <section class="feature-strip"><span>FROM PANTRY</span><?= icon('arrow') ?><span>TO PERFECT MATCH</span><?= icon('arrow') ?><span>TO DINNER</span></section>

  <section class="section features">
    <div class="section-heading">
      <span class="badge badge-peach">WHY PANTRYPAL</span>
      <h2>A little kitchen magic,<br>powered by what you already have.</h2>
    </div>
    <div class="feature-grid">
      <?php
      $features = [
          ['search', 'AI Recipe Matching', 'Find recipes that fit the ingredients already waiting in your pantry.'],
          ['sparkle', 'Smart Substitutions', "Get practical alternatives when you're missing just one thing."],
          ['heart', 'Personal Recommendations', 'Discover recipes shaped around your pantry and preferences.'],
          ['book', 'Adapted Instructions', 'Follow clear cooking steps adapted to the ingredients you choose.'],
      ];
      foreach ($features as $i => $f): ?>
        <article class="feature-card feature-<?= $i + 1 ?>">
          <span class="feature-number">0<?= $i + 1 ?></span>
          <span class="feature-icon"><?= icon($f[0]) ?></span>
          <h3><?= e($f[1]) ?></h3>
          <p><?= e($f[2]) ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="how" id="how">
    <div class="how-copy">
      <span class="badge badge-green">HOW IT WORKS</span>
      <h2>From pantry shelf<br>to dinner table.</h2>
      <p>PantryPal keeps the database matching simple, then uses focused AI to make your results more useful.</p>
      <a class="btn btn-primary" href="<?= url('register.php') ?>"><span>Start cooking smarter</span></a>
    </div>
    <div class="steps">
      <?php
      $steps = [
          ['01', 'Add your ingredients', 'Type a list or add pantry items one by one.'],
          ['02', 'We find database matches', 'PantryPal compares your ingredients to stored recipes.'],
          ['03', 'AI enhances your results', 'Get clear recommendations, reasons and substitutions.'],
          ['04', 'Choose, cook and enjoy', 'Follow adapted instructions and save your favorites.'],
      ];
      foreach ($steps as $s): ?>
        <div class="step"><span><?= e($s[0]) ?></span><div><h3><?= e($s[1]) ?></h3><p><?= e($s[2]) ?></p></div></div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="section featured">
    <div class="section-top">
      <div><span class="badge badge-peach">FRESH INSPIRATION</span><h2>Recipes for right now.</h2></div>
      <a class="btn btn-secondary" href="<?= url('browse.php') ?>"><span>Browse all recipes</span></a>
    </div>
    <div class="recipe-grid">
      <?php foreach ($featured as $r): render_recipe_card($r, false, false); endforeach; ?>
    </div>
  </section>

  <footer>
    <div class="logo"><span class="logo-mark"><?= icon('logo', 22) ?></span><span>PantryPal</span></div>
    <p>Turn what you have into something wonderful.</p>
    <div>
      <a href="#">About</a><a href="#">Contact</a><a href="#">Privacy</a>
      <a href="<?= url('login.php') ?>">Login</a>
    </div>
    <small>© 2026 PantryPal. A smarter way to cook.</small>
  </footer>
</div>
</body>
</html>
