<?php
require_once __DIR__ . '/config/bootstrap.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];

$stmt = db()->prepare('SELECT * FROM user_preferences WHERE user_id = ?');
$stmt->execute([$userId]);
$prefs = $stmt->fetch() ?: ['dietary_preference' => 'No preference', 'favorite_cuisine' => 'Asian-inspired', 'cooking_skill' => 'Intermediate'];

$errors = [];
$editing = isset($_GET['edit']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dietary = trim($_POST['dietary_preference'] ?? 'No preference');
    $cuisine = trim($_POST['favorite_cuisine'] ?? '');
    $skill = trim($_POST['cooking_skill'] ?? 'Intermediate');

    if ($fullName === '') {
        $errors['full_name'] = 'Full name is required.';
    }
    if (!validate_email($email)) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
        $stmt->execute([$email, $userId]);
        if ($stmt->fetch()) {
            $errors['email'] = 'That email is already in use by another account.';
        }
    }

    if (!$errors) {
        $stmt = db()->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?');
        $stmt->execute([$fullName, $email, $userId]);

        $stmt = db()->prepare(
            'INSERT INTO user_preferences (user_id, dietary_preference, favorite_cuisine, cooking_skill)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE dietary_preference = VALUES(dietary_preference), favorite_cuisine = VALUES(favorite_cuisine), cooking_skill = VALUES(cooking_skill)'
        );
        $stmt->execute([$userId, $dietary, $cuisine, $skill]);

        flash('success', 'Profile updated.');
        redirect(url('profile.php'));
    }

    $user = ['full_name' => $fullName, 'email' => $email] + $user;
    $prefs = ['dietary_preference' => $dietary, 'favorite_cuisine' => $cuisine, 'cooking_skill' => $skill];
    $editing = true;
}

$pageTitle = 'Your Profile';
$activeNav = 'profile';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ACCOUNT</span>
      <h1>Your Profile</h1>
      <p>Manage your personal details and cooking preferences.</p>
    </div>
  </div>

    <div class="profile-stack">
    <section class="profile-card">
      <div class="profile-head">
        <div class="avatar large"><?= e(first_letter($user['full_name'])) ?></div>
        <div><h2><?= e($user['full_name']) ?></h2><p><?= e($user['email']) ?></p><span class="badge badge-green">HOME COOK</span></div>
        <?php if (!$editing): ?>
          <a class="btn btn-secondary" href="<?= url('profile.php?edit=1') ?>"><?= icon('edit', 16) ?><span>Edit profile</span></a>
        <?php endif; ?>
      </div>

      <form method="post" action="<?= url('profile.php') ?>">
        <?= csrf_field() ?>
        <fieldset <?= $editing ? '' : 'disabled' ?> style="border:0;padding:0;margin:0;">
          <div class="form-grid">
            <label class="field <?= isset($errors['full_name']) ? 'has-error' : '' ?>">
              <span>Full name</span>
              <input type="text" name="full_name" value="<?= e($user['full_name']) ?>">
              <?php if (isset($errors['full_name'])): ?><small class="field-error"><?= e($errors['full_name']) ?></small><?php endif; ?>
            </label>
            <label class="field <?= isset($errors['email']) ? 'has-error' : '' ?>">
              <span>Email address</span>
              <input type="email" name="email" value="<?= e($user['email']) ?>">
              <?php if (isset($errors['email'])): ?><small class="field-error"><?= e($errors['email']) ?></small><?php endif; ?>
            </label>
            <label class="field">
              <span>Dietary preference</span>
              <select name="dietary_preference">
                <?php foreach (['No preference', 'Vegetarian', 'Vegan', 'Gluten-free', 'Dairy-free'] as $opt): ?>
                  <option value="<?= e($opt) ?>" <?= $prefs['dietary_preference'] === $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label class="field">
              <span>Favorite cuisine</span>
              <select name="favorite_cuisine">
                <?php foreach (['Asian-inspired', 'Italian-inspired', 'Filipino', 'American', 'Mexican', 'Mediterranean'] as $opt): ?>
                  <option value="<?= e($opt) ?>" <?= $prefs['favorite_cuisine'] === $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
            <label class="field">
              <span>Cooking skill</span>
              <select name="cooking_skill">
                <?php foreach (['Beginner', 'Intermediate', 'Advanced'] as $opt): ?>
                  <option value="<?= e($opt) ?>" <?= $prefs['cooking_skill'] === $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          </div>
        </fieldset>
        <?php if ($editing): ?>
          <div class="modal-actions">
            <a class="btn btn-secondary" href="<?= url('profile.php') ?>">Cancel</a>
            <button type="submit" class="btn btn-primary"><?= icon('check', 17) ?><span>Save changes</span></button>
          </div>
        <?php endif; ?>
      </form>
       </section>
  </div>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
