<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/recipe-card.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_require();
    $id = (int) ($_POST['id'] ?? 0);

    // Ownership check — only the author can delete their own recipe.
    $stmt = db()->prepare('DELETE FROM recipes WHERE id = ? AND created_by = ? AND is_community = 1');
    $stmt->execute([$id, $userId]);

    if ($stmt->rowCount() > 0) {
        flash('success', 'Recipe deleted.');
    } else {
        flash('error', 'Recipe not found or you do not have permission to delete it.');
    }
    redirect(url('my-recipes.php'));
}

$recipes = get_user_recipes($userId);
$publishedCount = count_user_recipes($userId, true);
$draftCount     = count_user_recipes($userId, false) - $publishedCount;

$pageTitle = 'My Recipes';
$activeNav = 'my-recipes';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">YOUR COLLECTION</span>
      <h1>My Recipes</h1>
      <p>Share your own Filipino dishes with the PantryPal community.</p>
    </div>
    <a class="btn btn-primary" href="<?= url('my-recipe-form.php') ?>">
      <?= icon('plus', 18) ?><span>New Recipe</span>
    </a>
  </div>

  <?php if (!$recipes): ?>
    <div class="empty-state" style="padding:5rem 1rem;">
      <span class="round-icon" style="width:4rem;height:4rem;margin:0 auto 1rem;"><?= icon('chef', 28) ?></span>
      <strong style="font-size:1.15rem;">You haven't added any recipes yet</strong>
      <p style="max-width:32rem;margin:.5rem auto 1.5rem;line-height:1.6;">
        Turn a family favorite into a PantryPal recipe. Your dishes will be
        matched against other users' pantries and appear in Browse Recipes
        once published.
      </p>
      <a class="btn btn-primary" href="<?= url('my-recipe-form.php') ?>">
        <?= icon('plus', 18) ?><span>Create your first recipe</span>
      </a>
    </div>
  <?php else: ?>

    <div class="stat-grid" style="margin-top:1.2rem; grid-template-columns: repeat(3, 1fr);">
      <article class="stat-card"><span class="stat-icon"><?= icon('book') ?></span><div><strong><?= count($recipes) ?></strong><p>Total recipes</p><small><?= $publishedCount ?> published</small></div></article>
      <article class="stat-card"><span class="stat-icon"><?= icon('check') ?></span><div><strong><?= $publishedCount ?></strong><p>Published</p><small>Visible to community</small></div></article>
      <article class="stat-card"><span class="stat-icon"><?= icon('edit') ?></span><div><strong><?= $draftCount ?></strong><p>Drafts</p><small>Only visible to you</small></div></article>
    </div>

    <div class="recipe-grid" style="margin-top:1.5rem;">
      <?php foreach ($recipes as $r): ?>
        <article class="recipe-card community-owner-card">
          <div class="recipe-image">
            <a href="<?= url('my-recipe-form.php?id=' . (int) $r['id']) ?>">
              <?php if (!empty($r['image_url'])): ?>
                <img src="<?= e($r['image_url']) ?>" alt="<?= e($r['title']) ?>">
              <?php else: ?>
                <div class="image-placeholder"><?= icon('chef', 48) ?></div>
              <?php endif; ?>
            </a>
            <span class="badge <?= $r['status'] === 'published' ? 'badge-green' : 'badge-neutral' ?>">
              <?= $r['status'] === 'published' ? 'PUBLISHED' : 'DRAFT' ?>
            </span>
          </div>
          <div class="recipe-body">
            <div class="recipe-title-row">
              <h3><?= e($r['title']) ?></h3>
              <?= icon('arrow', 18) ?>
            </div>
            <p><?= e(mb_strimwidth($r['description'] ?? '', 0, 110, '…')) ?></p>
            <div class="recipe-meta">
              <span><?= icon('timer', 17) ?><?= (int) $r['prep_time_minutes'] + (int) $r['cook_time_minutes'] ?> min</span>
              <span><?= icon('chef', 17) ?><?= e($r['difficulty']) ?></span>
            </div>
            <div class="owner-card-actions">
              <a class="btn btn-secondary" href="<?= url('my-recipe-form.php?id=' . (int) $r['id']) ?>">
                <?= icon('edit', 16) ?><span>Edit</span>
              </a>
              <form method="post" action="<?= url('my-recipes.php') ?>" data-confirm="Delete &quot;<?= e($r['title']) ?>&quot;? This cannot be undone." style="flex:1;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                <button type="submit" class="btn btn-danger full"><?= icon('trash', 16) ?><span>Delete</span></button>
              </form>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>