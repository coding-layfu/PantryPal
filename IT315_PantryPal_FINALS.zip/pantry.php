<?php
require_once __DIR__ . '/config/bootstrap.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];

$errors = [];
$editing = null;

// ---- Handle POST actions (add / update / delete) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = db()->prepare('DELETE FROM pantry_items WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);
        flash('success', 'Ingredient removed from your pantry.');
        redirect(url('pantry.php'));
    }

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $quantity = trim($_POST['quantity'] ?? '');
        $categoryId = (int) ($_POST['category_id'] ?? 0) ?: null;
        $expiresOn = trim($_POST['expires_on'] ?? '') ?: null;

        if ($name === '') {
            $errors['name'] = 'Please enter an ingredient name.';
        }

        if (!$errors) {
            // Try to link to a canonical ingredient by exact/partial name match, for better recipe matching.
            $ingredientId = null;
            $stmt = db()->prepare('SELECT id FROM ingredients WHERE name = ? LIMIT 1');
            $stmt->execute([$name]);
            $found = $stmt->fetch();
            if ($found) {
                $ingredientId = (int) $found['id'];
            }

            if ($id > 0) {
                $stmt = db()->prepare(
                    'UPDATE pantry_items SET custom_name = ?, quantity_text = ?, category_id = ?, expires_on = ?, ingredient_id = ?
                     WHERE id = ? AND user_id = ?'
                );
                $stmt->execute([$name, $quantity ?: null, $categoryId, $expiresOn, $ingredientId, $id, $userId]);
                flash('success', 'Ingredient updated.');
            } else {
                $stmt = db()->prepare(
                    'INSERT INTO pantry_items (user_id, ingredient_id, custom_name, quantity_text, category_id, expires_on)
                     VALUES (?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([$userId, $ingredientId, $name, $quantity ?: null, $categoryId, $expiresOn]);
                flash('success', 'Ingredient added to your pantry.');
            }
            redirect(url('pantry.php'));
        }
    }
}

// ---- Editing an existing item? ----
if (isset($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM pantry_items WHERE id = ? AND user_id = ?');
    $stmt->execute([(int) $_GET['edit'], $userId]);
    $editing = $stmt->fetch() ?: null;
}

// ---- Search / sort ----
$search = trim($_GET['q'] ?? '');
$categoryFilter = (int) ($_GET['category'] ?? 0);
$sort = $_GET['sort'] ?? 'recent';

$sql = 'SELECT p.*, c.name AS category_name FROM pantry_items p LEFT JOIN categories c ON c.id = p.category_id WHERE p.user_id = ?';
$params = [$userId];
if ($search !== '') {
    $sql .= ' AND p.custom_name LIKE ?';
    $params[] = '%' . $search . '%';
}
if ($categoryFilter > 0) {
    $sql .= ' AND p.category_id = ?';
    $params[] = $categoryFilter;
}
$sql .= match ($sort) {
    'expiry' => ' ORDER BY (p.expires_on IS NULL), p.expires_on ASC',
    'name' => ' ORDER BY p.custom_name ASC',
    default => ' ORDER BY p.created_at DESC',
};
$stmt = db()->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$ingredientCategories = db()->query("SELECT * FROM categories WHERE type = 'ingredient' ORDER BY name")->fetchAll();
$distinctCategoryCount = count(array_unique(array_filter(array_column($items, 'category_id'))));
$soonCount = count(array_filter($items, fn($i) => !empty($i['expires_on']) && strtotime($i['expires_on']) <= strtotime('+3 days')));

$pageTitle = 'My Pantry';
$activeNav = 'pantry';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">MY KITCHEN</span>
      <h1>My Pantry</h1>
      <p>Keep your ingredients organized and your recommendations fresh.</p>
    </div>
    <button type="button" class="btn btn-primary" onclick="document.getElementById('pantryForm').scrollIntoView({behavior:'smooth'}); document.getElementById('pantryFormName').focus();">
      <?= icon('plus', 18) ?><span>Add Ingredient</span>
    </button>
  </div>

  <div class="pantry-summary">
    <div><span class="round-icon"><?= icon('pantry') ?></span><div><strong><?= count($items) ?> ingredients</strong><p>Across <?= $distinctCategoryCount ?> categories</p></div></div>
    <div class="use-soon"><span></span><?= $soonCount ?> item<?= $soonCount === 1 ? '' : 's' ?> to use soon</div>
    <a class="btn btn-secondary" href="<?= url('match.php') ?>"><?= icon('sparkle', 18) ?><span>Find recipes with these</span></a>
  </div>

  <form id="pantryForm" method="post" action="<?= url('pantry.php') ?>" class="modal-card" style="margin-bottom:1.5rem; max-width: 100%;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
    <h2><?= $editing ? 'Edit ingredient' : 'Add an ingredient' ?></h2>
    <p><?= $editing ? 'Update the details below.' : "Add something you have on hand — we'll use it for recipe matching." ?></p>
    <div class="form-grid">
      <label class="field <?= isset($errors['name']) ? 'has-error' : '' ?>">
        <span>Ingredient name</span>
        <input id="pantryFormName" type="text" name="name" placeholder="e.g. Chicken breast" value="<?= e($editing['custom_name'] ?? '') ?>" required>
        <?php if (isset($errors['name'])): ?><small class="field-error"><?= e($errors['name']) ?></small><?php endif; ?>
      </label>
      <label class="field"><span>Quantity <small>Optional</small></span><input type="text" name="quantity" placeholder="e.g. 500 g" value="<?= e($editing['quantity_text'] ?? '') ?>"></label>
      <label class="field">
        <span>Category</span>
        <select name="category_id">
          <option value="">Uncategorized</option>
          <?php foreach ($ingredientCategories as $c): ?>
            <option value="<?= (int) $c['id'] ?>" <?= (($editing['category_id'] ?? null) == $c['id']) ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="field"><span>Expiration date <small>Optional</small></span><input type="date" name="expires_on" value="<?= e($editing['expires_on'] ?? '') ?>"></label>
    </div>
    <div class="modal-actions">
      <?php if ($editing): ?><a class="btn btn-secondary" href="<?= url('pantry.php') ?>">Cancel</a><?php endif; ?>
      <button type="submit" class="btn btn-primary"><?= icon($editing ? 'check' : 'plus', 18) ?><span><?= $editing ? 'Save changes' : 'Add Ingredient' ?></span></button>
    </div>
  </form>

  <form method="get" action="<?= url('pantry.php') ?>" class="toolbar">
    <label class="search-field"><?= icon('search') ?><input type="text" name="q" value="<?= e($search) ?>" placeholder="Search your pantry..."></label>
    <select name="category" onchange="this.form.submit()">
      <option value="0">All categories</option>
      <?php foreach ($ingredientCategories as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= $categoryFilter === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="sort" onchange="this.form.submit()">
      <option value="recent" <?= $sort === 'recent' ? 'selected' : '' ?>>Sort: Recently added</option>
      <option value="expiry" <?= $sort === 'expiry' ? 'selected' : '' ?>>Expiry date</option>
      <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Name</option>
    </select>
    <noscript><button class="btn btn-secondary" type="submit">Apply</button></noscript>
  </form>

  <?php if (!$items): ?>
    <div class="empty-state"><strong>Your pantry is empty</strong><p>Add your first ingredient above to start getting recipe matches.</p></div>
  <?php else: ?>
  <div class="pantry-table">
    <div class="table-head"><span>Ingredient</span><span>Quantity</span><span>Category</span><span>Freshness</span><span>Actions</span></div>
    <?php foreach ($items as $item):
        $freshnessLabel = 'Pantry staple';
        $urgent = false;
        if (!empty($item['expires_on'])) {
            $days = (int) floor((strtotime($item['expires_on']) - strtotime(date('Y-m-d'))) / 86400);
            if ($days < 0) { $freshnessLabel = 'Expired'; $urgent = true; }
            elseif ($days === 0) { $freshnessLabel = 'Use today'; $urgent = true; }
            elseif ($days <= 3) { $freshnessLabel = 'Use within ' . $days . ' day' . ($days === 1 ? '' : 's'); $urgent = true; }
            else { $freshnessLabel = 'Use within ' . $days . ' days'; }
        }
    ?>
      <div class="table-row">
        <div class="item-name"><span class="food-dot"><?= e(first_letter($item['custom_name'])) ?></span><strong><?= e($item['custom_name']) ?></strong></div>
        <span><?= e($item['quantity_text'] ?: '—') ?></span>
        <span class="badge badge-neutral"><?= e($item['category_name'] ?? 'Uncategorized') ?></span>
        <span class="<?= $urgent ? 'expiry urgent' : 'expiry' ?>"><?= e($freshnessLabel) ?></span>
        <div class="row-actions">
          <a href="<?= url('pantry.php?edit=' . (int) $item['id']) ?>" aria-label="Edit"><?= icon('edit', 17) ?></a>
          <form method="post" action="<?= url('pantry.php') ?>" data-confirm="Remove this ingredient from your pantry?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
            <button type="submit" aria-label="Delete"><?= icon('trash', 17) ?></button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
