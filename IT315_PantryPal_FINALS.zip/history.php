<?php
require_once __DIR__ . '/config/bootstrap.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];

$stmt = db()->prepare('SELECT * FROM search_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
$stmt->execute([$userId]);
$searches = $stmt->fetchAll();

$pageTitle = 'Search History';
$activeNav = 'history';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">RECENT ACTIVITY</span>
      <h1>Search History</h1>
      <p>Return to previous pantry searches and recipe matches.</p>
    </div>
  </div>
  <?php if (!$searches): ?>
    <div class="empty-state"><strong>No searches yet</strong><p>Use <a href="<?= url('match.php') ?>">Find My Recipes</a> to start building your history.</p></div>
  <?php else: ?>
  <div class="history-list">
    <?php foreach ($searches as $i => $s):
        $ids = json_decode($s['matched_recipe_ids'] ?? '[]', true) ?: [];
        $resubmit = implode(', ', array_map('trim', explode(',', $s['ingredients_text'])));
    ?>
      <article>
        <span class="history-icon"><?= icon($i === 0 ? 'sparkle' : 'clock') ?></span>
        <div class="history-copy">
          <small><?= e(format_datetime($s['created_at'])) ?></small>
          <h3><?= e($s['ingredients_text']) ?></h3>
          <p><?= (int) $s['result_count'] ?> recipe<?= (int) $s['result_count'] === 1 ? '' : 's' ?> found <span>·</span> <?= (int) $s['best_match_percent'] ?>% best match</p>
        </div>
        <form method="post" action="<?= url('match.php') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="ingredients" value='<?= e(json_encode(array_map('trim', explode(',', $s['ingredients_text'])))) ?>'>
          <button type="submit" class="btn btn-secondary">View results</button>
        </form>
      </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
