<?php
require_once __DIR__ . '/config/bootstrap.php';

$recipeId = (int) ($_GET['id'] ?? 0);
$recipe = get_recipe($recipeId);
if (!$recipe || ($recipe['status'] !== 'published' && !is_admin())) {
    http_response_code(404);
    $pageTitle = 'Recipe not found';
    require __DIR__ . '/includes/head.php';
    echo '<div class="page" style="max-width:640px;margin:4rem auto;text-align:center;"><h1>Recipe not found</h1><p><a href="' . url('browse.php') . '">Back to Browse Recipes</a></p></div></body></html>';
    exit;
}

$loggedIn = is_logged_in();
$user = current_user();
$userId = $loggedIn ? (int) $user['id'] : null;

$ingredients = get_recipe_ingredients($recipeId);
$baseSteps = get_recipe_steps($recipeId);
$pantryNames = ($loggedIn && !is_admin()) ? get_user_pantry_names($userId) : [];
$matchResult = calculate_match($pantryNames, $ingredients);
$isSaved = $loggedIn ? is_recipe_favorited($userId, $recipeId) : false;

$substitution = null;
$substitutionError = null;
$adaptedSteps = null;
$adaptedError = null;
$chosenSubstitute = $_SESSION['substitute_' . $recipeId] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $loggedIn) {
    csrf_require();
    $action = $_POST['action'] ?? '';

    if ($action === 'substitute') {
        $missingIngredient = trim($_POST['ingredient'] ?? '');
        if ($missingIngredient !== '') {
            $result = gemini_suggest_substitute($missingIngredient, $recipe['title'], $userId);
            if ($result['ok']) {
                $substitution = $result;
                $_SESSION['substitute_' . $recipeId] = [
                    'missing' => $missingIngredient,
                    'substitute' => $result['substitute'],
                    'reason' => $result['reason'],
                    'amount' => $result['amount'],
                ];
                $chosenSubstitute = $_SESSION['substitute_' . $recipeId];
            } else {
                $substitutionError = $result['error'] === 'not_configured'
                    ? 'AI substitution needs a Gemini API key configured by the site admin.'
                    : $result['error'];
            }
        }
    }

    if ($action === 'adapt_instructions') {
        $missingNames = array_column($matchResult['missing'], 'name');
        $note = $chosenSubstitute ? ($chosenSubstitute['missing'] . ' → ' . $chosenSubstitute['substitute']) : null;
        $result = gemini_adapt_instructions($recipe['title'], $baseSteps, $missingNames, $note, $userId);
        if ($result['ok']) {
            $adaptedSteps = $result['steps'];
            $_SESSION['adapted_' . $recipeId] = $adaptedSteps;
        } else {
            $adaptedError = $result['error'] === 'not_configured'
                ? 'AI-adapted instructions need a Gemini API key configured by the site admin.'
                : $result['error'];
        }
    }
}

if ($substitution === null && $chosenSubstitute) {
    $substitution = ['substitute' => $chosenSubstitute['substitute'], 'reason' => $chosenSubstitute['reason'], 'amount' => $chosenSubstitute['amount']];
}
if ($adaptedSteps === null && !empty($_SESSION['adapted_' . $recipeId])) {
    $adaptedSteps = $_SESSION['adapted_' . $recipeId];
}

$firstMissing = $matchResult['missing'][0]['name'] ?? null;
$totalTime = (int) $recipe['prep_time_minutes'] + (int) $recipe['cook_time_minutes'];
$matchTone = match_badge_tone((int) $matchResult['percent']);
$matchLabel = $matchResult['percent'] >= 90 ? 'Excellent match' : ($matchResult['percent'] >= 60 ? 'Good match' : ($matchResult['percent'] > 0 ? 'Partial match' : 'No pantry ingredients yet'));

$pageTitle = $recipe['title'];
require __DIR__ . '/includes/head.php';
if ($loggedIn && !is_admin()) {
    require __DIR__ . '/includes/app-shell-start.php';
} else {
    echo '<div style="max-width:1180px;margin:0 auto;padding:1.5rem;">';
    require __DIR__ . '/includes/public-nav.php';
}
?>
<div class="recipe-page">
  <div class="recipe-cover">
    <img src="<?= e($recipe['image_url']) ?>" alt="<?= e($recipe['title']) ?>">
    <a class="back-pill" href="<?= url('browse.php') ?>" onclick="if(document.referrer){history.back();return false;}">&larr; Back to recipes</a>
    <div class="cover-actions">
      <?php if ($loggedIn && !is_admin()): ?>
        <form method="post" action="<?= url('api/toggle-favorite.php') ?>" class="favorite-toggle-form inline-form <?= $isSaved ? 'is-saved' : '' ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="recipe_id" value="<?= $recipeId ?>">
          <input type="hidden" name="redirect" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
          <button type="submit"><?= icon('heart', 16) ?> <?= $isSaved ? 'Saved' : 'Save' ?></button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <div class="recipe-detail-content">
    <div class="recipe-main">
      <div class="detail-title">
        <span class="badge badge-<?= $matchTone ?>"><?= e(strtoupper($matchLabel)) ?></span>
        <h1><?= e($recipe['title']) ?></h1>
        <p><?= e($recipe['description']) ?></p>
        <div class="detail-meta">
          <div><?= icon('timer') ?><span><strong><?= (int) $recipe['prep_time_minutes'] ?> min</strong><small>Prep</small></span></div>
          <div><?= icon('clock') ?><span><strong><?= (int) $recipe['cook_time_minutes'] ?> min</strong><small>Cook</small></span></div>
          <div><?= icon('users') ?><span><strong><?= (int) $recipe['servings'] ?></strong><small>Servings</small></span></div>
          <div><?= icon('chef') ?><span><strong><?= e($recipe['difficulty']) ?></strong><small>Difficulty</small></span></div>
        </div>
      </div>

      <section class="detail-section">
        <div class="section-top">
          <div><span class="badge badge-neutral">PANTRY CHECK</span><h2>Ingredients</h2></div>
          <?php if ($pantryNames): ?><div class="inline-match"><strong><?= (int) $matchResult['percent'] ?>%</strong> pantry match</div><?php endif; ?>
        </div>
        <div class="have-missing">
          <div class="have">
            <h3><span><?= icon('check') ?></span><?= $pantryNames ? 'Ingredients you have' : 'Full ingredient list' ?></h3>
            <?php foreach ($ingredients as $ing):
                $isHave = !$pantryNames || in_array($ing['name'], array_column($matchResult['have'], 'name'), true);
                if ($pantryNames && !$isHave) continue;
            ?>
              <div><span><?= icon('check', 15) ?><?= e($ing['name']) ?><?= $ing['is_optional'] ? ' (optional)' : '' ?></span><strong><?= e($ing['quantity_text'] ?? '') ?></strong></div>
            <?php endforeach; ?>
          </div>
          <?php if ($pantryNames && $matchResult['missing']): ?>
          <div class="missing-box">
            <h3>Missing ingredient<?= count($matchResult['missing']) === 1 ? '' : 's' ?></h3>
            <?php foreach ($matchResult['missing'] as $m): ?>
              <div><span>○ <?= e($m['name']) ?></span><strong><?= e(array_values(array_filter($ingredients, fn($i) => $i['name'] === $m['name']))[0]['quantity_text'] ?? '') ?></strong></div>
            <?php endforeach; ?>
            <small><?= e($matchResult['missing'][0]['optional'] ?? false ? 'Optional garnish' : 'Needed for this recipe') ?></small>
          </div>
          <?php endif; ?>
        </div>
      </section>

      <?php if ($loggedIn && !is_admin() && $firstMissing): ?>
      <section class="substitution">
        <div class="ai-section-head">
          <span class="ai-icon"><?= icon('sparkle') ?></span>
          <div><span class="badge badge-peach">PANTRYPAL AI</span><h2>Smart Ingredient Substitution</h2><p>A practical swap based on this recipe's flavor and function.</p></div>
        </div>
        <?php if ($substitution): ?>
          <div class="sub-card">
            <div class="swap">
              <div><small>MISSING</small><strong><?= e($chosenSubstitute['missing'] ?? $firstMissing) ?></strong></div>
              <span>&rarr;</span>
              <div><small>SUGGESTED SUBSTITUTE</small><strong><?= e($substitution['substitute']) ?></strong></div>
            </div>
            <div class="why-grid">
              <div><small>WHY IT WORKS</small><p><?= e($substitution['reason']) ?></p></div>
              <div><small>SUGGESTED AMOUNT</small><p><?= e($substitution['amount'] ?: 'To taste') ?></p></div>
            </div>
          </div>
        <?php elseif ($substitutionError): ?>
          <p class="ai-error-note"><?= e($substitutionError) ?></p>
        <?php else: ?>
          <form method="post" action="<?= url('recipe.php?id=' . $recipeId) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="substitute">
            <input type="hidden" name="ingredient" value="<?= e($firstMissing) ?>">
            <button type="submit" class="btn btn-primary"><?= icon('sparkle', 17) ?><span>Suggest a substitute for "<?= e($firstMissing) ?>"</span></button>
          </form>
        <?php endif; ?>
      </section>
      <?php endif; ?>

      <section class="instructions">
        <div class="section-top">
          <div><span class="badge badge-peach"><?= icon('sparkle', 14) ?> <?= $adaptedSteps ? 'AI-ASSISTED INSTRUCTIONS' : 'COOKING INSTRUCTIONS' ?></span><h2><?= $adaptedSteps ? 'Your adapted cooking plan' : 'How to make it' ?></h2></div>
          <span class="time-pill"><?= icon('timer') ?><?= $totalTime ?> minutes</span>
        </div>
        <?php if ($adaptedSteps): ?>
          <p>These steps reflect your available ingredients<?= $chosenSubstitute ? ' and selected substitute' : '' ?>.</p>
          <ol>
            <?php foreach ($adaptedSteps as $i => $s): ?>
              <li><span><?= $i + 1 ?></span><div><h3><?= e($s['title'] ?? '') ?></h3><p><?= e($s['description'] ?? '') ?></p></div></li>
            <?php endforeach; ?>
          </ol>
        <?php else: ?>
          <?php if ($adaptedError): ?><p class="ai-error-note"><?= e($adaptedError) ?></p><?php endif; ?>
          <ol>
            <?php foreach ($baseSteps as $i => $s): ?>
              <li><span><?= $i + 1 ?></span><div><h3><?= e($s['title']) ?></h3><p><?= e($s['description']) ?></p></div></li>
            <?php endforeach; ?>
          </ol>
          <?php if ($loggedIn && !is_admin()): ?>
            <form method="post" action="<?= url('recipe.php?id=' . $recipeId) ?>" style="margin-top:1rem;">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="adapt_instructions">
              <button type="submit" class="btn btn-secondary"><?= icon('sparkle', 17) ?><span>Adapt instructions with AI</span></button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
      </section>
    </div>

    <aside class="recipe-side">
      <div class="sticky-card">
        <div class="big-match">
          <<div class="match-ring" style="--pct:<?= (int) $matchResult['percent'] ?>"><strong><?= (int) $matchResult['percent'] ?>%</strong><small>MATCH</small></div>
          <div><strong><?= e($matchLabel) ?></strong><p><?= count($matchResult['have']) ?> of <?= count($ingredients) ?> ingredients ready</p></div>
        </div>
        <div class="progress"><span style="width:<?= (int) $matchResult['percent'] ?>%"></span></div>
        <p><?= $matchResult['missing'] ? 'You\'re missing ' . count($matchResult['missing']) . ' ingredient' . (count($matchResult['missing']) === 1 ? '' : 's') . ' for this recipe.' : 'You have all ingredients needed for this recipe.' ?></p>
        <?php if ($loggedIn && !is_admin()): ?>
          <a class="btn btn-primary full" href="#instructions"><?= icon('chef', 17) ?><span>Start cooking</span></a>
          <form method="post" action="<?= url('api/toggle-favorite.php') ?>" class="favorite-toggle-form inline-form <?= $isSaved ? 'is-saved' : '' ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="recipe_id" value="<?= $recipeId ?>">
            <input type="hidden" name="redirect" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
            <button type="submit" class="btn btn-secondary full"><?= icon('heart', 17) ?><span><?= $isSaved ? 'Saved to favorites' : 'Save recipe' ?></span></button>
          </form>
        <?php else: ?>
          <a class="btn btn-primary full" href="<?= url('login.php') ?>"><span>Log in to save & cook</span></a>
        <?php endif; ?>
      </div>
    </aside>
  </div>
</div>
<?php
if ($loggedIn && !is_admin()) {
    require __DIR__ . '/includes/app-shell-end.php';
} else {
    echo '</div></body></html>';
}
