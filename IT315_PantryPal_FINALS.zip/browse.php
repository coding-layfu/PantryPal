<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/recipe-card.php';

$loggedIn = is_logged_in();
$user = current_user();

$search = trim($_GET['q'] ?? '');
$difficulty = trim($_GET['difficulty'] ?? '');
$maxTime = (int) ($_GET['time'] ?? 0);
$cuisine = trim($_GET['cuisine'] ?? '');
$sort = $_GET['sort'] ?? 'match';

$recipes = get_published_recipes($search ?: null, $difficulty ?: null, null);

if ($maxTime > 0) {
    $recipes = array_values(array_filter($recipes, fn($r) => ((int) $r['prep_time_minutes'] + (int) $r['cook_time_minutes']) <= $maxTime));
}
if ($cuisine !== '') {
    $recipes = array_values(array_filter($recipes, fn($r) => $r['cuisine'] === $cuisine));
}

$pantryNames = ($loggedIn && !is_admin()) ? get_user_pantry_names((int) $user['id']) : [];
$recipes = attach_match_scores($recipes, $pantryNames);

if ($sort === 'time') {
    usort($recipes, fn($a, $b) => ((int) $a['prep_time_minutes'] + (int) $a['cook_time_minutes']) <=> ((int) $b['prep_time_minutes'] + (int) $b['cook_time_minutes']));
} elseif ($sort === 'easy') {
    $order = ['Easy' => 0, 'Medium' => 1, 'Hard' => 2];
    usort($recipes, fn($a, $b) => ($order[$a['difficulty']] ?? 9) <=> ($order[$b['difficulty']] ?? 9));
} elseif (!$pantryNames) {
    usort($recipes, fn($a, $b) => strcmp($a['title'], $b['title']));
}
// else: already sorted by match desc from attach_match_scores

$cuisines = db()->query('SELECT DISTINCT cuisine FROM recipes WHERE status="published" AND cuisine IS NOT NULL ORDER BY cuisine')->fetchAll(PDO::FETCH_COLUMN);
$favIds = $loggedIn ? get_favorite_recipe_ids((int) $user['id']) : [];

$pageTitle = 'Browse Recipes';
$activeNav = 'browse';
require __DIR__ . '/includes/head.php';

if ($loggedIn && !is_admin()) {
    require __DIR__ . '/includes/app-shell-start.php';
} else {
    echo '<div class="page" style="max-width:1180px;margin:0 auto;padding:2rem 1.5rem;">';
    require __DIR__ . '/includes/public-nav.php';
}
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">RECIPE LIBRARY</span>
      <h1>Discover something delicious</h1>
      <p>Browse database recipes and see how they match your pantry.</p>
    </div>
  </div>

  <form class="toolbar" method="get" action="<?= url('browse.php') ?>">
    <label class="search-field grow"><?= icon('search') ?><input type="text" name="q" value="<?= e($search) ?>" placeholder="Search recipes..."></label>
    <select name="sort" onchange="this.form.submit()">
      <option value="match" <?= $sort === 'match' ? 'selected' : '' ?>>Best Match</option>
      <option value="time" <?= $sort === 'time' ? 'selected' : '' ?>>Fastest</option>
      <option value="easy" <?= $sort === 'easy' ? 'selected' : '' ?>>Easiest</option>
    </select>
    <select name="time" onchange="this.form.submit()">
      <option value="0">Any time</option>
      <option value="20" <?= $maxTime === 20 ? 'selected' : '' ?>>Under 20 min</option>
      <option value="30" <?= $maxTime === 30 ? 'selected' : '' ?>>Under 30 min</option>
      <option value="45" <?= $maxTime === 45 ? 'selected' : '' ?>>Under 45 min</option>
    </select>
    <select name="difficulty" onchange="this.form.submit()">
      <option value="">Any difficulty</option>
      <?php foreach (['Easy', 'Medium', 'Hard'] as $d): ?>
        <option value="<?= $d ?>" <?= $difficulty === $d ? 'selected' : '' ?>><?= $d ?></option>
      <?php endforeach; ?>
    </select>
    <select name="cuisine" onchange="this.form.submit()">
      <option value="">Any cuisine</option>
      <?php foreach ($cuisines as $c): ?>
        <option value="<?= e($c) ?>" <?= $cuisine === $c ? 'selected' : '' ?>><?= e($c) ?></option>
      <?php endforeach; ?>
    </select>
    <noscript><button class="btn btn-secondary" type="submit">Apply</button></noscript>
  </form>

  <div class="browse-count"><strong><?= count($recipes) ?> recipe<?= count($recipes) === 1 ? '' : 's' ?></strong><span>Sorted by <?= $sort === 'match' ? 'best match' : ($sort === 'time' ? 'fastest' : 'easiest') ?></span></div>

  <?php if (!$recipes): ?>
    <div class="empty-state"><strong>No recipes found</strong><p>Try a different search or clear your filters.</p></div>
  <?php else: ?>
  <div class="recipe-grid browse-grid">
    <?php foreach ($recipes as $r): render_recipe_card($r, in_array((int) $r['id'], $favIds, true), (bool) $pantryNames); endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php
if ($loggedIn && !is_admin()) {
    require __DIR__ . '/includes/app-shell-end.php';
} else {
    echo '</div></body></html>';
}
