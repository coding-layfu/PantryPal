<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/ingredient-composer.php';
require_once __DIR__ . '/includes/recipe-card.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];

$pantryNames = get_user_pantry_names($userId);
$pantryCount = count($pantryNames);

$stmt = db()->prepare('SELECT COUNT(*) c FROM favorites WHERE user_id = ?');
$stmt->execute([$userId]);
$favCount = (int) $stmt->fetch()['c'];

$stmt = db()->prepare('SELECT COUNT(*) c FROM search_history WHERE user_id = ?');
$stmt->execute([$userId]);
$searchCount = (int) $stmt->fetch()['c'];

$recipes = get_published_recipes();
$recipes = attach_match_scores($recipes, $pantryNames);
$readyCount = count(array_filter($recipes, fn($r) => $r['match'] >= 60));
$recommended = array_slice($recipes, 0, 3);
$favIds = get_favorite_recipe_ids($userId);

$firstName = explode(' ', $user['full_name'])[0];

$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach"><?= e(strtoupper(date('l, F j'))) ?></span>
      <h1>Good <?= (int) date('G') < 12 ? 'morning' : ((int) date('G') < 18 ? 'afternoon' : 'evening') ?>, <?= e($firstName) ?>!</h1>
      <p>What's cooking today? Let's make something delicious with what you have.</p>
    </div>
  </div>

  <section class="dashboard-hero">
    <div class="dash-copy">
      <span class="badge badge-green">YOUR SMART KITCHEN</span>
      <h2>What ingredients<br>do you have?</h2>
      <p>Add what's in your kitchen and we'll find your best recipe matches.</p>
    </div>
    <?php render_ingredient_composer(['action' => url('match.php'), 'pantryNames' => $pantryNames]); ?>
  </section>

  <div class="stat-grid">
    <article class="stat-card"><span class="stat-icon"><?= icon('pantry') ?></span><div><strong><?= $pantryCount ?></strong><p>Pantry ingredients</p><small><a href="<?= url('pantry.php') ?>" class="text-link">Manage pantry</a></small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('book') ?></span><div><strong><?= $readyCount ?></strong><p>Recipes found</p><small>Ready to cook</small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('heart') ?></span><div><strong><?= $favCount ?></strong><p>Saved recipes</p><small><a href="<?= url('favorites.php') ?>" class="text-link">View favorites</a></small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('search') ?></span><div><strong><?= $searchCount ?></strong><p>Total searches</p><small>All time</small></div></article>
  </div>

  <section class="content-section">
    <div class="section-top">
      <div><span class="badge badge-peach">FOR YOU</span><h2>Recommended from your pantry</h2></div>
      <a class="text-link" href="<?= url('browse.php') ?>">See all <?= icon('arrow', 16) ?></a>
    </div>
    <div class="recipe-grid">
      <?php if ($recommended): ?>
        <?php foreach ($recommended as $r): render_recipe_card($r, in_array((int) $r['id'], $favIds, true)); endforeach; ?>
      <?php else: ?>
        <div class="empty-state"><strong>No recipes yet</strong><p>Ask an admin to add some recipes to get started.</p></div>
      <?php endif; ?>
    </div>
  </section>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
