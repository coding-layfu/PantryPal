<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $stmt = db()->prepare('DELETE FROM ingredients WHERE id = ?');
        $stmt->execute([(int) $_POST['id']]);
        flash('success', 'Ingredient deleted.');
        redirect(url('admin/ingredients.php'));
    }

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $categoryId = (int) ($_POST['category_id'] ?? 0) ?: null;

        if ($name === '') {
            $errors['name'] = 'Please enter an ingredient name.';
        } else {
            $stmt = db()->prepare('SELECT id FROM ingredients WHERE name = ? AND id != ?');
            $stmt->execute([$name, $id]);
            if ($stmt->fetch()) {
                $errors['name'] = 'That ingredient already exists.';
            }
        }

        if (!$errors) {
            if ($id > 0) {
                $stmt = db()->prepare('UPDATE ingredients SET name = ?, category_id = ? WHERE id = ?');
                $stmt->execute([$name, $categoryId, $id]);
                flash('success', 'Ingredient updated.');
            } else {
                $stmt = db()->prepare('INSERT INTO ingredients (name, category_id) VALUES (?, ?)');
                $stmt->execute([$name, $categoryId]);
                flash('success', 'Ingredient added.');
            }
            redirect(url('admin/ingredients.php'));
        }
    }
}

if (isset($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM ingredients WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$search = trim($_GET['q'] ?? '');
$categoryFilter = (int) ($_GET['category'] ?? 0);

$sql = 'SELECT i.*, c.name AS category_name,
        (SELECT COUNT(*) FROM recipe_ingredients ri WHERE ri.ingredient_id = i.id) AS recipe_count
        FROM ingredients i LEFT JOIN categories c ON c.id = i.category_id WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND i.name LIKE ?';
    $params[] = '%' . $search . '%';
}
if ($categoryFilter > 0) {
    $sql .= ' AND i.category_id = ?';
    $params[] = $categoryFilter;
}
$sql .= ' ORDER BY i.name ASC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$ingredients = $stmt->fetchAll();

$categories = db()->query("SELECT * FROM categories WHERE type='ingredient' ORDER BY name")->fetchAll();

$pageTitle = 'Ingredient Management';
$activeNav = 'admin-ingredients';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ADMIN CONSOLE</span>
      <h1>Ingredient Management</h1>
      <p>Maintain the standardized ingredient catalog.</p>
    </div>
    <button type="button" class="btn btn-primary" onclick="document.getElementById('ingForm').scrollIntoView({behavior:'smooth'});document.getElementById('ingFormName').focus();"><?= icon('plus', 18) ?><span>Add Ingredient</span></button>
  </div>

  <form id="ingForm" method="post" action="<?= url('admin/ingredients.php') ?>" class="modal-card" style="margin-bottom:1.5rem; max-width: 100%;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
    <h2><?= $editing ? 'Edit ingredient' : 'Add an ingredient' ?></h2>
    <p>Ingredients added here become available for recipes and are matched against user pantries.</p>
    <div class="form-grid">
      <label class="field <?= isset($errors['name']) ? 'has-error' : '' ?>">
        <span>Ingredient name</span>
        <input id="ingFormName" type="text" name="name" value="<?= e($editing['name'] ?? '') ?>" required>
        <?php if (isset($errors['name'])): ?><small class="field-error"><?= e($errors['name']) ?></small><?php endif; ?>
      </label>
      <label class="field">
        <span>Category</span>
        <select name="category_id">
          <option value="">Uncategorized</option>
          <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= (($editing['category_id'] ?? null) == $c['id']) ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select>
      </label>
    </div>
    <div class="modal-actions">
      <?php if ($editing): ?><a class="btn btn-secondary" href="<?= url('admin/ingredients.php') ?>">Cancel</a><?php endif; ?>
      <button type="submit" class="btn btn-primary"><?= icon($editing ? 'check' : 'plus', 18) ?><span><?= $editing ? 'Save changes' : 'Add Ingredient' ?></span></button>
    </div>
  </form>

  <form class="toolbar" method="get" action="<?= url('admin/ingredients.php') ?>">
    <label class="search-field grow"><?= icon('search') ?><input type="text" name="q" value="<?= e($search) ?>" placeholder="Search ingredients..."></label>
    <select name="category" onchange="this.form.submit()">
      <option value="0">All categories</option>
      <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $categoryFilter === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
    </select>
  </form>

  <section class="data-table">
    <div class="data-head"><span>Ingredient</span><span>Category</span><span>Recipes</span><span>Status</span><span>Added</span><span>Actions</span></div>
    <?php foreach ($ingredients as $i): ?>
      <div class="data-row">
        <span><strong><?= e($i['name']) ?></strong></span>
        <span><?= e($i['category_name'] ?? 'Uncategorized') ?></span>
        <span><?= (int) $i['recipe_count'] ?> recipe<?= (int) $i['recipe_count'] === 1 ? '' : 's' ?></span>
        <span class="status-active">Active</span>
        <span><?= e(date('M j, Y', strtotime($i['created_at']))) ?></span>
        <span class="row-actions">
          <a href="<?= url('admin/ingredients.php?edit=' . (int) $i['id']) ?>" aria-label="Edit"><?= icon('edit', 17) ?></a>
          <form method="post" action="<?= url('admin/ingredients.php') ?>" data-confirm="Delete &quot;<?= e($i['name']) ?>&quot;? It will be removed from any recipes using it.">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int) $i['id'] ?>">
            <button type="submit" aria-label="Delete"><?= icon('trash', 17) ?></button>
          </form>
        </span>
      </div>
    <?php endforeach; ?>
    <?php if (!$ingredients): ?><div class="empty-state"><strong>No ingredients found</strong><p>Add your first ingredient above.</p></div><?php endif; ?>
  </section>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
