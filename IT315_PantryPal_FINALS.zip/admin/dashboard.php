<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$stats = admin_stats();
$days = admin_searches_last_7_days();
$usage = admin_ai_feature_breakdown();
$activity = admin_recent_activity();

// Build a simple real SVG line/area path from the 7-day counts (viewBox 700x230).
$counts = array_column($days, 'count');
$maxCount = max(1, max($counts));
$stepX = 700 / max(1, count($days) - 1);
$points = [];
foreach ($counts as $i => $c) {
    $x = round($i * $stepX);
    $y = round(210 - ($c / $maxCount) * 190);
    $points[] = [$x, $y];
}
$linePath = 'M' . implode(' L', array_map(fn($p) => $p[0] . ' ' . $p[1], $points));
$areaPath = $linePath . " L700 230 L0 230 Z";
$weekTotal = array_sum($counts);
$prevWeekTotal = max(1, $weekTotal); // no prior-week data yet; avoid divide-by-zero for the badge below

$user = current_user();
$firstName = explode(' ', $user['full_name'])[0];

$pageTitle = 'Admin Dashboard';
$activeNav = 'admin-dashboard';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ADMIN OVERVIEW</span>
      <h1>Good <?= (int) date('G') < 18 ? 'afternoon' : 'evening' ?>, <?= e($firstName) ?>.</h1>
      <p>Here's what's happening across PantryPal today.</p>
    </div>
  </div>

  <div class="stat-grid admin-stats">
    <article class="stat-card"><span class="stat-icon"><?= icon('users') ?></span><div><strong><?= number_format($stats['total_users']) ?></strong><p>Total users</p><small class="positive"><?= $stats['active_users'] ?> active</small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('user') ?></span><div><strong><?= number_format($stats['active_users']) ?></strong><p>Active users</p><small class="positive"><?= $stats['total_users'] > 0 ? round($stats['active_users'] / $stats['total_users'] * 100) : 0 ?>%</small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('book') ?></span><div><strong><?= number_format($stats['total_recipes']) ?></strong><p>Total recipes</p><small><?= $stats['published_recipes'] ?> published</small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('search') ?></span><div><strong><?= number_format($stats['total_searches']) ?></strong><p>Recipe searches</p><small>All time</small></div></article>
    <article class="stat-card"><span class="stat-icon"><?= icon('sparkle') ?></span><div><strong><?= number_format($stats['total_ai_requests']) ?></strong><p>AI requests</p><small class="positive"><?= $stats['ai_success_rate'] ?>% success</small></div></article>
  </div>

  <div class="analytics-grid">
    <section class="chart-card">
      <div class="section-top">
        <div><h2>Recipe searches</h2><p>Search volume over the last 7 days</p></div>
        <span class="badge badge-green"><?= $weekTotal ?> this week</span>
      </div>
      <div class="line-chart">
        <svg viewBox="0 0 700 230" preserveAspectRatio="none">
          <defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--caramel)" stop-opacity=".28"/><stop offset="1" stop-color="var(--caramel)" stop-opacity="0"/></linearGradient></defs>
          <path class="area" fill="url(#area)" d="<?= e($areaPath) ?>"/>
          <path class="line" fill="none" d="<?= e($linePath) ?>"/>
        </svg>
        <div class="chart-labels"><?php foreach ($days as $d): ?><span><?= e($d['day']) ?></span><?php endforeach; ?></div>
      </div>
    </section>
    <section class="chart-card">
      <h2>AI feature usage</h2>
      <p>Share of total AI requests</p>
      <div class="usage-bars">
        <?php foreach ($usage as $u): ?>
          <div><div><span><?= e($u['label']) ?></span><strong><?= $u['percent'] ?>%</strong></div><i><span style="width:<?= $u['percent'] ?>%"></span></i></div>
        <?php endforeach; ?>
      </div>
    </section>
  </div>

  <section class="admin-table-card">
    <div class="section-top">
      <div><h2>Recent activity</h2><p>Latest events across the platform</p></div>
      <a class="text-link" href="<?= url('admin/ai-activity.php') ?>">View all</a>
    </div>
    <div class="activity-list">
      <?php foreach ($activity as $a): ?>
        <div>
          <span class="activity-icon"><?= icon($a['icon']) ?></span>
          <div><strong><?= e($a['title']) ?></strong><p><?= e($a['desc']) ?></p></div>
          <small><?= e(time_ago($a['time'])) ?></small>
        </div>
      <?php endforeach; ?>
      <?php if (!$activity): ?><p style="padding:1rem 0;color:var(--brown-2);font-size:.8rem;">No activity yet.</p><?php endif; ?>
    </div>
  </section>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
