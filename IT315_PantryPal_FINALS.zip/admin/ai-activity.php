<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$featureFilter = $_GET['feature'] ?? '';
$stats = admin_stats();
$usage = admin_ai_feature_breakdown();

$sql = 'SELECT a.*, u.full_name FROM ai_requests a LEFT JOIN users u ON u.id = a.user_id WHERE 1=1';
$params = [];
if ($featureFilter !== '') {
    $sql .= ' AND a.feature = ?';
    $params[] = $featureFilter;
}
$sql .= ' ORDER BY a.created_at DESC LIMIT 50';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$requests = $stmt->fetchAll();

$featureLabels = [
    'ingredient_understanding' => 'Ingredient Understanding',
    'recipe_matching' => 'Recipe Matching',
    'recipe_recommendation' => 'Recipe Recommendations',
    'ingredient_substitution' => 'Ingredient Substitution',
    'cooking_instructions' => 'Cooking Instructions',
];

$pageTitle = 'AI Activity';
$activeNav = 'admin-ai';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">AI MONITORING</span>
      <h1>AI Activity</h1>
      <p>Monitor focused AI features, request health and response performance.</p>
    </div>
    <span class="badge badge-green">&#9679; <?= gemini_is_configured() ? 'GEMINI CONNECTED' : 'GEMINI KEY NOT SET' ?></span>
  </div>

  <div class="stat-grid">
    <article class="stat-card"><div><strong><?= number_format($stats['total_ai_requests']) ?></strong><p>Total requests</p><small>All time</small></div></article>
    <article class="stat-card"><div><strong><?= $stats['ai_success_rate'] ?>%</strong><p>Success rate</p><small></small></div></article>
    <article class="stat-card"><div><strong><?= number_format($stats['avg_response_ms'] / 1000, 1) ?>s</strong><p>Avg. response</p><small>Successful requests</small></div></article>
    <article class="stat-card"><div><strong><?= gemini_is_configured() ? 'Live' : 'Fallback'  ?></strong><p>Gemini status</p><small><?= gemini_is_configured() ? 'API key configured' : 'Using offline fallback' ?></small></div></article>
  </div>

  <div class="analytics-grid">
    <section class="chart-card">
      <h2>AI feature usage</h2>
      <p>AI is used only to enhance recipe-related tasks — never as an open chatbot.</p>
      <div class="usage-bars large">
        <?php foreach ($usage as $u): ?>
          <div><div><span><?= e($u['label']) ?></span><strong><?= $u['percent'] ?>%</strong></div><i><span style="width:<?= $u['percent'] ?>%"></span></i></div>
        <?php endforeach; ?>
      </div>
    </section>
    <section class="ai-boundary">
      <?= icon('database', 28) ?>
      <h2>System boundary</h2>
      <p>Core recipes, ingredients and basic matching stay in MySQL. AI only enhances understanding, ranking and explanations — recipe data is never sent to Gemini in bulk.</p>
      <div><span>PHP + MySQL</span><?= icon('arrow') ?><span>Focused AI layer</span></div>
    </section>
  </div>

  <section class="data-table ai-table">
    <div class="section-top">
      <div><h2>Request activity</h2><p>Most recent AI feature requests</p></div>
      <form method="get" action="<?= url('admin/ai-activity.php') ?>">
        <select name="feature" onchange="this.form.submit()">
          <option value="">All functions</option>
          <?php foreach ($featureLabels as $key => $label): ?>
            <option value="<?= e($key) ?>" <?= $featureFilter === $key ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
    <div class="data-head"><span>Date</span><span>User</span><span>AI function</span><span>Status</span><span>Response time</span></div>
    <?php foreach ($requests as $r): ?>
      <div class="data-row">
        <span><?= e(date('m/d/Y g:i A', strtotime($r['created_at']))) ?></span>
        <span><?= e($r['full_name'] ?? 'Guest') ?></span>
        <span><?= e($featureLabels[$r['feature']] ?? $r['feature']) ?></span>
        <span class="<?= $r['status'] === 'success' ? 'status-active' : 'status-muted' ?>"><?= e(ucfirst($r['status'])) ?></span>
        <span><?= $r['response_time_ms'] !== null ? number_format($r['response_time_ms'] / 1000, 1) . ' sec' : '—' ?></span>
      </div>
    <?php endforeach; ?>
    <?php if (!$requests): ?><div class="empty-state"><strong>No AI activity yet</strong><p>Requests will appear here once users start using AI-powered features.</p></div><?php endif; ?>
  </section>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
