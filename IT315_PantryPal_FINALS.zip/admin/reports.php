<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$mostSearched = admin_most_searched_ingredients(5);
$mostMatched = admin_most_matched_recipes(5);
$missing = admin_common_missing_ingredients(5);
$weekly = admin_weekly_activity();

$missingTotal = array_sum(array_column($missing, 'count'));

$pageTitle = 'Reports & Analytics';
$activeNav = 'admin-reports';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">INSIGHTS</span>
      <h1>Reports &amp; Analytics</h1>
      <p>Understand searches, matches and feature adoption.</p>
    </div>
  </div>

  <div class="report-grid">
    <section class="chart-card">
      <h2>Most searched ingredients</h2>
      <p>Top ingredients used in recipe searches</p>
      <div class="rank-bars">
        <?php foreach ($mostSearched as $i => $b): ?>
          <div><span><?= $i + 1 ?></span><strong><?= e($b['name']) ?></strong><i><b style="width:<?= $b['percent'] ?>%"></b></i><small><?= $b['count'] ?></small></div>
        <?php endforeach; ?>
        <?php if (!$mostSearched): ?><p style="color:var(--brown-2);font-size:.78rem;">No searches recorded yet.</p><?php endif; ?>
      </div>
    </section>

    <section class="chart-card">
      <h2>Most matched recipes</h2>
      <p>Recipes appearing most often in results</p>
      <div class="popular-list">
        <?php foreach ($mostMatched as $r): ?>
          <div><img src="<?= e($r['image_url']) ?>" alt=""><span><strong><?= e($r['title']) ?></strong><small><?= (int) $r['match_count'] ?> matches</small></span><span class="badge badge-green"><?= e($r['difficulty']) ?></span></div>
        <?php endforeach; ?>
        <?php if (!$mostMatched): ?><p style="color:var(--brown-2);font-size:.78rem;">No search results recorded yet.</p><?php endif; ?>
      </div>
    </section>

    <section class="chart-card">
      <h2>Common missing ingredients</h2>
      <p>Opportunities for substitution support</p>
      <div class="donut-wrap">
        <div class="donut"><strong><?= $missingTotal ?></strong><small>TOTAL</small></div>
        <div class="legend">
          <?php foreach ($missing as $m): ?>
            <div><span></span><?= e($m['name']) ?><strong><?= $m['percent'] ?>%</strong></div>
          <?php endforeach; ?>
          <?php if (!$missing): ?><p style="color:var(--brown-2);font-size:.78rem;">Not enough data yet.</p><?php endif; ?>
        </div>
      </div>
    </section>

    <section class="chart-card">
      <h2>User activity</h2>
      <p>Distinct users searching per day, last 7 days</p>
      <div class="column-chart">
        <?php foreach ($weekly as $w): ?>
          <div><i style="height:<?= max(4, $w['percent']) ?>%"></i><span><?= e($w['label']) ?></span></div>
        <?php endforeach; ?>
      </div>
    </section>
  </div>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
