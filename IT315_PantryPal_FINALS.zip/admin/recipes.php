<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_require();
    $stmt = db()->prepare('DELETE FROM recipes WHERE id = ?');
    $stmt->execute([(int) $_POST['id']]);
    flash('success', 'Recipe deleted.');
    redirect(url('admin/recipes.php'));
}

$search = trim($_GET['q'] ?? '');
$categoryFilter = (int) ($_GET['category'] ?? 0);
$statusFilter = $_GET['status'] ?? '';

$sql = 'SELECT r.*, c.name AS category_name FROM recipes r LEFT JOIN categories c ON c.id = r.category_id WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND r.title LIKE ?';
    $params[] = '%' . $search . '%';
}
if ($categoryFilter > 0) {
    $sql .= ' AND r.category_id = ?';
    $params[] = $categoryFilter;
}
if ($statusFilter !== '') {
    $sql .= ' AND r.status = ?';
    $params[] = $statusFilter;
}
$sql .= ' ORDER BY r.created_at DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$recipes = $stmt->fetchAll();

$categories = db()->query("SELECT * FROM categories WHERE type='recipe' ORDER BY name")->fetchAll();

$pageTitle = 'Recipe Management';
$activeNav = 'admin-recipes';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ADMIN CONSOLE</span>
      <h1>Recipe Management</h1>
      <p>Create, edit and organize the recipe database.</p>
    </div>
    <a class="btn btn-primary" href="<?= url('admin/recipe-form.php') ?>"><?= icon('plus', 18) ?><span>Add Recipe</span></a>
  </div>

  <form class="toolbar" method="get" action="<?= url('admin/recipes.php') ?>">
    <label class="search-field grow"><?= icon('search') ?><input type="text" name="q" value="<?= e($search) ?>" placeholder="Search recipes..."></label>
    <select name="category" onchange="this.form.submit()">
      <option value="0">All categories</option>
      <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $categoryFilter === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
    </select>
    <select name="status" onchange="this.form.submit()">
      <option value="">All statuses</option>
      <option value="published" <?= $statusFilter === 'published' ? 'selected' : '' ?>>Published</option>
      <option value="draft" <?= $statusFilter === 'draft' ? 'selected' : '' ?>>Draft</option>
    </select>
  </form>

  <section class="data-table">
    <div class="data-head"><span>Recipe</span><span>Category</span><span>Difficulty</span><span>Cooking time</span><span>Status</span><span>Date added</span><span>Actions</span></div>
    <?php foreach ($recipes as $r): ?>
      <div class="data-row">
        <span><img src="<?= e($r['image_url']) ?>" alt="" style="width:2rem;height:2rem;border-radius:.4rem;object-fit:cover;vertical-align:middle;margin-right:.5rem;"><strong><?= e($r['title']) ?></strong></span>
        <span><?= e($r['category_name'] ?? '—') ?></span>
        <span><?= e($r['difficulty']) ?></span>
        <span><?= (int) $r['prep_time_minutes'] + (int) $r['cook_time_minutes'] ?> min</span>
        <span class="<?= $r['status'] === 'published' ? 'status-active' : 'status-muted' ?>"><?= e(ucfirst($r['status'])) ?></span>
        <span><?= e(date('M j, Y', strtotime($r['created_at']))) ?></span>
        <span class="row-actions">
          <a href="<?= url('admin/recipe-form.php?id=' . (int) $r['id']) ?>" aria-label="Edit"><?= icon('edit', 17) ?></a>
          <form method="post" action="<?= url('admin/recipes.php') ?>" data-confirm="Delete &quot;<?= e($r['title']) ?>&quot;? This cannot be undone.">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
            <button type="submit" aria-label="Delete"><?= icon('trash', 17) ?></button>
          </form>
        </span>
      </div>
    <?php endforeach; ?>
    <?php if (!$recipes): ?><div class="empty-state"><strong>No recipes found</strong><p>Try adjusting your filters, or add a new recipe.</p></div><?php endif; ?>
  </section>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
