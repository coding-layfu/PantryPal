<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $stmt = db()->prepare("DELETE FROM categories WHERE id = ? AND type = 'recipe'");
        $stmt->execute([(int) $_POST['id']]);
        flash('success', 'Category deleted.');
        redirect(url('admin/categories.php'));
    }

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $slug = slugify($name);

        if ($name === '') {
            $errors['name'] = 'Please enter a category name.';
        } else {
            $stmt = db()->prepare("SELECT id FROM categories WHERE type='recipe' AND name = ? AND id != ?");
            $stmt->execute([$name, $id]);
            if ($stmt->fetch()) {
                $errors['name'] = 'That category already exists.';
            }
        }

        if (!$errors) {
            if ($id > 0) {
                $stmt = db()->prepare("UPDATE categories SET name = ?, slug = ? WHERE id = ? AND type='recipe'");
                $stmt->execute([$name, $slug, $id]);
                flash('success', 'Category updated.');
            } else {
                $stmt = db()->prepare("INSERT INTO categories (name, slug, type) VALUES (?, ?, 'recipe')");
                $stmt->execute([$name, $slug]);
                flash('success', 'Category added.');
            }
            redirect(url('admin/categories.php'));
        }
    }
}

if (isset($_GET['edit'])) {
    $stmt = db()->prepare("SELECT * FROM categories WHERE id = ? AND type='recipe'");
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$stmt = db()->query(
    "SELECT c.*, (SELECT COUNT(*) FROM recipes r WHERE r.category_id = c.id) AS recipe_count
     FROM categories c WHERE c.type = 'recipe' ORDER BY c.name"
);
$categories = $stmt->fetchAll();

$pageTitle = 'Category Management';
$activeNav = 'admin-categories';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ADMIN CONSOLE</span>
      <h1>Category Management</h1>
      <p>Organize recipes into browsable categories.</p>
    </div>
    <button type="button" class="btn btn-primary" onclick="document.getElementById('catForm').scrollIntoView({behavior:'smooth'});document.getElementById('catFormName').focus();"><?= icon('plus', 18) ?><span>Add Category</span></button>
  </div>
<form id="catForm" method="post" action="<?= url('admin/categories.php') ?>" class="modal-card" style="margin-bottom:1.5rem; max-width: 100%;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
    <h2><?= $editing ? 'Edit category' : 'Add a category' ?></h2>
    <label class="field <?= isset($errors['name']) ? 'has-error' : '' ?>">
      <span>Category name</span>
      <input id="catFormName" type="text" name="name" value="<?= e($editing['name'] ?? '') ?>" placeholder="e.g. Breakfast" required>
      <?php if (isset($errors['name'])): ?><small class="field-error"><?= e($errors['name']) ?></small><?php endif; ?>
    </label>
    <div class="modal-actions">
      <?php if ($editing): ?><a class="btn btn-secondary" href="<?= url('admin/categories.php') ?>">Cancel</a><?php endif; ?>
      <button type="submit" class="btn btn-primary"><?= icon($editing ? 'check' : 'plus', 18) ?><span><?= $editing ? 'Save changes' : 'Add Category' ?></span></button>
    </div>
  </form>

  <section class="data-table categories-table">
    <div class="data-head"><span>Category</span><span>Slug</span><span>Recipes</span><span>Actions</span></div>
    <?php foreach ($categories as $c): ?>
      <div class="data-row">
        <span><strong><?= e($c['name']) ?></strong></span>
        <span><?= e($c['slug']) ?></span>
        <span><?= (int) $c['recipe_count'] ?> recipe<?= (int) $c['recipe_count'] === 1 ? '' : 's' ?></span>
        <span class="row-actions">
          <a href="<?= url('admin/categories.php?edit=' . (int) $c['id']) ?>" aria-label="Edit"><?= icon('edit', 17) ?></a>
          <form method="post" action="<?= url('admin/categories.php') ?>" data-confirm="Delete &quot;<?= e($c['name']) ?>&quot;? Recipes in it will become uncategorized.">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <button type="submit" aria-label="Delete"><?= icon('trash', 17) ?></button>
          </form>
        </span>
      </div>
    <?php endforeach; ?>
    <?php if (!$categories): ?><div class="empty-state"><strong>No categories yet</strong><p>Add your first recipe category above.</p></div><?php endif; ?>
  </section>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
