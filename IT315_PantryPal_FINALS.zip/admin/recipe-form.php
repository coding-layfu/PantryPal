<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$recipeId = (int) ($_GET['id'] ?? 0);
$recipe = $recipeId ? get_recipe($recipeId) : null;
$isEdit = $recipe !== null;

if ($recipeId && !$recipe) {
    flash('error', 'Recipe not found.');
    redirect(url('admin/recipes.php'));
}

$errors = [];
$form = [
    'title' => $recipe['title'] ?? '',
    'description' => $recipe['description'] ?? '',
    'image_url' => $recipe['image_url'] ?? '',
    'prep_time_minutes' => $recipe['prep_time_minutes'] ?? 10,
    'cook_time_minutes' => $recipe['cook_time_minutes'] ?? 20,
    'servings' => $recipe['servings'] ?? 4,
    'difficulty' => $recipe['difficulty'] ?? 'Easy',
    'cuisine' => $recipe['cuisine'] ?? '',
    'dietary_info' => $recipe['dietary_info'] ?? '',
    'category_id' => $recipe['category_id'] ?? '',
    'status' => $recipe['status'] ?? 'published',
];
$ingredientRows = $isEdit ? get_recipe_ingredients($recipeId) : [];
$stepRows = $isEdit ? get_recipe_steps($recipeId) : [];

if (!$ingredientRows) {
    $ingredientRows = [['ingredient_id' => '', 'quantity_text' => '', 'is_optional' => 0]];
}
if (!$stepRows) {
    $stepRows = [['title' => '', 'description' => '']];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $form['title'] = trim($_POST['title'] ?? '');
    $form['description'] = trim($_POST['description'] ?? '');
    $form['image_url'] = trim($_POST['image_url'] ?? '');
    $form['prep_time_minutes'] = max(0, (int) ($_POST['prep_time_minutes'] ?? 0));
    $form['cook_time_minutes'] = max(0, (int) ($_POST['cook_time_minutes'] ?? 0));
    $form['servings'] = max(1, (int) ($_POST['servings'] ?? 1));
    $form['difficulty'] = in_array($_POST['difficulty'] ?? '', ['Easy', 'Medium', 'Hard'], true) ? $_POST['difficulty'] : 'Easy';
    $form['cuisine'] = trim($_POST['cuisine'] ?? '');
    $form['dietary_info'] = trim($_POST['dietary_info'] ?? '');
    $form['category_id'] = (int) ($_POST['category_id'] ?? 0) ?: null;
    $form['status'] = in_array($_POST['status'] ?? '', ['published', 'draft'], true) ? $_POST['status'] : 'draft';

    $postedIngredients = $_POST['ingredients'] ?? [];
    $postedSteps = $_POST['steps'] ?? [];

    $ingredientRows = [];
    foreach ($postedIngredients as $row) {
        $ingId = (int) ($row['ingredient_id'] ?? 0);
        if ($ingId > 0) {
            $ingredientRows[] = [
                'ingredient_id' => $ingId,
                'quantity_text' => trim($row['quantity_text'] ?? ''),
                'is_optional' => !empty($row['is_optional']) ? 1 : 0,
            ];
        }
    }
    $stepRows = [];
    foreach ($postedSteps as $row) {
        $title = trim($row['title'] ?? '');
        $desc = trim($row['description'] ?? '');
        if ($title !== '' || $desc !== '') {
            $stepRows[] = ['title' => $title !== '' ? $title : 'Step', 'description' => $desc];
        }
    }

    if ($form['title'] === '') {
        $errors['title'] = 'Please enter a recipe title.';
    }
    if (!$ingredientRows) {
        $errors['ingredients'] = 'Add at least one ingredient.';
    }
    if (!$stepRows) {
        $errors['steps'] = 'Add at least one cooking step.';
    }

    if (!$errors) {
        $slugBase = slugify($form['title']);
        $slug = $slugBase;
        $suffix = 1;
        while (true) {
            $stmt = db()->prepare('SELECT id FROM recipes WHERE slug = ? AND id != ?');
            $stmt->execute([$slug, $recipeId]);
            if (!$stmt->fetch()) {
                break;
            }
            $suffix++;
            $slug = $slugBase . '-' . $suffix;
        }

        db()->beginTransaction();
        try {
            if ($isEdit) {
                $stmt = db()->prepare(
                    'UPDATE recipes SET title=?, slug=?, description=?, image_url=?, prep_time_minutes=?, cook_time_minutes=?,
                     servings=?, difficulty=?, cuisine=?, dietary_info=?, category_id=?, status=? WHERE id=?'
                );
                $stmt->execute([
                    $form['title'], $slug, $form['description'], $form['image_url'] ?: null,
                    $form['prep_time_minutes'], $form['cook_time_minutes'], $form['servings'], $form['difficulty'],
                    $form['cuisine'] ?: null, $form['dietary_info'] ?: null, $form['category_id'], $form['status'], $recipeId,
                ]);
                db()->prepare('DELETE FROM recipe_ingredients WHERE recipe_id = ?')->execute([$recipeId]);
                db()->prepare('DELETE FROM recipe_steps WHERE recipe_id = ?')->execute([$recipeId]);
            } else {
                $stmt = db()->prepare(
                    'INSERT INTO recipes (title, slug, description, image_url, prep_time_minutes, cook_time_minutes,
                     servings, difficulty, cuisine, dietary_info, category_id, status, created_by)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
                );
                $stmt->execute([
                    $form['title'], $slug, $form['description'], $form['image_url'] ?: null,
                    $form['prep_time_minutes'], $form['cook_time_minutes'], $form['servings'], $form['difficulty'],
                    $form['cuisine'] ?: null, $form['dietary_info'] ?: null, $form['category_id'], $form['status'], (int) current_user()['id'],
                ]);
                $recipeId = (int) db()->lastInsertId();
            }

            $stmt = db()->prepare(
                'INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity_text, is_optional, display_order) VALUES (?,?,?,?,?)'
            );
            foreach ($ingredientRows as $i => $row) {
                $stmt->execute([$recipeId, $row['ingredient_id'], $row['quantity_text'] ?: null, $row['is_optional'], $i]);
            }

            $stmt = db()->prepare('INSERT INTO recipe_steps (recipe_id, step_order, title, description) VALUES (?,?,?,?)');
            foreach ($stepRows as $i => $row) {
                $stmt->execute([$recipeId, $i, $row['title'], $row['description']]);
            }

            db()->commit();
            flash('success', $isEdit ? 'Recipe updated.' : 'Recipe created.');
            redirect(url('admin/recipes.php'));
        } catch (Throwable $e) {
            db()->rollBack();
            $errors['form'] = 'Something went wrong saving this recipe. Please try again.';
        }
    }
}

$allIngredients = db()->query('SELECT id, name FROM ingredients ORDER BY name')->fetchAll();
$recipeCategories = db()->query("SELECT * FROM categories WHERE type='recipe' ORDER BY name")->fetchAll();

$pageTitle = $isEdit ? 'Edit Recipe' : 'Add Recipe';
$activeNav = 'admin-recipes';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ADMIN CONSOLE</span>
      <h1><?= $isEdit ? 'Edit Recipe' : 'Add Recipe' ?></h1>
      <p><?= $isEdit ? 'Update ' . e($recipe['title']) : 'Create a new recipe for the PantryPal database.' ?></p>
    </div>
    <a class="btn btn-secondary" href="<?= url('admin/recipes.php') ?>">Cancel</a>
  </div>

  <?php if (!empty($errors['form'])): ?><div class="flash flash-error"><?= e($errors['form']) ?></div><?php endif; ?>

  <form method="post" action="<?= url('admin/recipe-form.php' . ($isEdit ? '?id=' . $recipeId : '')) ?>" id="recipeForm">
    <?= csrf_field() ?>

    <div class="modal-card" style="max-width:none;margin-bottom:1.2rem;">
      <h2>Recipe details</h2>
      <div class="form-grid">
        <label class="field <?= isset($errors['title']) ? 'has-error' : '' ?>" style="grid-column:1/-1;">
          <span>Recipe title</span>
          <input type="text" name="title" value="<?= e($form['title']) ?>" required>
          <?php if (isset($errors['title'])): ?><small class="field-error"><?= e($errors['title']) ?></small><?php endif; ?>
        </label>
        <label class="field" style="grid-column:1/-1;">
          <span>Description</span>
          <textarea name="description" rows="3"><?= e($form['description']) ?></textarea>
        </label>
        <label class="field" style="grid-column:1/-1;">
          <span>Image URL</span>
          <input type="url" name="image_url" value="<?= e($form['image_url']) ?>" placeholder="https://images.unsplash.com/...">
        </label>
        <label class="field"><span>Prep time (min)</span><input type="number" min="0" name="prep_time_minutes" value="<?= (int) $form['prep_time_minutes'] ?>"></label>
        <label class="field"><span>Cook time (min)</span><input type="number" min="0" name="cook_time_minutes" value="<?= (int) $form['cook_time_minutes'] ?>"></label>
        <label class="field"><span>Servings</span><input type="number" min="1" name="servings" value="<?= (int) $form['servings'] ?>"></label>
        <label class="field">
          <span>Difficulty</span>
          <select name="difficulty">
            <?php foreach (['Easy', 'Medium', 'Hard'] as $d): ?><option value="<?= $d ?>" <?= $form['difficulty'] === $d ? 'selected' : '' ?>><?= $d ?></option><?php endforeach; ?>
          </select>
        </label>
        <label class="field"><span>Cuisine</span><input type="text" name="cuisine" value="<?= e($form['cuisine']) ?>" placeholder="e.g. Asian-inspired"></label>
        <label class="field"><span>Dietary info <small>Optional</small></span><input type="text" name="dietary_info" value="<?= e($form['dietary_info']) ?>" placeholder="e.g. Vegetarian"></label>
        <label class="field">
          <span>Category</span>
          <select name="category_id">
            <option value="">Uncategorized</option>
            <?php foreach ($recipeCategories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= (string) $form['category_id'] === (string) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </label>
        <label class="field">
          <span>Status</span>
          <select name="status">
            <option value="published" <?= $form['status'] === 'published' ? 'selected' : '' ?>>Published</option>
            <option value="draft" <?= $form['status'] === 'draft' ? 'selected' : '' ?>>Draft</option>
          </select>
        </label>
      </div>
    </div>

    <div class="modal-card" style="max-width:none;margin-bottom:1.2rem;">
      <h2>Ingredients</h2>
      <p>Pick from the ingredient catalog so pantry matching works correctly.</p>
      <?php if (isset($errors['ingredients'])): ?><div class="flash flash-error"><?= e($errors['ingredients']) ?></div><?php endif; ?>
      <div id="ingredientRows">
        <?php foreach ($ingredientRows as $i => $row): ?>
          <div class="ingredient-picker-row">
            <select name="ingredients[<?= $i ?>][ingredient_id]">
              <option value="">Select ingredient…</option>
              <?php foreach ($allIngredients as $ing): ?>
                <option value="<?= (int) $ing['id'] ?>" <?= (string) ($row['ingredient_id'] ?? '') === (string) $ing['id'] ? 'selected' : '' ?>><?= e($ing['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <input type="text" name="ingredients[<?= $i ?>][quantity_text]" value="<?= e($row['quantity_text'] ?? '') ?>" placeholder="Quantity, e.g. 2 cups">
            <label class="checkbox-inline"><input type="checkbox" name="ingredients[<?= $i ?>][is_optional]" value="1" <?= !empty($row['is_optional']) ? 'checked' : '' ?>> Optional</label>
            <button type="button" class="btn btn-secondary remove-row" aria-label="Remove ingredient"><?= icon('trash', 16) ?></button>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="btn btn-secondary" id="addIngredientRow"><?= icon('plus', 16) ?><span>Add ingredient</span></button>
    </div>

    <div class="modal-card" style="max-width:none;margin-bottom:1.2rem;">
      <h2>Cooking steps</h2>
      <?php if (isset($errors['steps'])): ?><div class="flash flash-error"><?= e($errors['steps']) ?></div><?php endif; ?>
      <div id="stepRows">
        <?php foreach ($stepRows as $i => $row): ?>
          <div class="step-row" style="margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid var(--border);">
            <div class="form-grid">
              <label class="field"><span>Step <?= $i + 1 ?> title</span><input type="text" name="steps[<?= $i ?>][title]" value="<?= e($row['title'] ?? '') ?>" placeholder="e.g. Cook the chicken"></label>
              <label class="field" style="grid-column:1/-1;"><span>Instructions</span><textarea name="steps[<?= $i ?>][description]" rows="2"><?= e($row['description'] ?? '') ?></textarea></label>
            </div>
            <button type="button" class="btn btn-secondary remove-row"><?= icon('trash', 16) ?><span>Remove step</span></button>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="btn btn-secondary" id="addStepRow"><?= icon('plus', 16) ?><span>Add step</span></button>
    </div>

    <div class="modal-actions">
      <a class="btn btn-secondary" href="<?= url('admin/recipes.php') ?>">Cancel</a>
      <button type="submit" class="btn btn-primary"><?= icon('check', 18) ?><span><?= $isEdit ? 'Save changes' : 'Create Recipe' ?></span></button>
    </div>
  </form>
</div>

<script>
(function () {
  var ingredientOptionsHTML = document.querySelector('#ingredientRows select') ? document.querySelector('#ingredientRows select').innerHTML : '';
  var ingIndex = <?= count($ingredientRows) ?>;
  var stepIndex = <?= count($stepRows) ?>;

  document.getElementById('addIngredientRow').addEventListener('click', function () {
    var row = document.createElement('div');
    row.className = 'ingredient-picker-row';
    row.innerHTML =
      '<select name="ingredients[' + ingIndex + '][ingredient_id]"><option value="">Select ingredient…</option>' + ingredientOptionsHTML.replace(/<option value="">Select ingredient…<\/option>/, '') + '</select>' +
      '<input type="text" name="ingredients[' + ingIndex + '][quantity_text]" placeholder="Quantity, e.g. 2 cups">' +
      '<label class="checkbox-inline"><input type="checkbox" name="ingredients[' + ingIndex + '][is_optional]" value="1"> Optional</label>' +
      '<button type="button" class="btn btn-secondary remove-row" aria-label="Remove ingredient">\u00D7</button>';
    document.getElementById('ingredientRows').appendChild(row);
    ingIndex++;
  });

  document.getElementById('addStepRow').addEventListener('click', function () {
    var row = document.createElement('div');
    row.className = 'step-row';
    row.style.marginBottom = '1rem';
    row.style.paddingBottom = '1rem';
    row.style.borderBottom = '1px solid var(--border)';
    row.innerHTML =
      '<div class="form-grid">' +
      '<label class="field"><span>Step title</span><input type="text" name="steps[' + stepIndex + '][title]" placeholder="e.g. Cook the chicken"></label>' +
      '<label class="field" style="grid-column:1/-1;"><span>Instructions</span><textarea name="steps[' + stepIndex + '][description]" rows="2"></textarea></label>' +
      '</div><button type="button" class="btn btn-secondary remove-row">Remove step</button>';
    document.getElementById('stepRows').appendChild(row);
    stepIndex++;
  });

  document.addEventListener('click', function (e) {
    if (e.target.closest('.remove-row')) {
      var row = e.target.closest('.ingredient-picker-row, .step-row');
      if (row) row.remove();
    }
  });
})();
</script>

<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
