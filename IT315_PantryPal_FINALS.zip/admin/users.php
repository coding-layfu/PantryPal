<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_admin();

$currentAdminId = (int) current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($id === $currentAdminId && in_array($action, ['deactivate', 'delete', 'demote'], true)) {
        flash('error', "You can't change your own account that way while logged in.");
        redirect(url('admin/users.php'));
    }

    if ($action === 'toggle_status') {
        $stmt = db()->prepare("UPDATE users SET status = IF(status='active','inactive','active') WHERE id = ?");
        $stmt->execute([$id]);
        flash('success', 'User status updated.');
    } elseif ($action === 'toggle_role') {
        $stmt = db()->prepare("UPDATE users SET role = IF(role='admin','user','admin') WHERE id = ?");
        $stmt->execute([$id]);
        flash('success', 'User role updated.');
    } elseif ($action === 'delete') {
        $stmt = db()->prepare('DELETE FROM users WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'User deleted.');
    }
    redirect(url('admin/users.php'));
}

$search = trim($_GET['q'] ?? '');
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';

$sql = 'SELECT * FROM users WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND (full_name LIKE ? OR email LIKE ?)';
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
}
if ($roleFilter !== '') {
    $sql .= ' AND role = ?';
    $params[] = $roleFilter;
}
if ($statusFilter !== '') {
    $sql .= ' AND status = ?';
    $params[] = $statusFilter;
}
$sql .= ' ORDER BY created_at DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'User Management';
$activeNav = 'admin-users';
$isAdminSection = true;
require __DIR__ . '/../includes/head.php';
require __DIR__ . '/../includes/app-shell-start.php';
?>
<div class="page admin-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ADMIN CONSOLE</span>
      <h1>User Management</h1>
      <p>View accounts, roles and current status.</p>
    </div>
    <a class="btn btn-primary" href="<?= url('register.php') ?>"><?= icon('plus', 18) ?><span>Add User</span></a>
  </div>

  <form class="toolbar" method="get" action="<?= url('admin/users.php') ?>">
    <label class="search-field grow"><?= icon('search') ?><input type="text" name="q" value="<?= e($search) ?>" placeholder="Search users..."></label>
    <select name="role" onchange="this.form.submit()">
      <option value="">All roles</option>
      <option value="user" <?= $roleFilter === 'user' ? 'selected' : '' ?>>User</option>
      <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>Admin</option>
    </select>
    <select name="status" onchange="this.form.submit()">
      <option value="">All statuses</option>
      <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
      <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactive</option>
    </select>
  </form>

  <section class="data-table users-table">
    <div class="data-head"><span>Name</span><span>Email</span><span>Role</span><span>Registered</span><span>Status</span><span>Actions</span></div>
    <?php foreach ($users as $u): ?>
      <div class="data-row">
        <span><strong><?= e($u['full_name']) ?></strong><?= $u['id'] === $currentAdminId ? ' <small style="color:var(--brown-2);">(you)</small>' : '' ?></span>
        <span><?= e($u['email']) ?></span>
        <span><?= e(strtoupper($u['role'])) ?></span>
        <span><?= e(date('M j, Y', strtotime($u['created_at']))) ?></span>
        <span class="<?= $u['status'] === 'active' ? 'status-active' : 'status-muted' ?>"><?= e(ucfirst($u['status'])) ?></span>
        <span class="row-actions">
          <form method="post" action="<?= url('admin/users.php') ?>" data-confirm="<?= $u['status'] === 'active' ? 'Deactivate' : 'Reactivate' ?> <?= e($u['full_name']) ?>?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_status">
            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
            <button type="submit" aria-label="Toggle status" title="<?= $u['status'] === 'active' ? 'Deactivate' : 'Activate' ?>"><?= icon($u['status'] === 'active' ? 'close' : 'check', 17) ?></button>
          </form>
          <form method="post" action="<?= url('admin/users.php') ?>" data-confirm="Change <?= e($u['full_name']) ?>'s role to <?= $u['role'] === 'admin' ? 'User' : 'Admin' ?>?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_role">
            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
            <button type="submit" aria-label="Toggle role" title="Make <?= $u['role'] === 'admin' ? 'User' : 'Admin' ?>"><?= icon('settings', 17) ?></button>
          </form>
          <form method="post" action="<?= url('admin/users.php') ?>" data-confirm="Permanently delete <?= e($u['full_name']) ?>? This cannot be undone.">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
            <button type="submit" aria-label="Delete"><?= icon('trash', 17) ?></button>
          </form>
        </span>
      </div>
    <?php endforeach; ?>
    <?php if (!$users): ?><div class="empty-state"><strong>No users found</strong></div><?php endif; ?>
  </section>
</div>
<?php require __DIR__ . '/../includes/app-shell-end.php'; ?>
