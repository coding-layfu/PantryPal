<?php
require_once __DIR__ . '/../config/bootstrap.php';

require_method('POST');

if (!is_logged_in()) {
    if (is_ajax_request()) {
        json_response(['success' => false, 'message' => 'Please log in first.'], 401);
    }
    redirect(url('login.php'));
}

csrf_require();

$userId = (int) current_user()['id'];
$recipeId = (int) ($_POST['recipe_id'] ?? 0);
$redirectTo = $_POST['redirect'] ?? url('dashboard.php');

if ($recipeId <= 0) {
    if (is_ajax_request()) {
        json_response(['success' => false, 'message' => 'Invalid recipe.'], 422);
    }
    redirect($redirectTo);
}

$saved = is_recipe_favorited($userId, $recipeId);

if ($saved) {
    $stmt = db()->prepare('DELETE FROM favorites WHERE user_id = ? AND recipe_id = ?');
    $stmt->execute([$userId, $recipeId]);
    $saved = false;
} else {
    // Make sure the recipe actually exists first.
    $check = db()->prepare('SELECT id FROM recipes WHERE id = ? LIMIT 1');
    $check->execute([$recipeId]);
    if ($check->fetch()) {
        $stmt = db()->prepare('INSERT IGNORE INTO favorites (user_id, recipe_id) VALUES (?, ?)');
        $stmt->execute([$userId, $recipeId]);
        $saved = true;
    }
}

if (is_ajax_request()) {
    json_response(['success' => true, 'saved' => $saved]);
}

flash('success', $saved ? 'Added to favorites.' : 'Removed from favorites.');
redirect($redirectTo);
