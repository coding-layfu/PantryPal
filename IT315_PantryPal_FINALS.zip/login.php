<?php
require_once __DIR__ . '/config/bootstrap.php';

if (is_logged_in()) {
    redirect(url(is_admin() ? 'admin/dashboard.php' : 'dashboard.php'));
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $errors['form'] = 'Please enter both your email and password.';
    } else {
        $stmt = db()->prepare('SELECT id, full_name, email, password_hash, role, status FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errors['form'] = 'Those credentials don\'t match our records.';
        } elseif ($user['status'] !== 'active') {
            $errors['form'] = 'This account has been deactivated. Please contact an administrator.';
        } else {
            login_user($user);
            flash('success', 'Welcome back, ' . explode(' ', $user['full_name'])[0] . '!');
            redirect(url($user['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard.php'));
        }
    }
    set_old(['email' => $email]);
}

$pageTitle = 'Log in';
require __DIR__ . '/includes/head.php';
?>
<div class="auth-page">
  <a class="auth-logo" href="<?= url('index.php') ?>">
    <span class="logo"><span class="logo-mark"><?= icon('logo', 22) ?></span><span>PantryPal</span></span>
  </a>
  <div class="auth-card">
    <div class="auth-intro">
      <span class="badge badge-peach">WELCOME BACK</span>
      <h1>Your pantry is waiting.</h1>
      <p>Log in to discover what you can make today.</p>
    </div>

    <?php if (!empty($errors['form'])): ?><div class="flash flash-error"><?= e($errors['form']) ?></div><?php endif; ?>
    <?php render_flashes(); ?>

    <form method="post" action="<?= url('login.php') ?>">
      <?= csrf_field() ?>
      <label class="field"><span>Email address</span><input type="email" name="email" placeholder="maria@example.com" value="<?= old('email') ?>" required></label>
      <label class="field"><span>Password</span><input type="password" name="password" placeholder="••••••••" required></label>
      <div class="form-row">
        <label class="check"><input type="checkbox"> Remember me</label>
      </div>
      <button type="submit" class="btn btn-primary full"><?= icon('arrow', 18) ?><span>Log in to PantryPal</span></button>
    </form>
        <p class="auth-switch">New to PantryPal? <a href="<?= url('register.php') ?>">Create account</a></p>
  </div>
  <div class="auth-aside">
    <img src="https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=1200&q=85" alt="A warm bowl of fried rice">
    <div>
      <?= icon('sparkle') ?>
      <p>"Dinner went from no idea to on the table in 30 minutes."</p>
      <strong>— Maria, home cook</strong>
    </div>
  </div>
</div>
</body>
</html>
