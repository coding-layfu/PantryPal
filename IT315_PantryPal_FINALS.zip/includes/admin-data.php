<?php
/**
 * Query helpers used only by the admin section.
 */

function admin_stats(): array
{
    $db = db();
    return [
        'total_users' => (int) $db->query('SELECT COUNT(*) c FROM users')->fetch()['c'],
        'active_users' => (int) $db->query("SELECT COUNT(*) c FROM users WHERE status='active'")->fetch()['c'],
        'total_recipes' => (int) $db->query('SELECT COUNT(*) c FROM recipes')->fetch()['c'],
        'published_recipes' => (int) $db->query("SELECT COUNT(*) c FROM recipes WHERE status='published'")->fetch()['c'],
        'total_ingredients' => (int) $db->query('SELECT COUNT(*) c FROM ingredients')->fetch()['c'],
        'total_searches' => (int) $db->query('SELECT COUNT(*) c FROM search_history')->fetch()['c'],
        'total_ai_requests' => (int) $db->query('SELECT COUNT(*) c FROM ai_requests')->fetch()['c'],
        'ai_success_rate' => admin_ai_success_rate(),
        'avg_response_ms' => (int) ($db->query('SELECT AVG(response_time_ms) a FROM ai_requests WHERE status="success"')->fetch()['a'] ?? 0),
    ];
}

function admin_ai_success_rate(): float
{
    $db = db();
    $total = (int) $db->query('SELECT COUNT(*) c FROM ai_requests')->fetch()['c'];
    if ($total === 0) {
        return 100.0;
    }
    $success = (int) $db->query("SELECT COUNT(*) c FROM ai_requests WHERE status='success'")->fetch()['c'];
    return round(($success / $total) * 100, 1);
}

/** Daily search counts for the last 7 days, oldest first. */
function admin_searches_last_7_days(): array
{
    $stmt = db()->prepare(
        "SELECT DATE(created_at) d, COUNT(*) c FROM search_history
         WHERE created_at >= (CURDATE() - INTERVAL 6 DAY)
         GROUP BY DATE(created_at)"
    );
    $stmt->execute();
    $byDay = array_column($stmt->fetchAll(), 'c', 'd');

    $out = [];
    for ($i = 6; $i >= 0; $i--) {
        $day = date('Y-m-d', strtotime("-$i day"));
        $out[] = ['day' => date('D', strtotime($day)), 'count' => (int) ($byDay[$day] ?? 0)];
    }
    return $out;
}

/** Percentage breakdown of ai_requests by feature. */
function admin_ai_feature_breakdown(): array
{
    $stmt = db()->query('SELECT feature, COUNT(*) c FROM ai_requests GROUP BY feature');
    $rows = $stmt->fetchAll();
    $total = array_sum(array_column($rows, 'c'));
    $labels = [
        'ingredient_understanding' => 'Ingredient Understanding',
        'recipe_matching' => 'Recipe Matching',
        'recipe_recommendation' => 'Recipe Recommendations',
        'ingredient_substitution' => 'Ingredient Substitution',
        'cooking_instructions' => 'Cooking Instructions',
    ];
    $out = [];
    foreach ($labels as $key => $label) {
        $count = 0;
        foreach ($rows as $r) {
            if ($r['feature'] === $key) {
                $count = (int) $r['c'];
            }
        }
        $out[] = ['label' => $label, 'percent' => $total > 0 ? (int) round(($count / $total) * 100) : 0, 'count' => $count];
    }
    return $out;
}

/** Recent-activity feed combining a few real event sources. */
function admin_recent_activity(int $limit = 6): array
{
    $db = db();
    $events = [];

    $stmt = $db->query('SELECT full_name, created_at FROM users ORDER BY created_at DESC LIMIT 5');
    foreach ($stmt->fetchAll() as $u) {
        $events[] = ['icon' => 'users', 'title' => 'New user registered', 'desc' => $u['full_name'] . ' joined PantryPal', 'time' => $u['created_at']];
    }

    $stmt = $db->query('SELECT title, status, created_at, updated_at FROM recipes ORDER BY updated_at DESC LIMIT 5');
    foreach ($stmt->fetchAll() as $r) {
        $isNew = $r['created_at'] === $r['updated_at'];
        $events[] = [
            'icon' => $isNew ? 'book' : 'edit',
            'title' => $isNew ? 'Recipe added' : 'Recipe updated',
            'desc' => $r['title'] . ($isNew ? ' was ' . $r['status'] : ' was edited'),
            'time' => $r['updated_at'],
        ];
    }

    $stmt = $db->query('SELECT u.full_name, s.result_count, s.created_at FROM search_history s JOIN users u ON u.id = s.user_id ORDER BY s.created_at DESC LIMIT 5');
    foreach ($stmt->fetchAll() as $s) {
        $events[] = ['icon' => 'sparkle', 'title' => 'AI recipe matching request', 'desc' => (int) $s['result_count'] . ' recommendations generated for ' . $s['full_name'], 'time' => $s['created_at']];
    }

    usort($events, fn($a, $b) => strtotime($b['time']) <=> strtotime($a['time']));
    return array_slice($events, 0, $limit);
}

/** Most searched individual ingredient names, tallied from search_history. */
function admin_most_searched_ingredients(int $limit = 5): array
{
    $stmt = db()->query('SELECT ingredients_text FROM search_history');
    $tally = [];
    foreach ($stmt->fetchAll() as $row) {
        foreach (explode(',', $row['ingredients_text']) as $name) {
            $name = trim($name);
            if ($name === '') {
                continue;
            }
            $tally[$name] = ($tally[$name] ?? 0) + 1;
        }
    }
    arsort($tally);
    $tally = array_slice($tally, 0, $limit, true);
    $max = $tally ? max($tally) : 1;
    $out = [];
    foreach ($tally as $name => $count) {
        $out[] = ['name' => $name, 'count' => $count, 'percent' => (int) round(($count / $max) * 100)];
    }
    return $out;
}

/** Recipes that show up most often across everyone's search results. */
function admin_most_matched_recipes(int $limit = 5): array
{
    $stmt = db()->query('SELECT matched_recipe_ids FROM search_history');
    $tally = [];
    foreach ($stmt->fetchAll() as $row) {
        $ids = json_decode($row['matched_recipe_ids'] ?? '[]', true) ?: [];
        foreach ($ids as $id) {
            $tally[(int) $id] = ($tally[(int) $id] ?? 0) + 1;
        }
    }
    arsort($tally);
    $tally = array_slice($tally, 0, $limit, true);
    if (!$tally) {
        return [];
    }
    $placeholders = implode(',', array_fill(0, count($tally), '?'));
    $stmt = db()->prepare("SELECT * FROM recipes WHERE id IN ($placeholders)");
    $stmt->execute(array_keys($tally));
    $recipes = [];
    foreach ($stmt->fetchAll() as $r) {
        $recipes[(int) $r['id']] = $r;
    }
    $out = [];
    foreach ($tally as $id => $count) {
        if (isset($recipes[$id])) {
            $out[] = $recipes[$id] + ['match_count' => $count];
        }
    }
    return $out;
}

/** Ingredients most often missing, recomputed live from real search history + recipe data. */
function admin_common_missing_ingredients(int $limit = 5): array
{
    $stmt = db()->query('SELECT ingredients_text, matched_recipe_ids FROM search_history ORDER BY created_at DESC LIMIT 100');
    $tally = [];
    foreach ($stmt->fetchAll() as $row) {
        $userIngredients = array_map('trim', explode(',', $row['ingredients_text']));
        $ids = json_decode($row['matched_recipe_ids'] ?? '[]', true) ?: [];
        $topId = $ids[0] ?? null;
        if (!$topId) {
            continue;
        }
        $ri = get_recipe_ingredients((int) $topId);
        $result = calculate_match($userIngredients, $ri);
        foreach ($result['missing'] as $m) {
            $tally[$m['name']] = ($tally[$m['name']] ?? 0) + 1;
        }
    }
    arsort($tally);
    $tally = array_slice($tally, 0, $limit, true);
    $total = array_sum($tally) ?: 1;
    $out = [];
    foreach ($tally as $name => $count) {
        $out[] = ['name' => $name, 'count' => $count, 'percent' => (int) round(($count / $total) * 100)];
    }
    return $out;
}

/** Distinct active users per weekday over the last 7 days (search or AI activity counts as active). */
function admin_weekly_activity(): array
{
    $stmt = db()->prepare(
        "SELECT DATE(created_at) d, COUNT(DISTINCT user_id) c FROM search_history
         WHERE created_at >= (CURDATE() - INTERVAL 6 DAY) GROUP BY DATE(created_at)"
    );
    $stmt->execute();
    $byDay = array_column($stmt->fetchAll(), 'c', 'd');
    $maxUsers = max(1, (int) db()->query('SELECT COUNT(*) c FROM users')->fetch()['c']);

    $out = [];
    for ($i = 6; $i >= 0; $i--) {
        $day = date('Y-m-d', strtotime("-$i day"));
        $count = (int) ($byDay[$day] ?? 0);
        $out[] = ['label' => date('D', strtotime($day))[0], 'percent' => (int) round(($count / $maxUsers) * 100)];
    }
    return $out;
}
