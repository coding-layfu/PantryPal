<?php require_once __DIR__ . '/icons.php'; ?>
<header class="public-nav">
  <a class="logo" href="<?= url('index.php') ?>"><span class="logo-mark"><?= icon('logo', 22) ?></span><span>PantryPal</span></a>
  <nav>
    <a href="<?= url('index.php') ?>">Home</a>
    <a href="<?= url('browse.php') ?>">Recipes</a>
    <a href="<?= url('index.php#how') ?>">How it works</a>
  </nav>
  <div class="nav-actions">
    <?php if (is_logged_in()): ?>
      <a class="btn btn-primary" href="<?= url(is_admin() ? 'admin/dashboard.php' : 'dashboard.php') ?>">My dashboard</a>
    <?php else: ?>
      <a class="btn btn-ghost hide-mobile" href="<?= url('login.php') ?>">Log in</a>
      <a class="btn btn-primary hide-mobile" href="<?= url('register.php') ?>">Create account</a>
      
      <!-- Mobile-only login button -->
      <a class="btn btn-primary show-mobile" href="<?= url('login.php') ?>">Log in</a>
    <?php endif; ?>
  </div>
</header>
