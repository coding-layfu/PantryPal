<?php
/**
 * Session-based authentication and role checks.
 */

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    $stmt = db()->prepare('SELECT id, full_name, email, role, status FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user || $user['status'] !== 'active') {
        logout_user();
        return null;
    }

    $cached = $user;
    return $user;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function is_admin(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'admin';
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['user_role'] = $user['role'];
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie('PHPSESSID', '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

/**
 * Redirect to login if not authenticated. Call at the top of any user page.
 */
function require_login(): void
{
    if (!is_logged_in()) {
        redirect(url('login.php'));
    }
}

/**
 * Redirect to login if not an authenticated admin. Call at the top of any
 * admin page.
 */
function require_admin(): void
{
    if (!is_logged_in()) {
        redirect(url('login.php'));
    }
    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to view this page.');
    }
}
