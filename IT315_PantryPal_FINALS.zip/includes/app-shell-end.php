  </main>
  <?php if (!$isAdminSection): $bottomItems = array_slice(user_nav_items(), 0, 5); ?>
  <nav class="bottom-nav">
    <?php foreach ($bottomItems as $item): $active = $activeNav === $item['id']; ?>
      <a href="<?= url($item['href']) ?>" class="<?= $active ? 'active' : '' ?>">
        <?= icon($item['icon']) ?><span><?= e(explode(' ', $item['label'])[0]) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
  <?php endif; ?>
</div>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
