<?php
/**
 * Include AFTER includes/head.php on any logged-in page.
 * Expects: $activeNav (string), $isAdminSection (bool, default false)
 */
require_once __DIR__ . '/nav-config.php';
require_once __DIR__ . '/icons.php';

$isAdminSection = $isAdminSection ?? false;
$activeNav = $activeNav ?? '';
$navItems = $isAdminSection ? admin_nav_items() : user_nav_items();
$user = current_user();
$initial = $user ? first_letter($user['full_name']) : '?';
?>
<div class="app-shell" id="appShell">
    <aside class="sidebar" id="sidebar">
    <div class="sidebar-top">
      <a class="logo" href="<?= url($isAdminSection ? 'admin/dashboard.php' : 'dashboard.php') ?>">
        <span class="logo-mark"><?= icon('logo', 22) ?></span><span class="logo-text">PantryPal</span>
      </a>
      <button class="icon-btn mobile-only" id="sidebarClose" aria-label="Close menu"><?= icon('close') ?></button>
      <button class="icon-btn desktop-only sidebar-collapse-btn" id="sidebarCollapse" aria-label="Collapse sidebar" title="Collapse sidebar"><?= icon('menu') ?></button>
    </div>
    <div class="sidebar-context">
      <?php if ($isAdminSection): ?>
        <span class="badge badge-peach">ADMIN CONSOLE</span>
      <?php else: ?>
        <div class="avatar"><?= e($initial) ?></div>
        <div class="context-copy"><strong><?= e($user['full_name'] ?? '') ?></strong><small>Home cook</small></div>
      <?php endif; ?>
    </div>
    <nav>
      <?php foreach ($navItems as $item): $active = $activeNav === $item['id']; ?>
        <a href="<?= url($item['href']) ?>" class="nav-item <?= $active ? 'active' : '' ?>" title="<?= e($item['label']) ?>">
          <?= icon($item['icon']) ?><span class="nav-label"><?= e($item['label']) ?></span>
          <?php if ($active): ?><span class="nav-dot"></span><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-bottom">
      <a class="nav-item" href="<?= url('logout.php') ?>" title="Logout"><?= icon('logout') ?><span class="nav-label">Logout</span></a>
    </div>
  </aside>
  <div class="scrim" id="scrim" hidden></div>
  <main class="app-main">
    <header class="mobile-header">
      <button class="icon-btn" id="sidebarOpen" aria-label="Open menu"><?= icon('menu') ?></button>
      <div class="logo"><span class="logo-mark"><?= icon('logo', 22) ?></span><span>PantryPal</span></div>
      <a class="avatar small" href="<?= url('profile.php') ?>"><?= e($initial) ?></a>
    </header>
    <?php render_flashes(); ?>
