<?php
/**
 * General-purpose helpers used across the whole app.
 */

/**
 * Works out the base URL path the app is installed under, so links work
 * whether PantryPal lives at the domain root (htdocs/) or in a subfolder
 * (htdocs/pantrypal/) — which matters on shared hosts like InfinityFree.
 */
function base_path(): string
{
    static $basePath = null;
    if ($basePath !== null) {
        return $basePath;
    }

    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
    $appRoot = rtrim(str_replace('\\', '/', ROOT_PATH), '/');

    if ($docRoot !== '' && str_starts_with($appRoot, $docRoot)) {
        $basePath = substr($appRoot, strlen($docRoot));
    } else {
        $basePath = '';
    }

    return $basePath;
}

/** Build a link to a path relative to the project root, e.g. url('admin/recipes.php'). */
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    $base = base_path();
    return ($base === '' ? '' : $base) . '/' . $path;
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

/** Escape for HTML output. */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function old(string $key, string $default = ''): string
{
    return e($_SESSION['_old'][$key] ?? $default);
}

function set_old(array $data): void
{
    $_SESSION['_old'] = $data;
}

function clear_old(): void
{
    unset($_SESSION['_old']);
}

function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $flashes = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $flashes;
}

function render_flashes(): void
{
    foreach (get_flashes() as $f) {
        echo '<div class="flash flash-' . e($f['type']) . '">' . e($f['message']) . '</div>';
    }
}

function first_letter(string $text): string
{
    $text = trim($text);
    return $text === '' ? '?' : mb_strtoupper(mb_substr($text, 0, 1));
}

function format_datetime(string $mysqlDatetime): string
{
    $ts = strtotime($mysqlDatetime);
    if (!$ts) {
        return $mysqlDatetime;
    }
    $today = date('Y-m-d');
    $day = date('Y-m-d', $ts);
    if ($day === $today) {
        return 'Today, ' . date('g:i A', $ts);
    }
    if ($day === date('Y-m-d', strtotime('-1 day'))) {
        return 'Yesterday, ' . date('g:i A', $ts);
    }
    return date('M j, Y g:i A', $ts);
}

function time_ago(string $mysqlDatetime): string
{
    $ts = strtotime($mysqlDatetime);
    if (!$ts) {
        return $mysqlDatetime;
    }
    $diff = time() - $ts;
    if ($diff < 60) {
        return 'just now';
    }
    if ($diff < 3600) {
        return floor($diff / 60) . ' min ago';
    }
    if ($diff < 86400) {
        return floor($diff / 3600) . ' hr ago';
    }
    return floor($diff / 86400) . ' day(s) ago';
}

function slugify(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

/**
 * Splits free-text ingredient input into a clean array of names.
 * Used as the offline fallback when Gemini is unavailable, and as a
 * pre-clean step before sending text to Gemini.
 */
function parse_ingredients_fallback(string $text): array
{
    $text = str_ireplace([' and ', ' & ', "\n"], ',', $text);
    $parts = preg_split('/[,;]+/', $text);
    $items = [];
    foreach ($parts as $part) {
        $part = trim($part);
        $part = preg_replace('/^(i have|i\'ve got|i got|also|some|a|an|the)\s+/i', '', $part);
        $part = trim($part, " .\t\n\r\0\x0B");
        if ($part !== '') {
            $items[] = mb_convert_case($part, MB_CASE_TITLE);
        }
    }
    return array_values(array_unique($items));
}

/**
 * Core database-side ingredient match calculation (no AI involved).
 * Given the user's normalized ingredient names and a recipe's required
 * ingredients (name + is_optional), returns match stats.
 *
 * @param string[] $userIngredients Lowercased ingredient names the user has.
 * @param array $recipeIngredients Each item: ['name' => ..., 'is_optional' => bool]
 */
function calculate_match(array $userIngredients, array $recipeIngredients): array
{
    $userSet = array_map(fn($n) => mb_strtolower(trim($n)), $userIngredients);

    $have = [];
    $missing = [];
    $requiredTotal = 0;
    $requiredHave = 0;

    foreach ($recipeIngredients as $ri) {
        $name = $ri['name'];
        $optional = !empty($ri['is_optional']);
        $needle = mb_strtolower(trim($name));

        $found = false;
        foreach ($userSet as $have_item) {
            if ($have_item === $needle || str_contains($needle, $have_item) || str_contains($have_item, $needle)) {
                $found = true;
                break;
            }
        }

        if (!$optional) {
            $requiredTotal++;
            if ($found) {
                $requiredHave++;
            }
        }

        if ($found) {
            $have[] = ['name' => $name, 'optional' => $optional];
        } else {
            $missing[] = ['name' => $name, 'optional' => $optional];
        }
    }

    $percent = $requiredTotal > 0 ? (int) round(($requiredHave / $requiredTotal) * 100) : 0;

    return [
        'percent' => $percent,
        'have' => $have,
        'missing' => $missing,
    ];
}

function match_badge_tone(int $percent): string
{
    return $percent >= 90 ? 'green' : 'gold';
}

function log_ai_request(?int $userId, string $feature, string $status, ?int $responseTimeMs = null, ?string $error = null): void
{
    try {
        $stmt = db()->prepare(
            'INSERT INTO ai_requests (user_id, feature, status, response_time_ms, error_message, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())'
        );
        $stmt->execute([$userId, $feature, $status, $responseTimeMs, $error]);
    } catch (Throwable $e) {
        // Never let logging break the request.
    }
}

function validate_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function require_method(string $method): void
{
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        http_response_code(405);
        die('Method not allowed.');
    }
}

/**
 * Returns how many AI recipe-generation requests this user has made
 * in the last N minutes. Used to cap token usage per user.
 */
function ai_recipe_gen_count(int $userId, int $minutes = 60): int
{
    $stmt = db()->prepare(
        "SELECT COUNT(*) c FROM ai_requests
         WHERE user_id = ?
           AND feature = 'recipe_recommendation'
           AND created_at >= (NOW() - INTERVAL ? MINUTE)"
    );
    $stmt->execute([$userId, $minutes]);
    return (int) ($stmt->fetch()['c'] ?? 0);
}

/**
 * Convenience check for the recipe-generation rate limit.
 * Returns true if the user is still allowed to generate.
 */
function ai_recipe_gen_allowed(int $userId, int $perHour = 10): bool
{
    return ai_recipe_gen_count($userId, 60) < $perHour;
}