<?php
/**
 * Dedicated Gemini API service.
 *
 * This is the ONLY file in the project that ever calls the Gemini API.
 * The API key is read from config.php (server-side only, never sent to
 * the browser). Every public function here fails soft: on any error it
 * returns ['ok' => false, ...] so the rest of the app can fall back to
 * plain database behaviour instead of breaking.
 *
 * PantryPal deliberately sends Gemini only small, specific payloads
 * (a short ingredient list, or one recipe's name + missing ingredients) —
 * never the whole recipe database — per the app's architecture.
 */
    
/**
 * System instruction for AI recipe generation.
 * PantryPal is built for Filipino home cooks, so recipes should always feel
 * like something you'd actually cook in a Filipino kitchen.
 */
const GEMINI_RECIPE_GEN_SYSTEM = <<<TXT
You are PantryPal's recipe generator, made for Filipino home cooks.

You create practical, everyday Filipino recipes using primarily the ingredients
the user says they have, plus basic Filipino pantry staples the user is very
likely to already own (toyo/soy sauce, suka/vinegar, patis/fish sauce,
bawang/garlic, sibuyas/onion, luya/ginger, asukal/sugar, asin/salt,
paminta/pepper, mantika/cooking oil, bigas/rice, itlog/egg, gata/coconut milk,
and basic noodles/pasta).

Hard rules:
- Return ONLY raw JSON. No markdown fences, no commentary, no extra prose.
- Return exactly a JSON array of between 3 and 5 recipe objects.
- Each recipe object must match this schema exactly:
  {
    "title": string,
    "description": string (1-2 sentences, warm and appetizing),
    "cuisine": string (must be "Filipino", "Filipino-Chinese", "Filipino-Spanish",
                       or "Filipino-Asian Fusion" — no other values),
    "difficulty": one of "Easy" | "Medium" | "Hard",
    "prep_time_minutes": integer (5-60),
    "cook_time_minutes": integer (5-90),
    "servings": integer (1-8),
    "dietary_info": string or null (e.g. "Vegetarian", "Vegan", "Pork-free"),
    "ingredients": array of objects, each: { "name": string, "quantity_text": string, "is_optional": boolean },
    "steps": array of objects, each: { "title": string, "description": string }
  }

Filipino cooking style guidelines:
- Use names that Filipino home cooks would recognize: adobo, sinigang, tinola,
  sisig, menudo, afritada, kaldereta, nilaga, bistek, tapa, longganisa, pancit,
  palabok, arroz caldo, lugaw, goto, champorado, tortang talong, giniling,
  pinakbet, laing, sinangag, itlog na maalat, kakanin, halohalo, leche flan,
  bibingka, puto, kutsinta, maja blanca, etc. Use them when they fit — but
  invent new names only when necessary, and keep them Filipino-sounding.
- Use Filipino ingredient names in parentheses alongside English when it helps:
  e.g. "Soy sauce (toyo)", "Vinegar (suka)", "Fish sauce (patis)",
  "Garlic (bawang)", "Onion (sibuyas)", "Ginger (luya)", "Coconut milk (gata)".
- Measures should feel Filipino: "1 cup", "1 tbsp", "1 kutsara", "1 tasa",
  "1 piraso", "isang piraso", "1/4 kilo", "500 g", "2 cloves", etc. Mix is fine.
- Flavor profile should lean salty-sour-savory (asin-asim-tamis) — the way
  Filipino food usually tastes. Avoid Western-heavy flavors like cheese-heavy
  sauces unless the recipe really needs it.
- Method should be home-kitchen friendly: kawali (wok/pan), kaldero (pot),
  palayok (clay pot), steamer, oven only when needed. Frying, sautéing,
  boiling, simmering, grilling are the defaults.
- Steps should be 3-6 per recipe, each 1-2 sentences, written the way a lola
  would explain it: clear, warm, and no chef jargon.
- Every recipe MUST primarily use the ingredients the user listed.
- You may add common Filipino staples only if they are genuinely basic.
- Do NOT invent exotic or imported ingredients the user is unlikely to have.
- Titles must be distinct from each other.
- Keep descriptions to 1-2 short sentences. Keep step descriptions to 1-2
  short sentences each. Do not pad with filler or long explanations.
- Aim for 4-5 ingredients per recipe and 4-5 steps per recipe. Do not add
  extra steps just to reach a number.
- Total output must stay compact enough to complete without being truncated.
  If space is running short, prefer fewer recipes (3) over longer ones.
TXT;


function gemini_is_configured(): bool
{
    return defined('GEMINI_API_KEY') && trim(GEMINI_API_KEY) !== '';
}

/**
 * Low-level call to the Gemini generateContent endpoint.
 * Returns ['ok' => bool, 'text' => string|null, 'error' => string|null, 'ms' => int]
 */
function gemini_generate(string $prompt, ?string $systemInstruction = null, float $temperature = 0.4): array
{
    $start = microtime(true);

    if (!gemini_is_configured()) {
        return ['ok' => false, 'text' => null, 'error' => 'Gemini API key is not configured.', 'ms' => 0];
    }

    $url = rtrim(GEMINI_API_BASE, '/') . '/' . GEMINI_MODEL . ':generateContent?key=' . urlencode(GEMINI_API_KEY);

    $payload = [
        'contents' => [
            ['role' => 'user', 'parts' => [['text' => $prompt]]],
        ],
        'generationConfig' => [
            'temperature' => $temperature,
            'maxOutputTokens' => 4096,
        ],
    ];

    if ($systemInstruction) {
        $payload['systemInstruction'] = ['parts' => [['text' => $systemInstruction]]];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_TIMEOUT => defined('GEMINI_TIMEOUT_SECONDS') ? GEMINI_TIMEOUT_SECONDS : 12,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    $ms = (int) round((microtime(true) - $start) * 1000);

    if ($response === false) {
        return ['ok' => false, 'text' => null, 'error' => 'Connection error: ' . $curlError, 'ms' => $ms];
    }

    if ($httpCode === 429) {
        return ['ok' => false, 'text' => null, 'error' => 'Rate limited by Gemini. Please try again shortly.', 'ms' => $ms];
    }

    if ($httpCode >= 400) {
        $decoded = json_decode($response, true);
        $msg = $decoded['error']['message'] ?? ('Gemini returned HTTP ' . $httpCode);
        return ['ok' => false, 'text' => null, 'error' => $msg, 'ms' => $ms];
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        return ['ok' => false, 'text' => null, 'error' => 'Malformed response from Gemini.', 'ms' => $ms];
    }

    $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? null;
    if ($text === null) {
        $finishReason = $decoded['candidates'][0]['finishReason'] ?? 'unknown';
        return ['ok' => false, 'text' => null, 'error' => 'No usable content from Gemini (finish reason: ' . $finishReason . ').', 'ms' => $ms];
    }

    return ['ok' => true, 'text' => $text, 'error' => null, 'ms' => $ms];
}

/**
 * Attempts to parse JSON out of a Gemini text response, tolerating markdown
 * code fences that models sometimes wrap JSON in.
 */
function gemini_extract_json(string $text): ?array
{
    $text = trim($text);
    $text = preg_replace('/^```(json)?/i', '', $text);
    $text = preg_replace('/```$/', '', $text);
    $text = trim($text);
    $decoded = json_decode($text, true);
    return is_array($decoded) ? $decoded : null;
}

/**
 * 1. AI Ingredient Understanding
 * Turns free-text ingredient input into a clean array of ingredient names.
 * Falls back to a simple comma/and-splitter if Gemini is unavailable.
 */
function gemini_parse_ingredients(string $freeText, ?int $userId = null): array
{
    $freeText = trim($freeText);
    if ($freeText === '') {
        return ['ok' => true, 'ingredients' => [], 'source' => 'none'];
    }

    if (!gemini_is_configured()) {
        return ['ok' => true, 'ingredients' => parse_ingredients_fallback($freeText), 'source' => 'fallback'];
    }

    $prompt = 'Extract a clean list of individual food ingredient names from this text. ' .
        'Respond with ONLY a JSON array of strings, title-cased, no quantities, no extra words. ' .
        "Text: \"" . str_replace('"', "'", $freeText) . '"';

    $result = gemini_generate($prompt, 'You are an ingredient extraction tool for a recipe app. You only ever respond with a raw JSON array of strings.', 0.1);

    if (!$result['ok']) {
        log_ai_request($userId, 'ingredient_understanding', 'error', $result['ms'], $result['error']);
        return ['ok' => true, 'ingredients' => parse_ingredients_fallback($freeText), 'source' => 'fallback', 'ai_error' => $result['error']];
    }

    $json = gemini_extract_json($result['text']);
    if (!$json || !is_array($json)) {
        log_ai_request($userId, 'ingredient_understanding', 'error', $result['ms'], 'Unparseable JSON response');
        return ['ok' => true, 'ingredients' => parse_ingredients_fallback($freeText), 'source' => 'fallback'];
    }

    log_ai_request($userId, 'ingredient_understanding', 'success', $result['ms']);
    $clean = array_values(array_filter(array_map('strval', $json), fn($v) => trim($v) !== ''));
    return ['ok' => true, 'ingredients' => $clean, 'source' => 'gemini'];
}

/**
 * 2 & 3. AI-Enhanced Recipe Matching / Recommendation explanation.
 * Given one recipe's basic match data (already computed by PHP/MySQL),
 * asks Gemini for a short, useful explanation of the match quality and
 * which missing ingredients matter most.
 */
function gemini_explain_match(string $recipeTitle, int $matchPercent, array $haveNames, array $missingNames, ?int $userId = null): array
{
    if (!gemini_is_configured()) {
        return ['ok' => false, 'explanation' => null, 'error' => 'not_configured'];
    }

    $prompt = sprintf(
        "Recipe: %s\nDatabase match score: %d%%\nIngredients the user already has: %s\nIngredients the user is missing: %s\n\n" .
        'In 2-3 short sentences, explain how good this match is and which missing ingredient(s) actually matter most (mention if any missing ingredient is easily skippable). Be warm and practical, like a helpful home-cooking assistant. Do not repeat the percentage back verbatim as a headline.',
        $recipeTitle,
        $matchPercent,
        $haveNames ? implode(', ', $haveNames) : 'none',
        $missingNames ? implode(', ', $missingNames) : 'none'
    );

    $result = gemini_generate($prompt, 'You are PantryPal\'s recipe-matching assistant. You only explain ingredient matches for recipes — never general conversation.', 0.5);

    if (!$result['ok']) {
        log_ai_request($userId, 'recipe_matching', 'error', $result['ms'], $result['error']);
        return ['ok' => false, 'explanation' => null, 'error' => $result['error']];
    }

    log_ai_request($userId, 'recipe_matching', 'success', $result['ms']);
    return ['ok' => true, 'explanation' => trim($result['text']), 'error' => null];
}

/**
 * 4. AI Ingredient Substitution.
 */
function gemini_suggest_substitute(string $missingIngredient, string $recipeTitle, ?int $userId = null): array
{
    if (!gemini_is_configured()) {
        return ['ok' => false, 'error' => 'not_configured'];
    }

    $prompt = sprintf(
        "Recipe: %s\nMissing ingredient: %s\n\n" .
        'Suggest ONE practical substitute a home cook likely already has. Respond with ONLY JSON: ' .
        '{"substitute": "...", "reason": "one short sentence on why it works", "amount": "suggested amount/ratio, short"}',
        $recipeTitle,
        $missingIngredient
    );

    $result = gemini_generate($prompt, 'You are a cooking substitution expert. You only ever respond with raw JSON, no markdown.', 0.4);

    if (!$result['ok']) {
        log_ai_request($userId, 'ingredient_substitution', 'error', $result['ms'], $result['error']);
        return ['ok' => false, 'error' => $result['error']];
    }

    $json = gemini_extract_json($result['text']);
    if (!$json || empty($json['substitute'])) {
        log_ai_request($userId, 'ingredient_substitution', 'error', $result['ms'], 'Unparseable JSON');
        return ['ok' => false, 'error' => 'Could not parse substitution suggestion.'];
    }

    log_ai_request($userId, 'ingredient_substitution', 'success', $result['ms']);
    return [
        'ok' => true,
        'substitute' => (string) $json['substitute'],
        'reason' => (string) ($json['reason'] ?? ''),
        'amount' => (string) ($json['amount'] ?? ''),
    ];
}

/**
 * 5. AI-Generated/Adapted Cooking Instructions.
 * Adapts a recipe's base steps around the user's available ingredients and
 * any substitute they've chosen. Returns plain step-by-step text, not chat.
 */
function gemini_adapt_instructions(string $recipeTitle, array $baseSteps, array $missingNames, ?string $substituteNote, ?int $userId = null): array
{
    if (!gemini_is_configured()) {
        return ['ok' => false, 'steps' => null, 'error' => 'not_configured'];
    }

    $stepsText = '';
    foreach ($baseSteps as $i => $s) {
        $stepsText .= ($i + 1) . '. ' . $s['title'] . ' — ' . $s['description'] . "\n";
    }

    $prompt = sprintf(
        "Recipe: %s\nOriginal steps:\n%s\nMissing ingredient(s): %s\nSubstitution being used: %s\n\n" .
        'Rewrite these as an adapted step-by-step cooking plan for the ingredients the user actually has. ' .
        'Respond with ONLY a JSON array of objects: [{"title": "short step title", "description": "1-2 sentence instruction"}]. ' .
        'Keep the same number of steps unless a step must be merged or removed because of the substitution.',
        $recipeTitle,
        $stepsText,
        $missingNames ? implode(', ', $missingNames) : 'none',
        $substituteNote ?: 'none'
    );

    $result = gemini_generate($prompt, 'You are PantryPal\'s cooking instruction adapter. You only output raw JSON step arrays, never chat text.', 0.4);

    if (!$result['ok']) {
        log_ai_request($userId, 'cooking_instructions', 'error', $result['ms'], $result['error']);
        return ['ok' => false, 'steps' => null, 'error' => $result['error']];
    }

    $json = gemini_extract_json($result['text']);
    if (!$json || !is_array($json)) {
        log_ai_request($userId, 'cooking_instructions', 'error', $result['ms'], 'Unparseable JSON');
        return ['ok' => false, 'steps' => null, 'error' => 'Could not parse adapted instructions.'];
    }

    log_ai_request($userId, 'cooking_instructions', 'success', $result['ms']);
    return ['ok' => true, 'steps' => $json, 'error' => null];
}

/**
 * Generate up to 5 brand-new Filipino recipes from a user's ingredient list.
 *
 * @param string[] $userIngredients  The ingredient names the user typed.
 * @param ?int $userId               For logging.
 * @return array{
 *   ok: bool,
 *   recipes: array,
 *   error: string|null,
 *   ms: int
 * }
 */
function gemini_generate_recipes(array $userIngredients, ?int $userId = null): array
{
    if (!gemini_is_configured()) {
        return ['ok' => false, 'recipes' => [], 'error' => 'not_configured', 'ms' => 0];
    }

    $clean = array_values(array_filter(array_map('trim', $userIngredients), fn($v) => $v !== ''));
    if (!$clean) {
        return ['ok' => false, 'recipes' => [], 'error' => 'No ingredients provided.', 'ms' => 0];
    }

    $prompt = "Ingredients available (Filipino home kitchen):\n- " . implode("\n- ", $clean) . "\n\n"
        . "Generate 3 to 5 distinct Filipino recipes that primarily use these ingredients. "
        . "Lean on classic Filipino dishes and flavors where they fit naturally (adobo, "
        . "sinigang, tinola, giniling, bistek, pancit, sinangag, torta, ginataang gulay, etc.). "
        . "Use Filipino ingredient names in parentheses after the English name when helpful "
        . "(e.g. \"Soy sauce (toyo)\", \"Vinegar (suka)\"). "
        . "Follow the JSON schema in your system instruction exactly. "
        . "Return only the raw JSON array.";

    $result = gemini_generate($prompt, GEMINI_RECIPE_GEN_SYSTEM, 0.6);

        if (!$result['ok']) {
        log_ai_request($userId, 'recipe_recommendation', 'error', $result['ms'], $result['error']);
        return ['ok' => false, 'recipes' => [], 'error' => $result['error'], 'ms' => $result['ms']];
    }


    $json = gemini_extract_json($result['text']);
    if (!is_array($json)) {
        log_ai_request($userId, 'recipe_recommendation', 'error', $result['ms'], 'Unparseable JSON from recipe generator');
        return ['ok' => false, 'recipes' => [], 'error' => 'AI returned unreadable data.', 'ms' => $result['ms']];
    }

    // Gemini sometimes wraps the array in an object like {"recipes": [...]}.
    if (isset($json['recipes']) && is_array($json['recipes'])) {
        $json = $json['recipes'];
    }

    // Only allow Filipino-aligned cuisine labels. Anything else gets normalized.
    $allowedCuisines = [
        'Filipino',
        'Filipino-Chinese',
        'Filipino-Spanish',
        'Filipino-Asian Fusion',
    ];

    // Validate + normalize each recipe. Anything malformed is discarded.
    $validated = [];
    foreach ($json as $r) {
        if (!is_array($r) || empty($r['title']) || empty($r['ingredients']) || empty($r['steps'])) {
            continue;
        }

        $difficulty = in_array($r['difficulty'] ?? '', ['Easy', 'Medium', 'Hard'], true)
            ? $r['difficulty'] : 'Easy';

        $cuisine = trim((string) ($r['cuisine'] ?? ''));
        if (!in_array($cuisine, $allowedCuisines, true)) {
            $cuisine = 'Filipino';
        }

        $ingredients = [];
        foreach ((array) $r['ingredients'] as $ing) {
            if (empty($ing['name'])) continue;
            $ingredients[] = [
                'name'         => (string) $ing['name'],
                'quantity_text'=> (string) ($ing['quantity_text'] ?? ''),
                'is_optional'  => !empty($ing['is_optional']),
            ];
        }

        $steps = [];
        foreach ((array) $r['steps'] as $st) {
            if (empty($st['description'])) continue;
            $steps[] = [
                'title'       => (string) ($st['title'] ?? 'Step'),
                'description' => (string) $st['description'],
            ];
        }

        if (!$ingredients || !$steps) continue;

        $validated[] = [
            'title'              => trim((string) $r['title']),
            'description'        => trim((string) ($r['description'] ?? '')),
            'cuisine'            => $cuisine,
            'difficulty'         => $difficulty,
            'prep_time_minutes'  => max(0, (int) ($r['prep_time_minutes'] ?? 10)),
            'cook_time_minutes'  => max(0, (int) ($r['cook_time_minutes'] ?? 20)),
            'servings'           => max(1, (int) ($r['servings'] ?? 2)),
            'dietary_info'       => isset($r['dietary_info']) && $r['dietary_info'] !== null
                                     ? trim((string) $r['dietary_info']) : null,
            'ingredients'        => $ingredients,
            'steps'              => $steps,
        ];
    }

    if (!$validated) {
        log_ai_request($userId, 'recipe_recommendation', 'error', $result['ms'], 'No valid recipes in AI response');
        return ['ok' => false, 'recipes' => [], 'error' => 'AI returned no usable recipes.', 'ms' => $result['ms']];
    }

    // Cap at 5 just in case the model ignored the "between 3 and 5" instruction.
    $validated = array_slice($validated, 0, 5);

    log_ai_request($userId, 'recipe_recommendation', 'success', $result['ms']);
    return ['ok' => true, 'recipes' => $validated, 'error' => null, 'ms' => $result['ms']];
}
