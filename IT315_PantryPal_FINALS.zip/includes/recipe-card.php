<?php
/**
 * Renders one recipe card.
 * $recipe needs: id, title, image_url, desc/description, cook_time_minutes (or time),
 * difficulty (or level), and optionally match (int 0-100).
 * $isSaved: bool — whether the current user has favorited this recipe.
 */
function render_recipe_card(array $recipe, bool $isSaved = false, bool $showMatch = true): void
{
    $match = $recipe['match'] ?? null;
    $desc = $recipe['description'] ?? ($recipe['desc'] ?? '');
    $time = isset($recipe['cook_time_minutes']) ? ($recipe['cook_time_minutes'] + ($recipe['prep_time_minutes'] ?? 0)) . ' min' : ($recipe['time'] ?? '');
    $level = $recipe['difficulty'] ?? ($recipe['level'] ?? '');
    ?>
    <article class="recipe-card">
      <div class="recipe-image">
        <a href="<?= url('recipe.php?id=' . (int) $recipe['id']) ?>">
          <img src="<?= e($recipe['image_url'] ?? '') ?>" alt="<?= e($recipe['title']) ?>">
        </a>
        <?php if ($showMatch && $match !== null): ?>
          <span class="badge badge-<?= match_badge_tone((int) $match) ?>"><?= (int) $match ?>% match</span>
        <?php endif; ?>
        <?php if (is_logged_in() && !is_admin()): ?>
          <form method="post" action="<?= url('api/toggle-favorite.php') ?>" class="favorite-toggle-form <?= $isSaved ? 'is-saved' : '' ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="recipe_id" value="<?= (int) $recipe['id'] ?>">
            <input type="hidden" name="redirect" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
            <button class="save-btn <?= $isSaved ? 'saved' : '' ?>" aria-label="Save recipe" type="submit"><?= icon('heart', 18) ?></button>
          </form>
        <?php endif; ?>
      </div>
      <div class="recipe-body">
        <div class="recipe-title-row">
          <h3><?= e($recipe['title']) ?></h3>
          <?= icon('arrow', 18) ?>
        </div>
        <p><?= e(mb_strimwidth($desc, 0, 110, '…')) ?></p>
        <div class="recipe-meta">
          <span><?= icon('timer', 17) ?><?= e($time) ?></span>
          <span><?= icon('chef', 17) ?><?= e($level) ?></span>
        </div>
        <a class="btn btn-secondary full" href="<?= url('recipe.php?id=' . (int) $recipe['id']) ?>">View recipe</a>
      </div>
    </article>
    <?php
}
