<?php
/**
 * Ports the Icon() component from the original Figma prototype 1:1 —
 * same stroke-based SVG paths, just rendered server-side.
 */
function icon(string $name, int $size = 20): string
{
    $paths = [
        'logo' => '<path d="M7 4h10l-1 16H8L7 4Z"/><path d="M5 4h14M10 8v8M14 8v8"/>',
        'home' => '<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10M9 20v-6h6v6"/>',
        'pantry' => '<path d="M5 3h14v18H5zM5 10h14M9 6h6M9 14h6M9 17h4"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        'book' => '<path d="M4 5a3 3 0 0 1 3-3h5v19H7a3 3 0 0 0-3 1V5ZM20 5a3 3 0 0 0-3-3h-5v19h5a3 3 0 0 1 3 1V5Z"/>',
        'heart' => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'logout' => '<path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10"/>',
        'sparkle' => '<path d="m12 3 1.3 3.7L17 8l-3.7 1.3L12 13l-1.3-3.7L7 8l3.7-1.3L12 3Z"/><path d="m18 14 .8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8L18 14Z"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'arrow' => '<path d="m9 18 6-6-6-6"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'timer' => '<circle cx="12" cy="13" r="8"/><path d="M9 2h6M12 5v8l4 2"/>',
        'chef' => '<path d="M6 10a4 4 0 1 1 2-7 5 5 0 0 1 8 0 4 4 0 1 1 2 7v10H6V10ZM6 15h12"/>',
        'database' => '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
        'chart' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'users' => '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M17 14a6 6 0 0 1 4 6"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M19 13.5v-3l-2-.5-.8-1.9 1-1.8-2.1-2.1-1.8 1-1.9-.8L10.5 2h-3L7 4.4l-1.9.8-1.8-1-2.1 2.1 1 1.8-.8 1.9-2 .5v3l2 .5.8 1.9-1 1.8 2.1 2.1 1.8-1 1.9.8.5 2.4h3l.5-2.4 1.9-.8 1.8 1 2.1-2.1-1-1.8.8-1.9 2-.5Z" transform="translate(2) scale(.83)"/>',
        'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'close' => '<path d="m6 6 12 12M18 6 6 18"/>',
        'trash' => '<path d="M4 7h16M9 3h6l1 4H8l1-4ZM7 7l1 14h8l1-14M10 11v6M14 11v6"/>',
        'edit' => '<path d="m4 16-1 5 5-1L20 8l-4-4L4 16Z"/><path d="m14 6 4 4"/>',
    ];
    $path = $paths[$name] ?? $paths['sparkle'];
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}
