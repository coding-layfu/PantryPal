<?php
/**
 * Renders the ingredient composer widget.
 * Call with: render_ingredient_composer(array $options)
 * Options:
 *   large        bool    use the bigger "match page" styling
 *   action       string  form action URL (defaults to match.php)
 *   chips        array   pre-filled chip names
 *   pantryNames  array   all current pantry ingredient names, for "Use all pantry ingredients"
 *   buttonLabel  string
 */
function render_ingredient_composer(array $options = []): void
{
    $large = !empty($options['large']);
    $action = $options['action'] ?? url('match.php');
    $chips = $options['chips'] ?? [];
    $pantryNames = $options['pantryNames'] ?? [];
    $buttonLabel = $options['buttonLabel'] ?? 'Find My Recipes';
    ?>
    <form method="post" action="<?= e($action) ?>">
      <?= csrf_field() ?>
      <div class="ingredient-composer <?= $large ? 'composer-large' : '' ?>">
        <div class="composer-label">
          <span><?= icon('sparkle', 17) ?> AI INGREDIENT UNDERSTANDING</span>
          <small>Type naturally—we'll organize it for you</small>
        </div>
        <div class="chip-input">
          <input type="text" placeholder="Add an ingredient...">
        </div>
        <input type="hidden" name="ingredients" value='<?= e(json_encode(array_values($chips))) ?>'>
        <div class="natural-row">
          <?= icon('edit', 18) ?>
          <input type="text" name="freetext" placeholder='Or type: "I have chicken, rice, eggs and garlic..."'>
        </div>
        <div class="composer-footer">
          <small class="composer-count"><?= icon('check', 15) ?> <?= count($chips) ?> ingredients recognized</small>
          <?php if (!empty($pantryNames)): ?>
            <button type="button" class="btn btn-secondary" data-use-all-pantry='<?= e(json_encode(array_values($pantryNames))) ?>'>Use all pantry ingredients</button>
          <?php endif; ?>
          <button type="submit" class="btn btn-primary"><?= icon('sparkle', 18) ?><span><?= e($buttonLabel) ?></span></button>
        </div>
      </div>
    </form>
    <?php
}
