<?php
/**
 * Data-access helpers around recipes, their ingredients/steps, and the
 * PHP/MySQL side of ingredient matching (see calculate_match() in
 * functions.php for the actual percentage math).
 */

function get_user_pantry_items(int $userId): array
{
    $stmt = db()->prepare(
        'SELECT p.*, c.name AS category_name FROM pantry_items p
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.user_id = ? ORDER BY p.created_at DESC'
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function get_user_pantry_names(int $userId): array
{
    $stmt = db()->prepare('SELECT custom_name FROM pantry_items WHERE user_id = ?');
    $stmt->execute([$userId]);
    return array_column($stmt->fetchAll(), 'custom_name');
}

function get_recipe_ingredients(int $recipeId): array
{
    $stmt = db()->prepare(
        "SELECT
            ri.ingredient_id,
            COALESCE(i.name, ri.custom_name) AS name,
            ri.custom_name,
            ri.quantity_text,
            ri.is_optional
         FROM recipe_ingredients ri
         LEFT JOIN ingredients i ON i.id = ri.ingredient_id
         WHERE ri.recipe_id = ?
         ORDER BY ri.display_order ASC, ri.id ASC"
    );
    $stmt->execute([$recipeId]);
    return $stmt->fetchAll();
}

function get_recipe_steps(int $recipeId): array
{
    $stmt = db()->prepare('SELECT id, title, description FROM recipe_steps WHERE recipe_id = ? ORDER BY step_order ASC');
    $stmt->execute([$recipeId]);
    return $stmt->fetchAll();
}

function get_recipe(int $id): ?array
{
    $stmt = db()->prepare('SELECT r.*, c.name AS category_name FROM recipes r LEFT JOIN categories c ON c.id = r.category_id WHERE r.id = ?');
    $stmt->execute([$id]);
    $r = $stmt->fetch();
    return $r ?: null;
}

function get_published_recipes(?string $search = null, ?string $difficulty = null, ?string $sort = null, int $limit = 200): array
{
    $sql = 'SELECT r.*, c.name AS category_name FROM recipes r LEFT JOIN categories c ON c.id = r.category_id WHERE r.status = "published"';
    $params = [];

    if ($search) {
        $sql .= ' AND (r.title LIKE ? OR r.description LIKE ? OR r.cuisine LIKE ?)';
        $like = '%' . $search . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }
    if ($difficulty) {
        $sql .= ' AND r.difficulty = ?';
        $params[] = $difficulty;
    }

    $sql .= match ($sort) {
        'time' => ' ORDER BY (r.prep_time_minutes + r.cook_time_minutes) ASC',
        'newest' => ' ORDER BY r.created_at DESC',
        default => ' ORDER BY r.title ASC',
    };
    $sql .= ' LIMIT ' . (int) $limit;

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Computes DB-side match percentages for a set of recipes against the
 * user's ingredient list. Returns recipes sorted by match desc, each with
 * 'match', 'have', 'missing' keys added.
 *
 * @param array $recipes Rows from recipes table (must include 'id')
 * @param string[] $userIngredientNames
 */
function attach_match_scores(array $recipes, array $userIngredientNames): array
{
    if (empty($userIngredientNames)) {
        foreach ($recipes as &$r) {
            $r['match'] = 0;
            $r['have'] = [];
            $r['missing'] = [];
        }
        unset($r);
        return $recipes;
    }

    foreach ($recipes as &$r) {
        $ri = get_recipe_ingredients((int) $r['id']);
        $result = calculate_match($userIngredientNames, $ri);
        $r['match'] = $result['percent'];
        $r['have'] = $result['have'];
        $r['missing'] = $result['missing'];
    }
    unset($r);

    usort($recipes, fn($a, $b) => $b['match'] <=> $a['match']);
    return $recipes;
}

function get_favorite_recipe_ids(int $userId): array
{
    $stmt = db()->prepare('SELECT recipe_id FROM favorites WHERE user_id = ?');
    $stmt->execute([$userId]);
    return array_map('intval', array_column($stmt->fetchAll(), 'recipe_id'));
}

function is_recipe_favorited(int $userId, int $recipeId): bool
{
    $stmt = db()->prepare('SELECT 1 FROM favorites WHERE user_id = ? AND recipe_id = ? LIMIT 1');
    $stmt->execute([$userId, $recipeId]);
    return (bool) $stmt->fetch();
}

/**
 * Returns all recipes authored by a specific user (community recipes).
 * Includes drafts and published — the owner can see both.
 */
function get_user_recipes(int $userId): array
{
    $stmt = db()->prepare(
        'SELECT r.*, c.name AS category_name
         FROM recipes r
         LEFT JOIN categories c ON c.id = r.category_id
         WHERE r.created_by = ? AND r.is_community = 1
         ORDER BY r.updated_at DESC'
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Fetch one user-authored recipe, but only if it belongs to this user.
 * Admins can pass $allowAdmin = true to bypass the ownership check.
 * Returns null if not found / not owned.
 */
function get_user_recipe(int $recipeId, int $userId, bool $allowAdmin = false): ?array
{
    $sql = 'SELECT r.*, c.name AS category_name
            FROM recipes r
            LEFT JOIN categories c ON c.id = r.category_id
            WHERE r.id = ?';
    $params = [$recipeId];

    if (!$allowAdmin) {
        $sql .= ' AND r.created_by = ? AND r.is_community = 1';
        $params[] = $userId;
    }

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $r = $stmt->fetch();
    return $r ?: null;
}

/**
 * Counts the user's own recipes, for badges / dashboard stats.
 * $publishedOnly = true counts only recipes visible to other users.
 */
function count_user_recipes(int $userId, bool $publishedOnly = false): int
{
    $sql = 'SELECT COUNT(*) c FROM recipes WHERE created_by = ? AND is_community = 1';
    if ($publishedOnly) {
        $sql .= " AND status = 'published'";
    }
    $stmt = db()->prepare($sql);
    $stmt->execute([$userId]);
    return (int) ($stmt->fetch()['c'] ?? 0);
}