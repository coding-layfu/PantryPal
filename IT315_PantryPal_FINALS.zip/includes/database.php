<?php
/**
 * Single shared PDO connection. Uses prepared statements everywhere else
 * in the app — this file only opens the connection.
 */

function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            DB_HOST,
            DB_PORT,
            DB_NAME
        );

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);

            // Force the database session to match the PHP timezone.
            // Without this, MySQL's NOW() / CURRENT_TIMESTAMP uses the
            // server's default (often UTC), which makes timestamps drift
            // by hours from what PHP writes and reads.
            $pdo->exec("SET time_zone = '+08:00'");
        } catch (PDOException $e) {
            http_response_code(500);
            if (defined('APP_ENV') && APP_ENV === 'local') {
                die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
            }
            die('PantryPal cannot connect to the database right now. Please try again later.');
        }
    }

    return $pdo;
}
