<?php
/**
 * Mirrors the `userNav` / `adminNav` arrays from the original Figma prototype.
 * `icon` keys map to the <use> paths defined in includes/icons.php.
 */

function user_nav_items(): array
{
    return [
        ['id' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'home', 'href' => 'dashboard.php'],
        ['id' => 'pantry', 'label' => 'My Pantry', 'icon' => 'pantry', 'href' => 'pantry.php'],
        ['id' => 'match', 'label' => 'Find Recipes', 'icon' => 'sparkle', 'href' => 'match.php'],
        ['id' => 'browse', 'label' => 'Browse Recipes', 'icon' => 'book', 'href' => 'browse.php'],
        ['id' => 'my-recipes', 'label' => 'My Recipes', 'icon' => 'chef', 'href' => 'my-recipes.php'],
        ['id' => 'favorites', 'label' => 'Favorites', 'icon' => 'heart', 'href' => 'favorites.php'],
        ['id' => 'history', 'label' => 'History', 'icon' => 'clock', 'href' => 'history.php'],
        ['id' => 'profile', 'label' => 'Profile', 'icon' => 'user', 'href' => 'profile.php'],
    ];
}

function admin_nav_items(): array
{
    return [
        ['id' => 'admin-dashboard', 'label' => 'Dashboard', 'icon' => 'home', 'href' => 'admin/dashboard.php'],
        ['id' => 'admin-recipes', 'label' => 'Recipes', 'icon' => 'book', 'href' => 'admin/recipes.php'],
        ['id' => 'admin-ingredients', 'label' => 'Ingredients', 'icon' => 'pantry', 'href' => 'admin/ingredients.php'],
        ['id' => 'admin-categories', 'label' => 'Categories', 'icon' => 'chart', 'href' => 'admin/categories.php'],
        ['id' => 'admin-users', 'label' => 'Users', 'icon' => 'users', 'href' => 'admin/users.php'],
        ['id' => 'admin-ai', 'label' => 'AI Activity', 'icon' => 'sparkle', 'href' => 'admin/ai-activity.php'],
        ['id' => 'admin-reports', 'label' => 'Reports', 'icon' => 'chart', 'href' => 'admin/reports.php'],
    ];
}
