<?php
    
// ---------------------------------------------------------------------------
// DATABASE
// ---------------------------------------------------------------------------
define('DB_HOST', 'sql313.infinityfree.com');       
define('DB_PORT', '3306');
define('DB_NAME', 'if0_43021861_PantryPal');
define('DB_USER', 'if0_43021861');
define('DB_PASS', 'dT9u8ZXeyrhmWei');

// ---------------------------------------------------------------------------
// GOOGLE GEMINI API
// ---------------------------------------------------------------------------
define('GEMINI_API_KEY', 'AQ.Ab8RN6JoIs5Kwu7YpAKmeTSjvlj81sTOWUC77hOp4h0f0e4ylg');
define('GEMINI_MODEL', 'gemini-3.5-flash-lite');
define('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta/models/');
define('GEMINI_TIMEOUT_SECONDS', 12);

// ---------------------------------------------------------------------------
// APP
// ---------------------------------------------------------------------------
define('APP_NAME', 'PantryPal');
define('APP_ENV', 'local'); // 'local' shows PHP errors, 'production' hides them
define('APP_URL', 'https://pantrypal.free.nf'); 
define('APP_SECRET', '7f91c0e4b9a64d9f8c13e9a1b5d62f904i8d31a7d9b26f4c8e1p732d5b2f51c');
