<?php
/**
 * PantryPal configuration.
 *
 * 1. Copy this file to "config.php" in this same folder.
 * 2. Fill in your real database credentials and Gemini API key below.
 * 3. config.php is already in .gitignore-style exclusion (see README) — never
 *    commit or upload config.php anywhere public except your own server.
 *
 * config.php is loaded once by config/bootstrap.php and is NOT reachable
 * directly from the browser (see the .htaccess in this folder).
 */

// ---------------------------------------------------------------------------
// DATABASE
// ---------------------------------------------------------------------------
define('DB_HOST', 'localhost');       // e.g. sql123.infinityfree.com
define('DB_PORT', '3306');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_username');
define('DB_PASS', 'your_database_password');

// ---------------------------------------------------------------------------
// GOOGLE GEMINI API
// ---------------------------------------------------------------------------
// Paste your own key below. Never put this key in JavaScript, HTML, or any
// publicly-readable file — it is only ever read from PHP on the server.
define('GEMINI_API_KEY', '');

// Model name — change here any time Google updates/renames the model.
define('GEMINI_MODEL', 'gemini-2.0-flash');

// Base endpoint. Only change this if Google changes the API version.
define('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta/models/');

// Seconds to wait for Gemini before giving up and falling back to
// database-only matching.
define('GEMINI_TIMEOUT_SECONDS', 12);

// ---------------------------------------------------------------------------
// APP
// ---------------------------------------------------------------------------
define('APP_NAME', 'PantryPal');
define('APP_ENV', 'production'); // 'local' shows PHP errors, 'production' hides them
define('APP_URL', 'https://pantrypal.free.nf'); // no trailing slash

// A random long string used to sign session/CSRF tokens. Change this to your
// own random value before going live.
define('APP_SECRET', 'change-this-to-a-long-random-string');
