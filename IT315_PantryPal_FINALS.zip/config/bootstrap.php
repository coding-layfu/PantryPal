<?php
/**
 * Loaded at the top of every entry-point script.
 * Sets up config, session, error handling, and the PDO connection.
 */

if (!defined('PANTRYPAL_BOOTSTRAPPED')) {
    define('PANTRYPAL_BOOTSTRAPPED', true);

    define('ROOT_PATH', dirname(__DIR__));

    $configFile = __DIR__ . '/config.php';
    if (!file_exists($configFile)) {
        http_response_code(500);
        die(
            'PantryPal is not configured yet. Copy config/config.sample.php to ' .
            'config/config.php and fill in your database and Gemini API details.'
        );
    }
    require_once $configFile;

    if (defined('APP_ENV') && APP_ENV === 'local') {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(0);
        ini_set('display_errors', '0');
    }

    date_default_timezone_set('Asia/Manila');

    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    require_once ROOT_PATH . '/includes/database.php';
    require_once ROOT_PATH . '/includes/functions.php';
    require_once ROOT_PATH . '/includes/csrf.php';
    require_once ROOT_PATH . '/includes/auth.php';
    require_once ROOT_PATH . '/includes/gemini.php';
    require_once ROOT_PATH . '/includes/recipes.php';
    require_once ROOT_PATH . '/includes/admin-data.php';
    require_once ROOT_PATH . '/includes/icons.php';
}
