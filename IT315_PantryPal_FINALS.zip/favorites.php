<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/recipe-card.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];

$stmt = db()->prepare(
    'SELECT r.*, c.name AS category_name FROM favorites f
     JOIN recipes r ON r.id = f.recipe_id
     LEFT JOIN categories c ON c.id = r.category_id
     WHERE f.user_id = ? ORDER BY f.created_at DESC'
);
$stmt->execute([$userId]);
$favorites = $stmt->fetchAll();

$pantryNames = get_user_pantry_names($userId);
$favorites = attach_match_scores($favorites, $pantryNames);

$pageTitle = 'Favorites';
$activeNav = 'favorites';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">YOUR COOKBOOK</span>
      <h1>Favorite Recipes</h1>
      <p>The recipes you loved, saved in one cozy place.</p>
    </div>
  </div>
  <?php if (!$favorites): ?>
    <div class="empty-state"><strong>No favorites yet</strong><p>Save recipes you love from any recipe page to see them here.</p></div>
  <?php else: ?>
  <div class="recipe-grid">
    <?php foreach ($favorites as $r): render_recipe_card($r, true); endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
