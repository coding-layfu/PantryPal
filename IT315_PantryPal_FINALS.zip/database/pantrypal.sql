-- =============================================================
-- PantryPal — Database Schema
-- Import this whole file directly into phpMyAdmin (or via CLI:
-- mysql -u USER -p DBNAME < pantrypal.sql)
-- =============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -------------------------------------------------------------
-- users
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role (role),
  INDEX idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- user_preferences (1:1 with users)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_preferences (
  user_id INT UNSIGNED PRIMARY KEY,
  dietary_preference VARCHAR(100) NOT NULL DEFAULT 'No preference',
  favorite_cuisine VARCHAR(100) NOT NULL DEFAULT 'Asian-inspired',
  cooking_skill VARCHAR(50) NOT NULL DEFAULT 'Intermediate',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_prefs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- categories (shared table; `type` separates recipe categories
-- like Dinner/Breakfast from ingredient categories like Meat/Grains)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  type ENUM('recipe','ingredient') NOT NULL DEFAULT 'recipe',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_category_type (type, name),
  UNIQUE KEY uniq_category_slug (type, slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- ingredients (master ingredient catalog)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingredients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL UNIQUE,
  category_id INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ingredient_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_ingredient_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- recipes
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recipes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(220) NOT NULL UNIQUE,
  description TEXT NULL,
  image_url VARCHAR(500) NULL,
  prep_time_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  cook_time_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  servings SMALLINT UNSIGNED NOT NULL DEFAULT 2,
  difficulty ENUM('Easy','Medium','Hard') NOT NULL DEFAULT 'Easy',
  cuisine VARCHAR(100) NULL,
  dietary_info VARCHAR(150) NULL,
  category_id INT UNSIGNED NULL,
  status ENUM('published','draft') NOT NULL DEFAULT 'published',
  created_by INT UNSIGNED NULL,
  is_community TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_recipe_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  CONSTRAINT fk_recipe_author FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_recipe_status (status),
  INDEX idx_recipe_difficulty (difficulty),
  INDEX idx_recipe_community (is_community),
  FULLTEXT KEY ft_recipe_title (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- recipe_ingredients (many-to-many, with quantity + optional flag)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recipe_ingredients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  recipe_id INT UNSIGNED NOT NULL,
  ingredient_id INT UNSIGNED NULL,
  custom_name VARCHAR(150) NULL,
  quantity_text VARCHAR(100) NULL,
  is_optional TINYINT(1) NOT NULL DEFAULT 0,
  display_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT fk_ri_recipe FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
  CONSTRAINT fk_ri_ingredient FOREIGN KEY (ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE,
  CONSTRAINT chk_ri_has_ingredient CHECK (
    (ingredient_id IS NOT NULL AND custom_name IS NULL) OR
    (ingredient_id IS NULL AND custom_name IS NOT NULL)
  ),
  INDEX idx_ri_custom_name (custom_name),
  UNIQUE KEY uniq_recipe_ingredient (recipe_id, ingredient_id),
  INDEX idx_ri_ingredient (ingredient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- recipe_steps
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recipe_steps (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  recipe_id INT UNSIGNED NOT NULL,
  step_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  title VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  CONSTRAINT fk_step_recipe FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
  INDEX idx_step_recipe (recipe_id, step_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- pantry_items (per-user pantry)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pantry_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  ingredient_id INT UNSIGNED NULL,
  custom_name VARCHAR(150) NOT NULL,
  quantity_text VARCHAR(100) NULL,
  category_id INT UNSIGNED NULL,
  expires_on DATE NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pantry_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_pantry_ingredient FOREIGN KEY (ingredient_id) REFERENCES ingredients(id) ON DELETE SET NULL,
  CONSTRAINT fk_pantry_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_pantry_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- favorites
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS favorites (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  recipe_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_fav_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_fav_recipe FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
  UNIQUE KEY uniq_user_recipe (user_id, recipe_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- search_history
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS search_history (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  ingredients_text VARCHAR(500) NOT NULL,
  matched_recipe_ids TEXT NULL,
  result_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  best_match_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_history_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_history_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- ai_requests (admin AI monitoring)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ai_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  feature ENUM('ingredient_understanding','recipe_matching','recipe_recommendation','ingredient_substitution','cooking_instructions') NOT NULL,
  status ENUM('success','error') NOT NULL,
  response_time_ms INT UNSIGNED NULL,
  error_message VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ai_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_ai_feature (feature),
  INDEX idx_ai_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================
-- PantryPal — Seed / Demo Data
-- Realistic sample data so the app is usable immediately after import.
-- Demo credentials are documented in README.md.
-- =============================================================

-- -------------------------------------------------------------
-- Users
-- Passwords below are bcrypt hashes. Plain-text demo passwords
-- (see README.md): Admin@123 / Maria@123 / Jamie@123 / Chris@123
-- -------------------------------------------------------------
INSERT INTO users (id, full_name, email, password_hash, role, status, created_at) VALUES
(1, 'Alex Rivera', 'alex@pantrypal.com', '$2y$10$PpC2TTrtEnuU.HAxKbGJiOxY/dmgQQnnyaK63VHpHOywkiyXJOyr6', 'admin', 'active', '2026-07-10 09:00:00'),
(2, 'Maria Santos', 'maria@example.com', '$2y$10$V0A940NJkFuL1hepe3z4JOdi5MRF4O1DcTpDMQxKFf3JrH9nTocnG', 'user', 'active', '2026-09-27 08:15:00'),
(3, 'Jamie Lee', 'jamie@example.com', '$2y$10$xlEzM1lnY6c6.IoxzfT53.wU1k/Lo8Ag50Gpb.o0d5Wje78zWuXLq', 'user', 'active', '2026-09-25 14:20:00'),
(4, 'Chris Tan', 'chris@example.com', '$2y$10$kJu.NaSg00WoT6/oXE.H/ebsxhBztD088hzImSK7u6ala0HR9qnDy', 'user', 'inactive', '2026-09-18 11:05:00');

INSERT INTO user_preferences (user_id, dietary_preference, favorite_cuisine, cooking_skill) VALUES
(2, 'No preference', 'Asian-inspired', 'Intermediate'),
(3, 'Vegetarian', 'Italian-inspired', 'Beginner'),
(4, 'No preference', 'American', 'Beginner');

-- -------------------------------------------------------------
-- Categories
-- -------------------------------------------------------------
INSERT INTO categories (id, name, slug, type) VALUES
(1, 'Breakfast', 'breakfast', 'recipe'),
(2, 'Lunch', 'lunch', 'recipe'),
(3, 'Dinner', 'dinner', 'recipe'),
(4, 'Dessert', 'dessert', 'recipe'),
(5, 'Meat', 'meat', 'ingredient'),
(6, 'Vegetables', 'vegetables', 'ingredient'),
(7, 'Grains', 'grains', 'ingredient'),
(8, 'Dairy & Protein', 'dairy-protein', 'ingredient'),
(9, 'Sauces & Condiments', 'sauces-condiments', 'ingredient'),
(10, 'Herbs & Spices', 'herbs-spices', 'ingredient'),
(11, 'Other', 'other', 'ingredient');

-- -------------------------------------------------------------
-- Ingredients
-- -------------------------------------------------------------
INSERT INTO ingredients (id, name, category_id) VALUES
(1, 'Chicken breast', 5), (2, 'Ground beef', 5), (3, 'Bacon', 5), (4, 'Shrimp', 5), (5, 'Tuna', 5),
(6, 'Jasmine rice', 7), (7, 'Cooked rice', 7), (8, 'Noodles', 7), (9, 'Pasta', 7), (10, 'Bread', 7),
(11, 'Eggs', 8), (12, 'Milk', 8), (13, 'Heavy cream', 8), (14, 'Parmesan cheese', 8), (15, 'Cheese', 8), (16, 'Butter', 8),
(17, 'Garlic', 6), (18, 'Green onion', 6), (19, 'Onion', 6), (20, 'Carrots', 6), (21, 'Bell pepper', 6),
(22, 'Broccoli', 6), (23, 'Spinach', 6), (24, 'Potatoes', 6), (25, 'Tomatoes', 6), (34, 'Lemon', 6),
(26, 'Ginger', 10), (27, 'Basil', 10), (28, 'Black pepper', 10), (29, 'Salt', 10),
(30, 'Soy sauce', 9), (31, 'Mayonnaise', 9), (32, 'Olive oil', 9), (33, 'Vegetable oil', 9),
(35, 'Cornstarch', 11), (36, 'Chicken broth', 11);

-- -------------------------------------------------------------
-- Recipes
-- -------------------------------------------------------------
INSERT INTO recipes (id, title, slug, description, image_url, prep_time_minutes, cook_time_minutes, servings, difficulty, cuisine, dietary_info, category_id, status, created_by, created_at) VALUES
(1, 'Chicken Fried Rice', 'chicken-fried-rice', 'A comforting, savory fried rice made with tender chicken, fluffy grains and a rich soy-garlic finish.', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=1200&q=85', 10, 15, 4, 'Easy', 'Asian-inspired', NULL, 3, 'published', 1, '2026-08-01 10:00:00'),
(2, 'Garlic Egg Rice Bowl', 'garlic-egg-rice-bowl', 'Comforting garlic rice topped with a silky egg and fresh herbs — ready before your coffee finishes brewing.', 'https://images.unsplash.com/photo-1601226809638-4ab838bb4d97?auto=format&fit=crop&w=1200&q=85', 5, 15, 2, 'Easy', 'Asian-inspired', NULL, 1, 'draft', 1, '2026-08-03 09:30:00'),
(3, 'Soy Chicken Noodles', 'soy-chicken-noodles', 'Glossy noodles tossed with soy-glazed chicken and crisp vegetables for a fast weeknight dinner.', 'https://images.unsplash.com/photo-1658346368601-869ae3ded6d1?auto=format&fit=crop&w=900&q=85', 15, 20, 3, 'Medium', 'Asian-inspired', NULL, 3, 'published', 1, '2026-08-05 18:00:00'),
(4, 'Creamy Tuscan Pasta', 'creamy-tuscan-pasta', 'Rich, garlicky cream sauce with wilted spinach and parmesan, tossed through pasta.', 'https://images.unsplash.com/photo-1619683548293-c74defe8d5d2?auto=format&fit=crop&w=900&q=85', 10, 30, 4, 'Medium', 'Italian-inspired', 'Vegetarian option available', 3, 'published', 1, '2026-08-08 19:00:00'),
(5, 'Vegetable Stir Fry', 'vegetable-stir-fry', 'A quick, colorful stir fry that turns whatever vegetables you have into a satisfying meal.', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=1200&q=85', 10, 10, 2, 'Easy', 'Asian-inspired', 'Vegetarian, Vegan', 2, 'published', 1, '2026-08-10 12:00:00'),
(6, 'Garlic Butter Shrimp Pasta', 'garlic-butter-shrimp-pasta', 'Juicy shrimp in a bright garlic-butter-lemon sauce over pasta — restaurant flavor, weeknight speed.', 'https://images.unsplash.com/photo-1601226809638-4ab838bb4d97?auto=format&fit=crop&w=1200&q=85', 10, 20, 3, 'Medium', 'Italian-inspired', NULL, 3, 'published', 1, '2026-08-14 19:30:00'),
(7, 'Beef Tapa Rice Bowl', 'beef-tapa-rice-bowl', 'A Filipino breakfast favorite: garlicky beef strips served over rice with a fried egg.', 'https://images.unsplash.com/photo-1658346368601-869ae3ded6d1?auto=format&fit=crop&w=900&q=85', 15, 20, 4, 'Medium', 'Filipino', NULL, 1, 'published', 1, '2026-08-18 07:00:00'),
(8, 'Tuna Sandwich Melt', 'tuna-sandwich-melt', 'A pantry-staple lunch: creamy tuna salad melted with cheese between toasted bread.', 'https://images.unsplash.com/photo-1619683548293-c74defe8d5d2?auto=format&fit=crop&w=900&q=85', 10, 5, 2, 'Easy', 'American', NULL, 2, 'published', 1, '2026-08-20 12:30:00'),
(9, 'Cheesy Potato Bake', 'cheesy-potato-bake', 'Layers of tender potatoes baked in a cheesy, garlicky milk sauce until golden.', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=1200&q=85', 15, 45, 6, 'Easy', 'American', 'Vegetarian', 3, 'published', 1, '2026-08-22 17:00:00'),
(10, 'Egg Drop Soup', 'egg-drop-soup', 'A light, silky soup with ribbons of egg — ready in under 20 minutes with pantry staples.', 'https://images.unsplash.com/photo-1601226809638-4ab838bb4d97?auto=format&fit=crop&w=1200&q=85', 5, 10, 2, 'Easy', 'Asian-inspired', NULL, 2, 'published', 1, '2026-08-25 12:00:00');

-- -------------------------------------------------------------
-- Recipe ingredients
-- -------------------------------------------------------------
INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity_text, is_optional, display_order) VALUES
-- Chicken Fried Rice
(1, 1, '400 g', 0, 1), (1, 7, '3 cups', 0, 2), (1, 11, '2 large', 0, 3), (1, 17, '3 cloves', 0, 4), (1, 30, '3 tbsp', 0, 5), (1, 18, '2 stalks', 1, 6),
-- Garlic Egg Rice Bowl
(2, 7, '2 cups', 0, 1), (2, 11, '2 large', 0, 2), (2, 17, '4 cloves', 0, 3), (2, 16, '1 tbsp', 0, 4), (2, 30, '1 tbsp', 0, 5), (2, 18, '1 stalk', 1, 6),
-- Soy Chicken Noodles
(3, 1, '300 g', 0, 1), (3, 8, '200 g', 0, 2), (3, 30, '3 tbsp', 0, 3), (3, 17, '2 cloves', 0, 4), (3, 26, '1 tsp', 0, 5), (3, 21, '1 piece', 1, 6),
-- Creamy Tuscan Pasta
(4, 9, '300 g', 0, 1), (4, 13, '1 cup', 0, 2), (4, 14, '1/2 cup', 0, 3), (4, 17, '3 cloves', 0, 4), (4, 23, '2 cups', 0, 5), (4, 25, '1/2 cup, diced', 1, 6),
-- Vegetable Stir Fry
(5, 22, '1 cup', 0, 1), (5, 20, '1 cup, sliced', 0, 2), (5, 21, '1 piece', 0, 3), (5, 17, '2 cloves', 0, 4), (5, 30, '2 tbsp', 0, 5), (5, 33, '1 tbsp', 0, 6),
-- Garlic Butter Shrimp Pasta
(6, 4, '300 g', 0, 1), (6, 9, '250 g', 0, 2), (6, 16, '3 tbsp', 0, 3), (6, 17, '4 cloves', 0, 4), (6, 34, '1 piece', 0, 5), (6, 28, '1 tsp', 1, 6),
-- Beef Tapa Rice Bowl
(7, 2, '400 g', 0, 1), (7, 7, '3 cups', 0, 2), (7, 17, '5 cloves', 0, 3), (7, 30, '4 tbsp', 0, 4), (7, 11, '4 large', 0, 5), (7, 19, '1 piece', 1, 6),
-- Tuna Sandwich Melt
(8, 5, '1 can', 0, 1), (8, 10, '4 slices', 0, 2), (8, 31, '3 tbsp', 0, 3), (8, 15, '4 slices', 0, 4), (8, 19, '2 tbsp, diced', 1, 5),
-- Cheesy Potato Bake
(9, 24, '1 kg', 0, 1), (9, 15, '1.5 cups', 0, 2), (9, 12, '1 cup', 0, 3), (9, 16, '2 tbsp', 0, 4), (9, 17, '2 cloves', 1, 5),
-- Egg Drop Soup
(10, 11, '2 large', 0, 1), (10, 36, '4 cups', 0, 2), (10, 35, '1 tbsp', 0, 3), (10, 18, '2 stalks', 1, 4), (10, 26, '1 tsp', 1, 5);

-- -------------------------------------------------------------
-- Recipe steps
-- -------------------------------------------------------------
INSERT INTO recipe_steps (recipe_id, step_order, title, description) VALUES
(1,1,'Prepare the rice','Break up any clumps in your cooked rice. Chilled rice works best, but freshly cooked rice can be spread on a plate to cool.'),
(1,2,'Cook the chicken','Heat a large pan over medium-high heat. Cook the chicken for 6-7 minutes until golden and fully cooked, then set aside.'),
(1,3,'Build the aromatics','In the same pan, add garlic and cook for 30 seconds until fragrant.'),
(1,4,'Scramble the eggs','Push everything aside, add the eggs and gently scramble until just set.'),
(1,5,'Bring it together','Add rice, chicken and soy sauce. Toss over high heat for 3-4 minutes until evenly combined and hot.'),
(1,6,'Serve and enjoy','Taste, adjust seasoning and serve immediately while warm.'),

(2,1,'Cook the rice','Warm the cooked rice in a pan with half the butter until heated through.'),
(2,2,'Fry the garlic','Push rice aside, add remaining butter and garlic, and fry until golden and fragrant.'),
(2,3,'Fry the eggs','Push rice to one side of the pan and fry the eggs sunny-side up in the same pan.'),
(2,4,'Assemble and serve','Drizzle with soy sauce and top the rice with the fried eggs and green onion.'),

(3,1,'Cook the noodles','Boil the noodles according to package directions, then drain and set aside.'),
(3,2,'Sear the chicken','Slice the chicken thin and sear in a hot pan for 5-6 minutes until cooked through.'),
(3,3,'Build the sauce','Add garlic and ginger to the pan and cook for 30 seconds, then stir in soy sauce.'),
(3,4,'Toss it together','Add the noodles to the pan and toss to coat evenly in the sauce.'),
(3,5,'Finish and serve','Top with sliced bell pepper if using, and serve hot.'),

(4,1,'Cook the pasta','Boil the pasta in salted water until al dente, then reserve a cup of pasta water and drain.'),
(4,2,'Build the sauce','In a large pan, sauté garlic in butter, then stir in heavy cream and bring to a gentle simmer.'),
(4,3,'Add the cheese','Stir in parmesan cheese until melted and the sauce thickens slightly.'),
(4,4,'Wilt the spinach','Add spinach and cook until just wilted, about 2 minutes.'),
(4,5,'Combine and serve','Toss the pasta through the sauce, loosening with pasta water as needed, and serve immediately.'),

(5,1,'Prep the vegetables','Cut all vegetables into similar-sized pieces for even cooking.'),
(5,2,'Heat the wok','Heat vegetable oil in a wok or large pan over high heat until shimmering.'),
(5,3,'Stir fry','Add garlic, then vegetables, stir-frying for 4-5 minutes until crisp-tender.'),
(5,4,'Season and serve','Add soy sauce, toss to coat, and serve immediately over rice.'),

(6,1,'Cook the pasta','Boil the pasta until al dente, reserving some pasta water before draining.'),
(6,2,'Sear the shrimp','Season shrimp and sear in a hot pan for 1-2 minutes per side until pink; set aside.'),
(6,3,'Make the garlic butter','In the same pan, melt butter and cook garlic until fragrant, about 30 seconds.'),
(6,4,'Combine','Return shrimp to the pan, add lemon juice and pasta, tossing to coat.'),
(6,5,'Serve','Finish with black pepper if using and serve right away.'),

(7,1,'Marinate the beef','Toss beef strips with garlic and soy sauce; let sit for at least 10 minutes.'),
(7,2,'Sear the beef','Cook the beef in a hot pan for 3-4 minutes per side until caramelized.'),
(7,3,'Fry the eggs','In a separate pan, fry the eggs to your liking.'),
(7,4,'Warm the rice','Warm the cooked rice, optionally frying with a little garlic.'),
(7,5,'Assemble the bowl','Serve the beef over rice topped with a fried egg and sliced onion if using.'),

(8,1,'Make the tuna salad','Mix drained tuna with mayonnaise and diced onion if using.'),
(8,2,'Assemble the sandwich','Spread the tuna mixture on bread and top with cheese slices.'),
(8,3,'Melt the cheese','Toast in a pan or oven until the bread is golden and the cheese is melted.'),
(8,4,'Slice and serve','Cut in half and serve warm.'),

(9,1,'Prep the potatoes','Slice the potatoes thinly and layer them in a baking dish.'),
(9,2,'Make the sauce','Warm milk with butter and garlic if using, then season to taste.'),
(9,3,'Layer and bake','Pour the sauce over the potatoes, top with cheese, and bake at 190°C (375°F) for about 40 minutes.'),
(9,4,'Check for doneness','Potatoes should be fork-tender and the top golden and bubbling.'),
(9,5,'Rest and serve','Let stand 5 minutes before serving.'),

(10,1,'Heat the broth','Bring chicken broth to a gentle simmer in a pot.'),
(10,2,'Thicken','Whisk cornstarch with a little water and stir into the simmering broth until slightly thickened.'),
(10,3,'Add the egg ribbons','Slowly drizzle in beaten eggs while stirring gently to form ribbons.'),
(10,4,'Finish and serve','Top with green onion and ginger if using, then serve hot.');

-- -------------------------------------------------------------
-- Pantry items (Maria Santos, user_id 2)
-- -------------------------------------------------------------
INSERT INTO pantry_items (user_id, ingredient_id, custom_name, quantity_text, category_id, expires_on, created_at) VALUES
(2, 1, 'Chicken breast', '500 g', 5, '2026-09-29', '2026-09-25 08:00:00'),
(2, 6, 'Jasmine rice', '1 kg', 7, NULL, '2026-09-20 08:00:00'),
(2, 11, 'Free-range eggs', '6 pieces', 8, '2026-10-05', '2026-09-25 08:00:00'),
(2, 17, 'Garlic', '1 bulb', 6, NULL, '2026-09-18 08:00:00'),
(2, 30, 'Soy sauce', '250 ml', 9, NULL, '2026-09-10 08:00:00'),
(2, 20, 'Carrots', '4 pieces', 6, '2026-10-02', '2026-09-24 08:00:00');

INSERT INTO pantry_items (user_id, ingredient_id, custom_name, quantity_text, category_id, expires_on, created_at) VALUES
(3, 9, 'Pasta', '500 g', 7, NULL, '2026-09-20 08:00:00'),
(3, 25, 'Tomatoes', '6 pieces', 6, '2026-10-01', '2026-09-24 08:00:00'),
(3, 27, 'Basil', '1 bunch', 10, '2026-09-30', '2026-09-24 08:00:00');

-- -------------------------------------------------------------
-- Favorites
-- -------------------------------------------------------------
INSERT INTO favorites (user_id, recipe_id, created_at) VALUES
(2, 1, '2026-09-26 20:00:00'),
(2, 4, '2026-09-20 19:00:00'),
(2, 6, '2026-09-15 19:30:00'),
(3, 4, '2026-09-24 12:00:00');

-- -------------------------------------------------------------
-- Search history
-- -------------------------------------------------------------
INSERT INTO search_history (user_id, ingredients_text, matched_recipe_ids, result_count, best_match_percent, created_at) VALUES
(2, 'Chicken, rice, eggs, garlic', '[1,3,7]', 3, 94, '2026-09-27 14:34:00'),
(2, 'Potatoes, cheese, milk', '[9,4,1,3,7]', 5, 87, '2026-09-26 18:12:00'),
(2, 'Pasta, tomatoes, basil', '[4,6,1,3,5,7,9,10]', 8, 91, '2026-09-24 11:40:00'),
(2, 'Tuna, bread, mayonnaise', '[8,2,1,10]', 4, 82, '2026-09-20 19:18:00'),
(3, 'Pasta, spinach, garlic', '[4,6]', 2, 88, '2026-09-25 09:00:00');

-- -------------------------------------------------------------
-- AI request activity (for admin monitoring / reports)
-- -------------------------------------------------------------
INSERT INTO ai_requests (user_id, feature, status, response_time_ms, error_message, created_at) VALUES
(2, 'recipe_matching', 'success', 1400, NULL, '2026-09-27 14:34:00'),
(3, 'ingredient_understanding', 'success', 800, NULL, '2026-09-27 14:31:00'),
(4, 'ingredient_substitution', 'success', 1100, NULL, '2026-09-27 14:24:00'),
(2, 'cooking_instructions', 'success', 1800, NULL, '2026-09-27 14:18:00'),
(2, 'recipe_matching', 'success', 1250, NULL, '2026-09-26 18:12:00'),
(3, 'recipe_matching', 'success', 1600, NULL, '2026-09-25 09:00:00'),
(2, 'ingredient_understanding', 'error', 5200, 'Connection timed out', '2026-09-24 11:39:00'),
(2, 'recipe_matching', 'success', 1300, NULL, '2026-09-24 11:40:00'),
(2, 'ingredient_substitution', 'success', 950, NULL, '2026-09-20 19:19:00');
