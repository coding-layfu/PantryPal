-- =============================================================
-- PantryPal — Migration: allow custom (non-catalog) ingredients
-- Run this ONCE via phpMyAdmin → SQL tab on an existing install.
-- Fresh installs get this from the updated pantrypal.sql.
-- =============================================================

-- 1. Allow ingredient_id to be NULL (custom ingredients don't link to the catalog)
ALTER TABLE recipe_ingredients
  MODIFY COLUMN ingredient_id INT UNSIGNED NULL;

-- 2. Add a free-text column for the custom name
ALTER TABLE recipe_ingredients
  ADD COLUMN custom_name VARCHAR(150) NULL AFTER ingredient_id;

-- 3. Enforce that each row has EITHER a catalog link OR a custom name, never both,
--    never neither. This is a CHECK constraint — MySQL 8+ supports it, MariaDB 10.2+ too.
ALTER TABLE recipe_ingredients
  ADD CONSTRAINT chk_ri_has_ingredient
  CHECK (
    (ingredient_id IS NOT NULL AND custom_name IS NULL) OR
    (ingredient_id IS NULL AND custom_name IS NOT NULL)
  );

-- 4. Index for looking up "which recipes use this custom name" (useful later)
ALTER TABLE recipe_ingredients
  ADD INDEX idx_ri_custom_name (custom_name);