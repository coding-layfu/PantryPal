-- =============================================================
-- PantryPal — Migration: add community recipe support
-- =============================================================

ALTER TABLE recipes
  ADD COLUMN is_community TINYINT(1) NOT NULL DEFAULT 0 AFTER created_by,
  ADD INDEX idx_recipe_community (is_community);

UPDATE recipes r
  JOIN users u ON u.id = r.created_by
  SET r.is_community = 1
  WHERE u.role = 'user';