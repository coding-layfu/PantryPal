<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/ingredient-composer.php';
require_once __DIR__ . '/includes/recipe-card.php';
require_once __DIR__ . '/includes/ai-recipe-card.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];
$pantryNames = get_user_pantry_names($userId);

$results = null;
$topExplanation = null;
$topExplanationError = null;
$searchedNames = [];

$aiRecipes = [];
$aiError = null;
$aiRateLimited = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $chips = [];
    $decoded = json_decode($_POST['ingredients'] ?? '[]', true);
    if (is_array($decoded)) {
        $chips = array_values(array_filter(array_map('strval', $decoded), fn($v) => trim($v) !== ''));
    }

    $freeText = trim($_POST['freetext'] ?? '');
    if ($freeText !== '') {
        $parsed = gemini_parse_ingredients($freeText, $userId);
        foreach ($parsed['ingredients'] as $name) {
            if (!in_array($name, $chips, true)) {
                $chips[] = $name;
            }
        }
    }

    $searchedNames = $chips;

    if (empty($searchedNames)) {
        flash('error', 'Please add at least one ingredient to find matching recipes.');
    } else {
        $recipes = get_published_recipes();
        $results = attach_match_scores($recipes, $searchedNames);

        $topIds = array_slice(array_map(fn($r) => (int) $r['id'], array_filter($results, fn($r) => $r['match'] > 0)), 0, 10);
        $stmt = db()->prepare(
            'INSERT INTO search_history (user_id, ingredients_text, matched_recipe_ids, result_count, best_match_percent)
             VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $userId,
            implode(', ', $searchedNames),
            json_encode($topIds),
            count($topIds),
            $results ? (int) $results[0]['match'] : 0,
        ]);

        $topMatchPercent = $results ? (int) $results[0]['match'] : 0;

        if ($results && $topMatchPercent > 0) {
            $top = $results[0];
            $haveNames = array_column($top['have'], 'name');
            $missingNames = array_column($top['missing'], 'name');
            $explanation = gemini_explain_match($top['title'], (int) $top['match'], $haveNames, $missingNames, $userId);
            if ($explanation['ok']) {
                $topExplanation = $explanation['explanation'];
            } else {
                $topExplanationError = $explanation['error'];
            }
        }

        // --- AI recipe generation ---
        // Only fires if the DB's best match is below 80% (so we don't waste tokens
        // when the database already has a great answer).
        if ($topMatchPercent < 80 && gemini_is_configured()) {
            if (!ai_recipe_gen_allowed($userId)) {
                $aiRateLimited = true;
            } else {
                $gen = gemini_generate_recipes($searchedNames, $userId);
                if ($gen['ok']) {
                    $aiRecipes = $gen['recipes'];
                    $_SESSION['ai_batch_' . $userId] = $aiRecipes;
                } else {
                    $aiError = $gen['error'];
                }
            }
        }

        // If the user just navigated here without a POST (e.g. from history),
        // we still want the last AI batch to be visible within this session.
    }
}

// If the page was loaded via GET (not POST), restore any previous AI batch for this user.
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !empty($_SESSION['ai_batch_' . $userId])) {
    $aiRecipes = $_SESSION['ai_batch_' . $userId];
}

$favIds = get_favorite_recipe_ids($userId);
$matchedCount = $results ? count(array_filter($results, fn($r) => $r['match'] > 0)) : 0;

$pageTitle = 'Find My Recipes';
$activeNav = 'match';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page match-page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">PANTRYPAL MATCH</span>
      <h1>Find Recipes From Your Pantry</h1>
      <p>Tell us what you have. PantryPal checks the recipe database first, then AI makes your matches more useful.</p>
    </div>
  </div>

  <section class="matching-input">
    <?php render_ingredient_composer(['large' => true, 'action' => url('match.php'), 'chips' => $searchedNames, 'pantryNames' => $pantryNames]); ?>
  </section>

  <?php if ($results !== null): ?>
    <?php if (!$matchedCount): ?>
      <div class="empty-state">
        <strong>No recipes matched those ingredients</strong>
        <p>Try adding a few more ingredients, or browse the full recipe list instead.</p>
        <a class="btn btn-secondary" href="<?= url('browse.php') ?>" style="margin-top:1rem;display:inline-flex;">Browse all recipes</a>
      </div>
    <?php else: ?>
      <?php $top = $results[0]; $isTopSaved = in_array((int) $top['id'], $favIds, true); ?>
      <section class="match-results">
        <div class="result-heading">
          <div>
            <span class="badge badge-green"><?= icon('check', 15) ?> MATCHING COMPLETE</span>
            <h2>We found <?= $matchedCount ?> recipe<?= $matchedCount === 1 ? '' : 's' ?> for you</h2>
            <p>Sorted by how well they match your ingredients.</p>
          </div>
          <button type="button" class="btn btn-secondary" onclick="window.scrollTo({top:0,behavior:'smooth'})">Run again</button>
        </div>

        <div class="top-match">
          <div class="top-match-image">
            <img src="<?= e($top['image_url']) ?>" alt="<?= e($top['title']) ?>">
            <span class="badge badge-green">BEST MATCH</span>
          </div>
          <div class="top-match-content">
            <div class="title-match">
              <div><p><?= e(strtoupper(trim(($top['category_name'] ?? '') . ' · ' . ($top['cuisine'] ?? ''), " ·"))) ?></p><h2><?= e($top['title']) ?></h2></div>
              <div class="match-ring" style="--pct:<?= (int) $top['match'] ?>"><strong><?= (int) $top['match'] ?>%</strong><small>MATCH</small></div>
            </div>
            <p class="lead"><?= e(mb_strimwidth($top['description'] ?? '', 0, 140, '…')) ?></p>
            <div class="ingredient-columns">
              <div><strong>Ingredients you have</strong>
                <?php foreach ($top['have'] as $h): ?><span><?= icon('check', 15) ?><?= e($h['name']) ?></span><?php endforeach; ?>
              </div>
              <?php if ($top['missing']): ?>
              <div class="missing"><strong>Missing</strong>
                <?php foreach ($top['missing'] as $m): ?><span>○ <?= e($m['name']) ?> <?php if ($m['optional']): ?><small>Optional</small><?php endif; ?></span><?php endforeach; ?>
              </div>
              <?php endif; ?>
            </div>
            <div class="progress"><span style="width:<?= (int) $top['match'] ?>%"></span></div>
            <?php if ($topExplanation): ?>
              <div class="ai-note">
                <span><?= icon('sparkle') ?></span>
                <div><strong>PantryPal AI Recommendation</strong><p><?= e($topExplanation) ?></p></div>
              </div>
            <?php elseif ($topExplanationError): ?>
              <p class="ai-error-note">AI enhancement is unavailable right now. Showing the database match only.</p>
            <?php endif; ?>
            <div class="card-actions">
              <a class="btn btn-primary" href="<?= url('recipe.php?id=' . (int) $top['id']) ?>"><span>View Recipe</span> <?= icon('arrow', 17) ?></a>
              <form method="post" action="<?= url('api/toggle-favorite.php') ?>" class="favorite-toggle-form inline-form <?= $isTopSaved ? 'is-saved' : '' ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="recipe_id" value="<?= (int) $top['id'] ?>">
                <input type="hidden" name="redirect" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
                <button type="submit" class="btn btn-secondary"><?= icon('heart', 17) ?><span><?= $isTopSaved ? 'Saved' : 'Save Recipe' ?></span></button>
              </form>
            </div>
          </div>
        </div>

                <?php $rest = array_values(array_filter(array_slice($results, 1), fn($r) => $r['match'] > 0)); ?>
        <?php if ($rest): ?>
        <div class="result-grid">
          <?php foreach ($rest as $r): render_recipe_card($r, in_array((int) $r['id'], $favIds, true)); endforeach; ?>
        </div>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  <?php endif; ?>

  <?php if ($aiRecipes || $aiError || $aiRateLimited): ?>
    <section class="match-results ai-results">
      <div class="result-heading">
        <div>
          <span class="badge badge-gold"><?= icon('sparkle', 15) ?> PANTRYPAL AI</span>
          <h2>AI-generated Filipino recipes for you</h2>
          <p>Made just for your ingredients — these aren't in our recipe database.</p>
        </div>
      </div>

      <?php if ($aiRateLimited): ?>
        <p class="ai-error-note">You've reached today's AI generation limit (10 per hour). Please try again later, or explore the database matches above.</p>
      <?php elseif ($aiError && !$aiRecipes): ?>
        <p class="ai-error-note">AI recipe generation is unavailable right now. Showing the database matches above.</p>
      <?php elseif ($aiRecipes): ?>
        <div class="recipe-grid">
          <?php foreach ($aiRecipes as $i => $ai): render_ai_recipe_card($ai, $i); endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
  <?php endif; ?>
</div>

<?php if ($aiRecipes): ?>
  <?php render_ai_recipe_modals($aiRecipes); ?>
<?php endif; ?>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
