(function () {
  "use strict";

  /* ---------- Mobile sidebar ---------- */
  var sidebar = document.getElementById("sidebar");
  var scrim = document.getElementById("scrim");
  var openBtn = document.getElementById("sidebarOpen");
  var closeBtn = document.getElementById("sidebarClose");
  var shell = document.getElementById("appShell");
  var collapseBtn = document.getElementById("sidebarCollapse");

  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add("sidebar-open");
    if (scrim) scrim.hidden = false;
  }
  function closeSidebar() {
    if (!sidebar) return;
    sidebar.classList.remove("sidebar-open");
    if (scrim) scrim.hidden = true;
  }
  if (openBtn) openBtn.addEventListener("click", openSidebar);
  if (closeBtn) closeBtn.addEventListener("click", closeSidebar);
  if (scrim) scrim.addEventListener("click", closeSidebar);

  /* ---------- Desktop collapsible sidebar (persisted in localStorage) ---------- */
  var SIDEBAR_KEY = "pantrypal.sidebarCollapsed";

  function applyCollapsed(collapsed) {
    if (!shell) return;
    shell.classList.toggle("sidebar-collapsed", collapsed);
    if (collapseBtn) {
      collapseBtn.setAttribute("aria-label", collapsed ? "Expand sidebar" : "Collapse sidebar");
      collapseBtn.setAttribute("title", collapsed ? "Expand sidebar" : "Collapse sidebar");
    }
  }

  // Restore saved state on page load
  try {
    if (localStorage.getItem(SIDEBAR_KEY) === "1") applyCollapsed(true);
  } catch (e) { /* localStorage may be blocked */ }

  if (collapseBtn && shell) {
    collapseBtn.addEventListener("click", function () {
      var next = !shell.classList.contains("sidebar-collapsed");
      applyCollapsed(next);
      try { localStorage.setItem(SIDEBAR_KEY, next ? "1" : "0"); } catch (e) {}
    });
  }

  /* ---------- Confirm-before-delete ---------- */
  document.querySelectorAll("[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.confirm(form.getAttribute("data-confirm"))) {
        e.preventDefault();
      }
    });
  });

  /* ---------- Ingredient composer (chip input) ---------- */
  document.querySelectorAll(".ingredient-composer").forEach(function (composer) {
    var chipInput = composer.querySelector(".chip-input");
    var chipTextEntry = composer.querySelector(".chip-input input");
    var hidden = composer.querySelector('input[name="ingredients"]');
    var countEl = composer.querySelector(".composer-count");
    if (!chipInput || !hidden) return;

    var chips = [];
    try {
      chips = JSON.parse(hidden.value || "[]");
    } catch (err) {
      chips = [];
    }

    function render() {
      chipInput.querySelectorAll(".ingredient-chip").forEach(function (c) {
        c.remove();
      });
      chips.forEach(function (name, idx) {
        var span = document.createElement("span");
        span.className = "ingredient-chip";
        span.textContent = name;
        var btn = document.createElement("button");
        btn.type = "button";
        btn.setAttribute("aria-label", "Remove " + name);
        btn.textContent = "\u00D7";
        btn.addEventListener("click", function () {
          chips.splice(idx, 1);
          sync();
        });
        span.appendChild(btn);
        chipInput.insertBefore(span, chipTextEntry);
      });
      hidden.value = JSON.stringify(chips);
      if (countEl) countEl.textContent = chips.length + " ingredient" + (chips.length === 1 ? "" : "s") + " recognized";
    }

    function addChip(raw) {
      var name = (raw || "").trim().replace(/,$/, "").trim();
      if (name && chips.indexOf(name) === -1) {
        chips.push(name);
      }
    }

    function sync() {
      render();
    }

    if (chipTextEntry) {
      chipTextEntry.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === ",") {
          e.preventDefault();
          addChip(chipTextEntry.value);
          chipTextEntry.value = "";
          sync();
        }
      });
      chipTextEntry.addEventListener("blur", function () {
        if (chipTextEntry.value.trim()) {
          addChip(chipTextEntry.value);
          chipTextEntry.value = "";
          sync();
        }
      });
    }

    render();

    var quickAllBtn = composer.querySelector("[data-use-all-pantry]");
    if (quickAllBtn) {
      quickAllBtn.addEventListener("click", function () {
        try {
          var all = JSON.parse(quickAllBtn.getAttribute("data-use-all-pantry") || "[]");
          all.forEach(function (n) {
            if (chips.indexOf(n) === -1) chips.push(n);
          });
          sync();
        } catch (err) { /* ignore */ }
      });
    }

    var form = composer.closest("form");
    if (form) {
      form.addEventListener("submit", function () {
        var submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.dataset.originalHtml = submitBtn.innerHTML;
          submitBtn.innerHTML = '<span class="spinner"></span><span>Finding recipes\u2026</span>';
        }
      });
    }
  });

  /* ---------- Favorite heart toggle (progressive AJAX, falls back to normal form) ---------- */
  document.querySelectorAll("form.favorite-toggle-form").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.fetch) return; // let it submit normally
      e.preventDefault();
      var btn = form.querySelector("button");
      var csrfInput = form.querySelector('input[name="csrf_token"]');
      var body = new FormData(form);
      fetch(form.action, {
        method: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        body: body,
      })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data.success) {
            form.classList.toggle("is-saved", data.saved);
            if (btn) btn.classList.toggle("saved", data.saved);
          } else if (data && data.message) {
            window.location.reload();
          }
        })
        .catch(function () {
          form.submit();
        });
    });
  });

  /* ---------- AI recipe modal open/close ---------- */
  document.querySelectorAll("[data-ai-modal-open]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var id = btn.getAttribute("data-ai-modal-open");
      var modal = document.getElementById(id);
      if (!modal) return;
      modal.hidden = false;
      document.body.style.overflow = "hidden";
    });
  });

  function closeAiModal(modal) {
    if (!modal) return;
    modal.hidden = true;
    document.body.style.overflow = "";
  }

  document.querySelectorAll(".ai-recipe-modal").forEach(function (modal) {
    // Click on the scrim (outside the card) closes
    modal.addEventListener("click", function (e) {
      if (e.target === modal) closeAiModal(modal);
    });
    // Explicit close button
    var closeBtn = modal.querySelector("[data-ai-modal-close]");
    if (closeBtn) closeBtn.addEventListener("click", function () { closeAiModal(modal); });
  });

  // Escape key closes any open modal
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      document.querySelectorAll(".ai-recipe-modal:not([hidden])").forEach(closeAiModal);
    }
  });

  /* ---------- Generic dismiss for flash messages ---------- */
  document.querySelectorAll(".flash").forEach(function (el) {
    setTimeout(function () {
      el.style.transition = "opacity .4s ease";
      el.style.opacity = "0";
      setTimeout(function () { el.remove(); }, 400);
    }, 6000);
  });
})();
