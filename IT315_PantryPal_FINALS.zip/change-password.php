<?php
require_once __DIR__ . '/config/bootstrap.php';

require_login();
$user = current_user();
$userId = (int) $user['id'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $current = (string) ($_POST['current_password'] ?? '');
    $new = (string) ($_POST['new_password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    $stmt = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $hash = $stmt->fetchColumn();

    if (!password_verify($current, $hash)) {
        $errors['current_password'] = 'Your current password is incorrect.';
    }
    if (mb_strlen($new) < 8) {
        $errors['new_password'] = 'New password must be at least 8 characters.';
    }
    if ($new !== $confirm) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }

    if (!$errors) {
        $stmt = db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
        $stmt->execute([password_hash($new, PASSWORD_DEFAULT), $userId]);
        flash('success', 'Your password has been updated.');
        redirect(url('profile.php'));
    }
}

$pageTitle = 'Change Password';
$activeNav = 'profile';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/app-shell-start.php';
?>
<div class="page">
  <div class="page-header">
    <div>
      <span class="badge badge-peach">ACCOUNT SECURITY</span>
      <h1>Change Password</h1>
      <p>Choose a strong password you don't use anywhere else.</p>
    </div>
  </div>
  <section class="profile-card" style="max-width:480px;">
    <form method="post" action="<?= url('change-password.php') ?>">
      <?= csrf_field() ?>
      <label class="field <?= isset($errors['current_password']) ? 'has-error' : '' ?>">
        <span>Current password</span>
        <input type="password" name="current_password" required>
        <?php if (isset($errors['current_password'])): ?><small class="field-error"><?= e($errors['current_password']) ?></small><?php endif; ?>
      </label>
      <label class="field <?= isset($errors['new_password']) ? 'has-error' : '' ?>">
        <span>New password</span>
        <input type="password" name="new_password" required>
        <?php if (isset($errors['new_password'])): ?><small class="field-error"><?= e($errors['new_password']) ?></small><?php endif; ?>
      </label>
      <label class="field <?= isset($errors['confirm_password']) ? 'has-error' : '' ?>">
        <span>Confirm new password</span>
        <input type="password" name="confirm_password" required>
        <?php if (isset($errors['confirm_password'])): ?><small class="field-error"><?= e($errors['confirm_password']) ?></small><?php endif; ?>
      </label>
      <div class="modal-actions">
        <a class="btn btn-secondary" href="<?= url('profile.php') ?>">Cancel</a>
        <button type="submit" class="btn btn-primary"><?= icon('check', 17) ?><span>Update password</span></button>
      </div>
    </form>
  </section>
</div>
<?php require __DIR__ . '/includes/app-shell-end.php'; ?>
