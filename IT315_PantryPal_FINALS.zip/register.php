<?php
require_once __DIR__ . '/config/bootstrap.php';

if (is_logged_in()) {
    redirect(url(is_admin() ? 'admin/dashboard.php' : 'dashboard.php'));
}

$errors = [];
$fullName = '';
$email = '';
$dietary = 'No preference';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');
    $dietary = trim($_POST['dietary_preference'] ?? 'No preference');

    if ($fullName === '' || mb_strlen($fullName) < 2) {
        $errors['full_name'] = 'Please enter your full name.';
    }
    if ($email === '' || !validate_email($email)) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (mb_strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    }
    if ($password !== $confirm) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors['email'] = 'An account with that email already exists.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        db()->beginTransaction();
        try {
            $stmt = db()->prepare('INSERT INTO users (full_name, email, password_hash, role, status) VALUES (?, ?, ?, \'user\', \'active\')');
            $stmt->execute([$fullName, $email, $hash]);
            $userId = (int) db()->lastInsertId();

            $stmt = db()->prepare('INSERT INTO user_preferences (user_id, dietary_preference) VALUES (?, ?)');
            $stmt->execute([$userId, $dietary]);

            db()->commit();
        } catch (Throwable $e) {
            db()->rollBack();
            $errors['form'] = 'Something went wrong creating your account. Please try again.';
        }

        if (!$errors) {
            $stmt = db()->prepare('SELECT id, full_name, email, role, status FROM users WHERE id = ?');
            $stmt->execute([$userId]);
            login_user($stmt->fetch());
            flash('success', 'Welcome to PantryPal, ' . explode(' ', $fullName)[0] . '!');
            redirect(url('dashboard.php'));
        }
    }

    set_old(['full_name' => $fullName, 'email' => $email]);
}

$pageTitle = 'Create your account';
require __DIR__ . '/includes/head.php';
?>
<div class="auth-page">
  <a class="auth-logo" href="<?= url('index.php') ?>">
    <span class="logo"><span class="logo-mark"><?= icon('logo', 22) ?></span><span>PantryPal</span></span>
  </a>
  <div class="auth-card">
    <div class="auth-intro">
      <span class="badge badge-peach">WELCOME TO PANTRYPAL</span>
      <h1>Create your kitchen profile.</h1>
      <p>Save your ingredients and find recipes made for you.</p>
    </div>

    <?php if (!empty($errors['form'])): ?><div class="flash flash-error"><?= e($errors['form']) ?></div><?php endif; ?>

    <form method="post" action="<?= url('register.php') ?>" novalidate>
      <?= csrf_field() ?>
      <label class="field <?= isset($errors['full_name']) ? 'has-error' : '' ?>">
        <span>Full name</span>
        <input type="text" name="full_name" placeholder="Maria Santos" value="<?= old('full_name') ?>" required>
        <?php if (isset($errors['full_name'])): ?><small class="field-error"><?= e($errors['full_name']) ?></small><?php endif; ?>
      </label>
      <label class="field <?= isset($errors['email']) ? 'has-error' : '' ?>">
        <span>Email address</span>
        <input type="email" name="email" placeholder="maria@example.com" value="<?= old('email') ?>" required>
        <?php if (isset($errors['email'])): ?><small class="field-error"><?= e($errors['email']) ?></small><?php endif; ?>
      </label>
      <label class="field <?= isset($errors['password']) ? 'has-error' : '' ?>">
        <span>Password</span>
        <input type="password" name="password" placeholder="At least 8 characters" required>
        <?php if (isset($errors['password'])): ?><small class="field-error"><?= e($errors['password']) ?></small><?php endif; ?>
      </label>
      <label class="field <?= isset($errors['confirm_password']) ? 'has-error' : '' ?>">
        <span>Confirm password</span>
        <input type="password" name="confirm_password" placeholder="••••••••" required>
        <?php if (isset($errors['confirm_password'])): ?><small class="field-error"><?= e($errors['confirm_password']) ?></small><?php endif; ?>
      </label>
      <label class="field">
        <span>Dietary preference <small>Optional</small></span>
        <select name="dietary_preference">
          <?php foreach (['No preference', 'Vegetarian', 'Vegan', 'Gluten-free'] as $opt): ?>
            <option value="<?= e($opt) ?>" <?= $dietary === $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <button type="submit" class="btn btn-primary full"><?= icon('user', 18) ?><span>Create Account</span></button>
    </form>
    <p class="auth-switch">Already have an account? <a href="<?= url('login.php') ?>">Log in</a></p>
  </div>
  <div class="auth-aside">
    <img src="https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=1200&q=85" alt="A warm bowl of fried rice">
    <div>
      <?= icon('sparkle') ?>
      <p>"Dinner went from no idea to on the table in 30 minutes."</p>
      <strong>— Maria, home cook</strong>
    </div>
  </div>
</div>
</body>
</html>
