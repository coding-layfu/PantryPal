# PantryPal

An AI-enhanced recipe matching and recommendation system. Tell PantryPal what's
in your kitchen and it finds recipes you can actually make — matching is done
in PHP/MySQL first, then Google's Gemini API enhances the results (explaining
matches, suggesting substitutions, and adapting cooking instructions).

Built with PHP, MySQL (PDO), HTML/CSS/JS and Bootstrap-free custom CSS ported
directly from the original Figma design.

---

## 1. What you're getting

```
pantrypal/
├── index.php, login.php, register.php, logout.php
├── dashboard.php, pantry.php, match.php, browse.php, recipe.php
├── favorites.php, history.php, profile.php, change-password.php
├── admin/            → Admin console (recipes, ingredients, categories, users, AI activity, reports)
├── api/               → toggle-favorite.php (favorites AJAX/endpoint)
├── config/            → config.sample.php (copy to config.php), bootstrap.php
├── database/          → pantrypal.sql (full schema + seed data)
├── includes/          → shared PHP (auth, db, Gemini service, matching logic, UI shell)
├── assets/            → css/js, ported 1:1 from the Figma design
└── uploads/recipes/   → where admin-uploaded recipe images would go
```

## 2. Local setup (XAMPP / MAMP / php -S)

1. Copy the whole `pantrypal/` folder into your web root (e.g. `htdocs/pantrypal`).
2. Create a MySQL database (e.g. `pantrypal`) and import the schema:
   - **phpMyAdmin:** open your new database → **Import** tab → choose
     `database/pantrypal.sql` → Go.
   - **CLI:** `mysql -u root -p pantrypal < database/pantrypal.sql`
3. Copy `config/config.sample.php` to `config/config.php` and fill in:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'pantrypal');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```
4. **Add your Gemini API key** (see section 3 below — this is the important part).
5. Visit `http://localhost/pantrypal/index.php`.

Alternatively, for a quick local check without XAMPP:
```
php -S localhost:8000
```
then visit `http://localhost:8000/index.php`.

## 3. 🔑 Where to put your Gemini API key (so AI features actually work)

Open **`config/config.php`** (the file you created in step 3 above — not
`config.sample.php`) and set:

```php
define('GEMINI_API_KEY', 'PASTE_YOUR_KEY_HERE');
```

That's the only place it goes. A few important things about how this is wired up:

- **The key never touches the browser.** It's a PHP `define()` read only by
  `includes/gemini.php` on the server side — it is never printed into HTML,
  JavaScript, or any AJAX response.
- **`config/` is blocked from direct web access** by `config/.htaccess`
  (`Require all denied`), so even if someone guessed the URL
  `yoursite.com/config/config.php`, the web server refuses to serve it.
- **`config.php` is git-ignored** (see `.gitignore`) so it won't accidentally
  get committed or re-uploaded if you push this to a repo.

### Is it "already connected"?

No — every AI feature currently runs through `gemini_is_configured()`, which
checks whether `GEMINI_API_KEY` is a non-empty string. **Right now the sample
config ships with an empty key**, so:

- `match.php` will still work (PHP/MySQL matching always runs), but the "AI
  Recommendation" note under your best match won't appear — you'll see a
  small gray note instead ("AI enhancement is unavailable right now...").
- On `recipe.php`, the "Suggest a substitute" and "Adapt instructions with
  AI" buttons will show a message that the Gemini key isn't configured yet
  instead of a suggestion.
- Natural-language ingredient typing on the composer ("I have chicken, rice
  and garlic...") will still work, but via the **offline fallback parser**
  (simple comma/"and" splitting) instead of Gemini's smarter extraction.

**Once you paste a real key into `config/config.php` and reload**, all four
AI features go live immediately — there's no build step, cache to clear, or
toggle to flip. You can confirm it's working by:

1. Logging in as `maria@example.com` / `Maria@123` (see demo accounts below).
2. Going to **Find My Recipes**, typing a full sentence like
   *"I have chicken breast, rice, eggs, garlic and soy sauce"* in the
   natural-language box, and submitting.
3. You should see a "PantryPal AI Recommendation" note appear under your top
   match — that's Gemini talking.
4. As an admin (`alex@pantrypal.com` / `Admin@123`), open **AI Activity** —
   you'll see the request logged with a real response time, and a green
   **"GEMINI CONNECTED"** badge instead of **"GEMINI KEY NOT SET"**.

If you ever want to swap models (e.g. when Google renames/upgrades one),
change `GEMINI_MODEL` in the same file — nothing else needs to change.

You can get a Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey).

## 4. Demo accounts

| Role | Email | Password |
|---|---|---|
| Admin | `alex@pantrypal.com` | `Admin@123` |
| User | `maria@example.com` | `Maria@123` |
| User | `jamie@example.com` | `Jamie@123` |
| User (deactivated, to test that flow) | `chris@example.com` | `Chris@123` |

All passwords are bcrypt-hashed in the database (never stored in plain text).

## 5. Deploying to shared hosting (e.g. InfinityFree)

1. Upload everything **except** `config/config.php` (create it fresh on the
   server — never upload it from your machine, and never commit it).
2. Create a MySQL database through your host's control panel and import
   `database/pantrypal.sql` via their phpMyAdmin.
3. Create `config/config.php` on the server (via file manager or FTP) using
   your host's DB hostname/username/password/database name, and your Gemini
   key.
4. Set `APP_ENV` to `'production'` in `config.php` (hides PHP errors) and set
   `APP_URL` to your real domain.
5. Make sure PHP's `curl` extension is enabled (needed for Gemini requests)
   — most shared hosts have this on by default.
6. Visit your domain — PantryPal auto-detects whether it's installed at the
   domain root or a subfolder, so links work either way.

## 6. Security notes

- Passwords: `password_hash()` / `password_verify()` (bcrypt).
- All queries use PDO prepared statements — no raw string interpolation.
- Output is escaped via `e()` (an `htmlspecialchars` wrapper) everywhere.
- Every state-changing form includes a CSRF token, checked by `csrf_require()`.
- Sessions are regenerated on login; admin routes call `require_admin()`.
- The Gemini API key is server-side only (see section 3).
- `config/` is blocked from direct HTTP access via `.htaccess`.

## 7. A few implementation notes / deviations from the original brief

- **Ingredient matching** is done live in `match.php` and `recipe.php` via
  `calculate_match()` (in `includes/functions.php`) rather than a separate
  `/api/match-recipes.php` endpoint — it's a normal form POST that computes
  the DB match, logs the search, and (if configured) asks Gemini to explain
  only the single top match, exactly per the "don't send everything to
  Gemini" architecture in the brief. Functionally equivalent, fewer moving
  parts, easier to keep working the first time you deploy it.
- **Category Management** manages *recipe* categories (Breakfast/Lunch/
  Dinner/Dessert) with live recipe counts, as the brief describes. Ingredient
  categories (Meat, Vegetables, Grains, etc.) are managed inline from the
  Ingredient Management page's "Category" dropdown, backed by the same
  `categories` table (distinguished by a `type` column).
- **Reports** (most searched ingredients, most matched recipes, common
  missing ingredients, weekly activity) are computed live from real
  `search_history` / `ai_requests` data — nothing is hardcoded — so the
  numbers will be sparse until your seed data or real usage builds up.
- Recipe photos use a small set of stable Unsplash URLs (as in the original
  Figma prototype) rather than uploaded files, so the app never depends on
  images that could disappear. Admins can still paste any image URL when
  adding/editing a recipe.
