-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql313.infinityfree.com
-- Generation Time: Nov 07, 2026 at 12:55 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43021861_PantryPal`
--

-- --------------------------------------------------------

--
-- Table structure for table `ai_requests`
--

CREATE TABLE `ai_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `feature` enum('ingredient_understanding','recipe_matching','recipe_recommendation','ingredient_substitution','cooking_instructions') NOT NULL,
  `status` enum('success','error') NOT NULL,
  `response_time_ms` int(10) UNSIGNED DEFAULT NULL,
  `error_message` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ai_requests`
--

INSERT INTO `ai_requests` (`id`, `user_id`, `feature`, `status`, `response_time_ms`, `error_message`, `created_at`) VALUES
(1, 2, 'recipe_matching', 'success', 1400, NULL, '2026-09-27 21:34:00'),
(2, 3, 'ingredient_understanding', 'success', 800, NULL, '2026-09-27 21:31:00'),
(3, 4, 'ingredient_substitution', 'success', 1100, NULL, '2026-09-27 21:24:00'),
(4, 2, 'cooking_instructions', 'success', 1800, NULL, '2026-09-27 21:18:00'),
(5, 2, 'recipe_matching', 'success', 1250, NULL, '2026-09-27 01:12:00'),
(6, 3, 'recipe_matching', 'success', 1600, NULL, '2026-09-25 16:00:00'),
(7, 2, 'ingredient_understanding', 'error', 5200, 'Connection timed out', '2026-09-24 18:39:00'),
(8, 2, 'recipe_matching', 'success', 1300, NULL, '2026-09-24 18:40:00'),
(9, 2, 'ingredient_substitution', 'success', 950, NULL, '2026-09-21 02:19:00'),
(10, 2, 'recipe_matching', 'success', 790, NULL, '2026-09-27 23:32:43'),
(11, 2, 'recipe_matching', 'success', 977, NULL, '2026-09-27 23:34:32'),
(12, 2, 'recipe_matching', 'success', 1005, NULL, '2026-09-27 23:36:43'),
(13, 2, 'ingredient_understanding', 'success', 590, NULL, '2026-09-27 23:38:16'),
(14, 2, 'recipe_matching', 'success', 1006, NULL, '2026-09-27 23:38:17'),
(15, 2, 'ingredient_substitution', 'success', 880, NULL, '2026-09-27 23:39:16'),
(16, 1, 'recipe_matching', 'success', 1000, NULL, '2026-09-28 00:06:08'),
(17, 1, 'recipe_matching', 'error', 12002, 'Connection error: Operation timed out after 12001 milliseconds with 0 bytes received', '2026-09-28 05:51:59'),
(18, 1, 'recipe_matching', 'success', 991, NULL, '2026-09-28 06:09:41'),
(19, 1, 'recipe_matching', 'success', 6863, NULL, '2026-09-28 06:11:11'),
(20, 1, 'recipe_matching', 'success', 1529, NULL, '2026-09-28 06:12:07'),
(21, 1, 'recipe_matching', 'success', 1003, NULL, '2026-09-28 06:14:08'),
(22, 1, 'recipe_matching', 'success', 920, NULL, '2026-10-03 14:24:56'),
(23, 1, 'recipe_matching', 'success', 981, NULL, '2026-10-03 14:53:28'),
(24, 1, 'recipe_matching', 'success', 910, NULL, '2026-10-03 15:06:19'),
(25, 1, 'recipe_matching', 'success', 827, NULL, '2026-10-03 15:09:31'),
(26, 1, 'recipe_matching', 'success', 1021, NULL, '2026-10-03 15:11:43'),
(27, 7, 'recipe_matching', 'success', 984, NULL, '2026-10-03 16:34:31'),
(28, 5, 'recipe_recommendation', 'error', 3175, 'Unparseable JSON from recipe generator', '2026-10-03 16:38:20'),
(29, 5, 'recipe_recommendation', 'success', 3701, NULL, '2026-10-03 16:43:10'),
(30, 7, 'recipe_matching', 'success', 1015, NULL, '2026-10-03 16:55:02'),
(31, 7, 'recipe_recommendation', 'success', 4876, NULL, '2026-10-03 16:55:07'),
(32, 7, 'recipe_matching', 'success', 7231, NULL, '2026-10-12 01:09:58'),
(33, 7, 'recipe_recommendation', 'success', 4928, NULL, '2026-10-12 01:10:03'),
(34, 7, 'recipe_matching', 'success', 645, NULL, '2026-10-12 01:18:20'),
(35, 7, 'recipe_recommendation', 'success', 4395, NULL, '2026-10-12 01:18:25'),
(36, 7, 'recipe_recommendation', 'success', 3345, NULL, '2026-10-12 06:11:28'),
(37, 7, 'recipe_matching', 'success', 849, NULL, '2026-10-12 06:33:09'),
(38, 7, 'recipe_recommendation', 'success', 2946, NULL, '2026-10-12 06:33:12'),
(39, 7, 'recipe_matching', 'success', 757, NULL, '2026-10-12 06:34:25'),
(40, 7, 'recipe_recommendation', 'success', 4565, NULL, '2026-10-12 06:34:29'),
(41, 7, 'recipe_matching', 'success', 857, NULL, '2026-10-18 14:37:14'),
(42, 7, 'recipe_recommendation', 'success', 4124, NULL, '2026-10-18 14:37:18'),
(43, 7, 'cooking_instructions', 'success', 1128, NULL, '2026-10-18 14:54:01'),
(44, 7, 'recipe_matching', 'success', 6209, NULL, '2026-11-07 00:55:08'),
(45, 7, 'recipe_recommendation', 'success', 3708, NULL, '2026-11-07 00:55:12'),
(46, 7, 'recipe_matching', 'success', 3147, NULL, '2026-11-07 01:19:39'),
(47, 7, 'recipe_recommendation', 'success', 5332, NULL, '2026-11-07 01:19:44'),
(48, 7, 'ingredient_substitution', 'success', 911, NULL, '2026-11-07 01:20:18'),
(49, 7, 'recipe_matching', 'success', 790, NULL, '2026-11-07 01:40:56'),
(50, 7, 'recipe_recommendation', 'error', 12001, 'Connection error: Operation timed out after 12000 milliseconds with 0 bytes received', '2026-11-07 01:41:08'),
(51, 7, 'recipe_recommendation', 'success', 4948, NULL, '2026-11-07 01:45:01'),
(52, 7, 'recipe_recommendation', 'success', 4688, NULL, '2026-11-07 01:45:41'),
(53, 7, 'recipe_recommendation', 'success', 3191, NULL, '2026-11-07 02:51:46');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `type` enum('recipe','ingredient') NOT NULL DEFAULT 'recipe',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `type`, `created_at`) VALUES
(1, 'Breakfast', 'breakfast', 'recipe', '2026-09-27 23:29:23'),
(2, 'Lunch', 'lunch', 'recipe', '2026-09-27 23:29:23'),
(3, 'Dinner', 'dinner', 'recipe', '2026-09-27 23:29:23'),
(4, 'Dessert', 'dessert', 'recipe', '2026-09-27 23:29:23'),
(5, 'Meat', 'meat', 'ingredient', '2026-09-27 23:29:23'),
(6, 'Vegetables', 'vegetables', 'ingredient', '2026-09-27 23:29:23'),
(7, 'Grains', 'grains', 'ingredient', '2026-09-27 23:29:23'),
(8, 'Dairy & Protein', 'dairy-protein', 'ingredient', '2026-09-27 23:29:23'),
(9, 'Sauces & Condiments', 'sauces-condiments', 'ingredient', '2026-09-27 23:29:23'),
(10, 'Herbs & Spices', 'herbs-spices', 'ingredient', '2026-09-27 23:29:23'),
(11, 'Other', 'other', 'ingredient', '2026-09-27 23:29:23');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `recipe_id`, `created_at`) VALUES
(1, 2, 1, '2026-09-27 03:00:00'),
(2, 2, 4, '2026-09-21 02:00:00'),
(3, 2, 6, '2026-09-16 02:30:00'),
(4, 3, 4, '2026-09-24 19:00:00'),
(9, 7, 7, '2026-10-12 06:33:49'),
(10, 7, 4, '2026-10-18 14:36:59'),
(11, 7, 10, '2026-11-07 01:21:02');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `category_id`, `created_at`) VALUES
(1, 'Chicken breast', 5, '2026-09-27 23:29:23'),
(2, 'Ground beef', 5, '2026-09-27 23:29:23'),
(3, 'Bacon', 5, '2026-09-27 23:29:23'),
(4, 'Shrimp', 5, '2026-09-27 23:29:23'),
(5, 'Tuna', 5, '2026-09-27 23:29:23'),
(6, 'Jasmine rice', 7, '2026-09-27 23:29:23'),
(7, 'Cooked rice', 7, '2026-09-27 23:29:23'),
(8, 'Noodles', 7, '2026-09-27 23:29:23'),
(9, 'Pasta', 7, '2026-09-27 23:29:23'),
(10, 'Bread', 7, '2026-09-27 23:29:23'),
(11, 'Eggs', 8, '2026-09-27 23:29:23'),
(12, 'Milk', 8, '2026-09-27 23:29:23'),
(13, 'Heavy cream', 8, '2026-09-27 23:29:23'),
(14, 'Parmesan cheese', 8, '2026-09-27 23:29:23'),
(15, 'Cheese', 8, '2026-09-27 23:29:23'),
(16, 'Butter', 8, '2026-09-27 23:29:23'),
(17, 'Garlic', 6, '2026-09-27 23:29:23'),
(18, 'Green onion', 6, '2026-09-27 23:29:23'),
(19, 'Onion', 6, '2026-09-27 23:29:23'),
(20, 'Carrots', 6, '2026-09-27 23:29:23'),
(21, 'Bell pepper', 6, '2026-09-27 23:29:23'),
(22, 'Broccoli', 6, '2026-09-27 23:29:23'),
(23, 'Spinach', 6, '2026-09-27 23:29:23'),
(24, 'Potatoes', 6, '2026-09-27 23:29:23'),
(25, 'Tomatoes', 6, '2026-09-27 23:29:23'),
(26, 'Ginger', 10, '2026-09-27 23:29:23'),
(27, 'Basil', 10, '2026-09-27 23:29:23'),
(28, 'Black pepper', 10, '2026-09-27 23:29:23'),
(29, 'Salt', 10, '2026-09-27 23:29:23'),
(30, 'Soy sauce', 9, '2026-09-27 23:29:23'),
(31, 'Mayonnaise', 9, '2026-09-27 23:29:23'),
(32, 'Olive oil', 9, '2026-09-27 23:29:23'),
(33, 'Vegetable oil', 9, '2026-09-27 23:29:23'),
(34, 'Lemon', 6, '2026-09-27 23:29:23'),
(35, 'Cornstarch', 11, '2026-09-27 23:29:23'),
(36, 'Chicken broth', 11, '2026-09-27 23:29:23'),
(37, 'talong', 6, '2026-10-12 01:33:18'),
(38, 'kalabasa', NULL, '2026-11-07 01:25:44'),
(39, 'sayote', NULL, '2026-11-07 01:42:54'),
(40, 'avocado', NULL, '2026-11-07 02:56:52');

-- --------------------------------------------------------

--
-- Table structure for table `pantry_items`
--

CREATE TABLE `pantry_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ingredient_id` int(10) UNSIGNED DEFAULT NULL,
  `custom_name` varchar(150) NOT NULL,
  `quantity_text` varchar(100) DEFAULT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `expires_on` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pantry_items`
--

INSERT INTO `pantry_items` (`id`, `user_id`, `ingredient_id`, `custom_name`, `quantity_text`, `category_id`, `expires_on`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'Chicken breast', '500 g', 5, '2026-09-29', '2026-09-25 15:00:00', '2026-09-27 23:29:23'),
(2, 2, 6, 'Jasmine rice', '1 kg', 7, NULL, '2026-09-20 15:00:00', '2026-09-27 23:29:23'),
(3, 2, 11, 'Free-range eggs', '6 pieces', 8, '2026-10-05', '2026-09-25 15:00:00', '2026-09-27 23:29:23'),
(4, 2, 17, 'Garlic', '1 bulb', 6, NULL, '2026-09-18 15:00:00', '2026-09-27 23:29:23'),
(5, 2, 30, 'Soy sauce', '250 ml', 9, NULL, '2026-09-10 15:00:00', '2026-09-27 23:29:23'),
(6, 2, 20, 'Carrots', '4 pieces', 6, '2026-10-02', '2026-09-24 15:00:00', '2026-09-27 23:29:23'),
(7, 3, 9, 'Pasta', '500 g', 7, NULL, '2026-09-20 15:00:00', '2026-09-27 23:29:23'),
(8, 3, 25, 'Tomatoes', '6 pieces', 6, '2026-10-01', '2026-09-24 15:00:00', '2026-09-27 23:29:23'),
(9, 3, 27, 'Basil', '1 bunch', 10, '2026-09-30', '2026-09-24 15:00:00', '2026-09-27 23:29:23'),
(10, 7, NULL, 'Chicken', '20 grams', 5, '2026-10-13', '2026-10-12 01:08:58', '2026-10-12 01:08:58'),
(11, 7, NULL, 'talong', '5 pieces', 6, '2026-10-14', '2026-10-12 01:09:33', '2026-10-12 01:09:33'),
(12, 7, NULL, 'egg', '1 dozen', 11, '2026-10-19', '2026-10-12 01:13:47', '2026-10-12 01:13:47'),
(13, 7, 18, 'green onion', NULL, 10, '2026-10-16', '2026-10-12 01:14:32', '2026-10-12 01:14:32'),
(14, 7, 26, 'ginger', NULL, 10, '2026-10-19', '2026-10-12 01:15:08', '2026-10-12 01:15:08'),
(15, 7, 8, 'noodles', NULL, 11, NULL, '2026-10-12 01:15:46', '2026-10-12 01:15:46'),
(16, 7, NULL, 'Tanglad', NULL, 10, NULL, '2026-11-07 01:09:18', '2026-11-07 01:09:18');

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `slug` varchar(220) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `prep_time_minutes` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `cook_time_minutes` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `servings` smallint(5) UNSIGNED NOT NULL DEFAULT 2,
  `difficulty` enum('Easy','Medium','Hard') NOT NULL DEFAULT 'Easy',
  `cuisine` varchar(100) DEFAULT NULL,
  `dietary_info` varchar(150) DEFAULT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('published','draft') NOT NULL DEFAULT 'published',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `is_community` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`id`, `title`, `slug`, `description`, `image_url`, `prep_time_minutes`, `cook_time_minutes`, `servings`, `difficulty`, `cuisine`, `dietary_info`, `category_id`, `status`, `created_by`, `is_community`, `created_at`, `updated_at`) VALUES
(1, 'Chicken Fried Rice', 'chicken-fried-rice', 'A comforting, savory fried rice made with tender chicken, fluffy grains and a rich soy-garlic finish.', 'https://theflattopking.com/wp-content/uploads/2024/01/blackstone-chicken-fried-rice-5.jpg', 10, 15, 4, 'Easy', 'Asian-inspired', NULL, 3, 'published', 1, 0, '2026-08-01 17:00:00', '2026-10-12 01:04:55'),
(2, 'Garlic Egg Rice Bowl', 'garlic-egg-rice-bowl', 'Comforting garlic rice topped with a silky egg and fresh herbs — ready before your coffee finishes brewing.', 'https://assets.epicurious.com/photos/5f19a47a59eadf0c13289595/1:1/w_2560%2Cc_limit/GarlicFriedRice_Recipe_071520_9567_VOG_final.jpg', 5, 15, 2, 'Easy', 'Asian-inspired', NULL, 1, 'published', 1, 0, '2026-08-03 16:30:00', '2026-11-07 00:57:01'),
(3, 'Soy Chicken Noodles', 'soy-chicken-noodles', 'Glossy noodles tossed with soy-glazed chicken and crisp vegetables for a fast weeknight dinner.', 'https://www.marionskitchen.com/wp-content/uploads/2024/04/20240313_MK_Soy-Sauce-Chicken-Noodles_Bangkok-14-scaled-e1718853716703.webp', 15, 20, 3, 'Medium', 'Asian-inspired', NULL, 3, 'published', 1, 0, '2026-08-06 01:00:00', '2026-10-12 01:03:08'),
(4, 'Creamy Tuscan Pasta', 'creamy-tuscan-pasta', 'Rich, garlicky cream sauce with wilted spinach and parmesan, tossed through pasta.', 'https://tastydelice.com/wp-content/uploads/2025/09/Creamy_Tuscan_Pasta_-1.webp', 10, 30, 4, 'Medium', 'Italian-inspired', 'Vegetarian option available', 3, 'published', 1, 0, '2026-08-09 02:00:00', '2026-10-12 01:02:41'),
(5, 'Vegetable Stir Fry', 'vegetable-stir-fry', 'A quick, colorful stir fry that turns whatever vegetables you have into a satisfying meal.', 'https://cdn.loveandlemons.com/wp-content/uploads/2025/02/stir-fry-recipe.jpg', 10, 10, 2, 'Easy', 'Asian-inspired', 'Vegetarian, Vegan', 2, 'published', 1, 0, '2026-08-10 19:00:00', '2026-10-12 01:02:11'),
(6, 'Garlic Butter Shrimp Pasta', 'garlic-butter-shrimp-pasta', 'Juicy shrimp in a bright garlic-butter-lemon sauce over pasta — restaurant flavor, weeknight speed.', 'https://amyinthekitchen.com/wp-content/uploads/2022/05/Pasta-with-garlic-butter-shrimp-recipe.jpg', 10, 20, 3, 'Medium', 'Italian-inspired', NULL, 3, 'published', 1, 0, '2026-08-15 02:30:00', '2026-10-12 01:01:38'),
(7, 'Beef Tapa Rice Bowl', 'beef-tapa-rice-bowl', 'A Filipino breakfast favorite: garlicky beef strips served over rice with a fried egg.', 'https://images.getrecipekit.com/20220721055451-mva02825.JPG?aspect_ratio=1:1&quality=90&', 15, 20, 4, 'Medium', 'Filipino', NULL, 1, 'published', 1, 0, '2026-08-18 14:00:00', '2026-10-18 14:39:01'),
(8, 'Tuna Sandwich Melt', 'tuna-sandwich-melt', 'A pantry-staple lunch: creamy tuna salad melted with cheese between toasted bread.', 'https://cdn.apartmenttherapy.info/image/upload/v1692634573/k/08-2023-tuna-melt/tuna-melt-415-horizontal.jpg', 10, 5, 2, 'Easy', 'American', NULL, 2, 'published', 1, 0, '2026-08-20 19:30:00', '2026-10-12 00:59:32'),
(9, 'Cheesy Potato Bake', 'cheesy-potato-bake', 'Layers of tender potatoes baked in a cheesy, garlicky milk sauce until golden.', 'https://yumfamilyrecipes.com/wp-content/uploads/2025/11/4-1.png', 15, 45, 6, 'Easy', 'American', 'Vegetarian', 3, 'published', 1, 0, '2026-08-23 00:00:00', '2026-10-12 00:59:03'),
(10, 'Egg Drop Soup', 'egg-drop-soup', 'A light, silky soup with ribbons of egg — ready in under 20 minutes with pantry staples', 'https://drivemehungry.com/wp-content/uploads/2020/07/egg-drop-soup-11.jpg', 5, 10, 2, 'Easy', 'Asian-inspired', NULL, 2, 'published', 1, 0, '2026-08-25 19:00:00', '2026-10-12 01:34:16'),
(11, 'Chicken Adobo', 'chicken-adobo', 'My Lola\'s Chicken Adobo Recipe', 'https://panlasangpinoy.com/wp-content/uploads/2026/05/Chicken-Adobo-in-a-Bowl.jpg', 12, 30, 5, 'Medium', 'Filipino', NULL, 1, 'published', 7, 1, '2026-10-12 02:13:07', '2026-10-12 02:13:07'),
(12, 'Ginataang Bangus', 'ginataang-bangus', 'A traditional Filipino dish made with bangus (milkfish) cooked in coconut milk, or gata.', 'https://panlasangpinoy.com/wp-content/uploads/2026/02/how-to-cook-ginataang-bangus.jpg', 10, 20, 4, 'Medium', 'Filipino', NULL, 2, 'draft', 7, 1, '2026-10-18 14:22:29', '2026-10-18 14:22:29'),
(13, 'Ensaladang Dilis', 'ensaladang-dilis', 'Ensaladang Dilis is a Filipino tomato and onion salad topped with crispy fried dried anchovies and dressed with calamansi juice and fish sauce.', 'https://panlasangpinoy.com/wp-content/uploads/2026/07/Dilis-salad.jpg', 10, 20, 4, 'Easy', 'Filipino', NULL, NULL, 'draft', 7, 1, '2026-10-18 14:36:27', '2026-10-18 14:36:27');

-- --------------------------------------------------------

--
-- Table structure for table `recipe_ingredients`
--

CREATE TABLE `recipe_ingredients` (
  `id` int(10) UNSIGNED NOT NULL,
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `ingredient_id` int(10) UNSIGNED DEFAULT NULL,
  `custom_name` varchar(150) DEFAULT NULL,
  `quantity_text` varchar(100) DEFAULT NULL,
  `is_optional` tinyint(1) NOT NULL DEFAULT 0,
  `display_order` smallint(5) UNSIGNED NOT NULL DEFAULT 0
) ;

--
-- Dumping data for table `recipe_ingredients`
--

INSERT INTO `recipe_ingredients` (`id`, `recipe_id`, `ingredient_id`, `custom_name`, `quantity_text`, `is_optional`, `display_order`) VALUES
(63, 9, 24, NULL, '1 kg', 0, 0),
(64, 9, 15, NULL, '1.5 cups', 0, 1),
(65, 9, 12, NULL, '1 cup', 0, 2),
(66, 9, 16, NULL, '2 tbsp', 0, 3),
(67, 9, 17, NULL, '2 cloves', 1, 4),
(68, 8, 5, NULL, '1 can', 0, 0),
(69, 8, 10, NULL, '4 slices', 0, 1),
(70, 8, 31, NULL, '3 tbsp', 0, 2),
(71, 8, 15, NULL, '4 slices', 0, 3),
(72, 8, 19, NULL, '2 tbsp, diced', 1, 4),
(87, 6, 4, NULL, '300 g', 0, 0),
(88, 6, 9, NULL, '250 g', 0, 1),
(89, 6, 16, NULL, '3 tbsp', 0, 2),
(90, 6, 17, NULL, '4 cloves', 0, 3),
(91, 6, 34, NULL, '1 piece', 0, 4),
(92, 6, 28, NULL, '1 tsp', 1, 5),
(93, 5, 22, NULL, '1 cup', 0, 0),
(94, 5, 20, NULL, '1 cup, sliced', 0, 1),
(95, 5, 21, NULL, '1 piece', 0, 2),
(96, 5, 17, NULL, '2 cloves', 0, 3),
(97, 5, 30, NULL, '2 tbsp', 0, 4),
(98, 5, 33, NULL, '1 tbsp', 0, 5),
(99, 4, 9, NULL, '300 g', 0, 0),
(100, 4, 13, NULL, '1 cup', 0, 1),
(101, 4, 14, NULL, '1/2 cup', 0, 2),
(102, 4, 17, NULL, '3 cloves', 0, 3),
(103, 4, 23, NULL, '2 cups', 0, 4),
(104, 4, 25, NULL, '1/2 cup, diced', 1, 5),
(105, 3, 1, NULL, '300 g', 0, 0),
(106, 3, 8, NULL, '200 g', 0, 1),
(107, 3, 30, NULL, '3 tbsp', 0, 2),
(108, 3, 17, NULL, '2 cloves', 0, 3),
(109, 3, 26, NULL, '1 tsp', 0, 4),
(110, 3, 21, NULL, '1 piece', 1, 5),
(123, 1, 1, NULL, '400 g', 0, 0),
(124, 1, 7, NULL, '3 cups', 0, 1),
(125, 1, 11, NULL, '2 large', 0, 2),
(126, 1, 17, NULL, '3 cloves', 0, 3),
(127, 1, 30, NULL, '3 tbsp', 0, 4),
(128, 1, 18, NULL, '2 stalks', 1, 5),
(129, 10, 11, NULL, '2 large', 0, 0),
(130, 10, 36, NULL, '4 cups', 0, 1),
(131, 10, 35, NULL, '1 tbsp', 0, 2),
(132, 10, 18, NULL, '2 stalks', 1, 3),
(133, 10, 26, NULL, '1 tsp', 1, 4),
(185, 7, 2, NULL, '400 g', 0, 0),
(186, 7, 7, NULL, '3 cups', 0, 1),
(187, 7, 17, NULL, '5 cloves', 0, 2),
(188, 7, 30, NULL, '4 tbsp', 0, 3),
(189, 7, 11, NULL, '4 large', 0, 4),
(190, 7, 19, NULL, '1 piece', 1, 5),
(191, 7, 25, NULL, '2 pieces', 1, 6),
(256, 13, NULL, 'Dried anchovies (dilis)', NULL, 0, 0),
(257, 13, NULL, 'Ripe tomatoes', NULL, 0, 1),
(258, 13, NULL, 'Purple onion', NULL, 0, 2),
(259, 13, NULL, 'Calamansi', NULL, 0, 3),
(260, 13, NULL, 'Fish sauce', NULL, 0, 4),
(261, 13, NULL, 'Ground black pepper', NULL, 0, 5),
(262, 13, NULL, 'Sugar', NULL, 0, 6),
(263, 13, NULL, 'Cooking oil', NULL, 0, 7),
(264, 12, NULL, 'Bangus (Boneless)', NULL, 0, 0),
(265, 12, NULL, 'Maggi Magic Sarap', NULL, 0, 1),
(266, 12, NULL, 'All purpose flour', NULL, 0, 2),
(267, 12, NULL, 'Coconut milk', NULL, 0, 3),
(268, 12, NULL, 'String beans', NULL, 0, 4),
(269, 12, NULL, 'Thai chili peppers', NULL, 0, 5),
(270, 12, 19, NULL, NULL, 0, 6),
(271, 12, 26, NULL, NULL, 0, 7),
(272, 12, 17, NULL, NULL, 0, 8),
(273, 12, NULL, 'Shrimp paste', NULL, 0, 9),
(274, 12, NULL, 'Cooking oil', NULL, 0, 10),
(275, 12, NULL, 'Fish sauce', NULL, 0, 11),
(276, 12, NULL, 'Ground black pepper', NULL, 0, 12),
(277, 11, NULL, 'Chicken', NULL, 0, 0),
(278, 11, 30, NULL, NULL, 0, 1),
(279, 11, NULL, 'White vinegar', NULL, 0, 2),
(280, 11, 17, NULL, NULL, 0, 3),
(281, 11, NULL, 'Dried bay leaves', NULL, 0, 4),
(282, 11, NULL, 'Whole black peppercorns', NULL, 0, 5),
(283, 11, NULL, 'Sugar', NULL, 0, 6),
(284, 11, NULL, 'Water', NULL, 0, 7),
(285, 11, NULL, 'Cooking oil', NULL, 0, 8),
(286, 2, 7, NULL, '2 cups', 0, 0),
(287, 2, 11, NULL, '2 large', 0, 1),
(288, 2, 17, NULL, '4 cloves', 0, 2),
(289, 2, 16, NULL, '1 tbsp', 0, 3),
(290, 2, 30, NULL, '1 tbsp', 0, 4),
(291, 2, 18, NULL, '1 stalk', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `recipe_steps`
--

CREATE TABLE `recipe_steps` (
  `id` int(10) UNSIGNED NOT NULL,
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `step_order` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recipe_steps`
--

INSERT INTO `recipe_steps` (`id`, `recipe_id`, `step_order`, `title`, `description`) VALUES
(52, 9, 0, 'Prep the potatoes', 'Slice the potatoes thinly and layer them in a baking dish.'),
(53, 9, 1, 'Make the sauce', 'Warm milk with butter and garlic if using, then season to taste.'),
(54, 9, 2, 'Layer and bake', 'Pour the sauce over the potatoes, top with cheese, and bake at 190°C (375°F) for about 40 minutes.'),
(55, 9, 3, 'Check for doneness', 'Potatoes should be fork-tender and the top golden and bubbling.'),
(56, 9, 4, 'Rest and serve', 'Let stand 5 minutes before serving.'),
(57, 8, 0, 'Make the tuna salad', 'Mix drained tuna with mayonnaise and diced onion if using.'),
(58, 8, 1, 'Assemble the sandwich', 'Spread the tuna mixture on bread and top with cheese slices.'),
(59, 8, 2, 'Melt the cheese', 'Toast in a pan or oven until the bread is golden and the cheese is melted.'),
(60, 8, 3, 'Slice and serve', 'Cut in half and serve warm.'),
(71, 6, 0, 'Cook the pasta', 'Boil the pasta until al dente, reserving some pasta water before draining.'),
(72, 6, 1, 'Sear the shrimp', 'Season shrimp and sear in a hot pan for 1-2 minutes per side until pink; set aside.'),
(73, 6, 2, 'Make the garlic butter', 'In the same pan, melt butter and cook garlic until fragrant, about 30 seconds.'),
(74, 6, 3, 'Combine', 'Return shrimp to the pan, add lemon juice and pasta, tossing to coat.'),
(75, 6, 4, 'Serve', 'Finish with black pepper if using and serve right away.'),
(76, 5, 0, 'Prep the vegetables', 'Cut all vegetables into similar-sized pieces for even cooking.'),
(77, 5, 1, 'Heat the wok', 'Heat vegetable oil in a wok or large pan over high heat until shimmering.'),
(78, 5, 2, 'Stir fry', 'Add garlic, then vegetables, stir-frying for 4-5 minutes until crisp-tender.'),
(79, 5, 3, 'Season and serve', 'Add soy sauce, toss to coat, and serve immediately over rice.'),
(80, 4, 0, 'Cook the pasta', 'Boil the pasta in salted water until al dente, then reserve a cup of pasta water and drain.'),
(81, 4, 1, 'Build the sauce', 'In a large pan, sauté garlic in butter, then stir in heavy cream and bring to a gentle simmer.'),
(82, 4, 2, 'Add the cheese', 'Stir in parmesan cheese until melted and the sauce thickens slightly.'),
(83, 4, 3, 'Wilt the spinach', 'Add spinach and cook until just wilted, about 2 minutes.'),
(84, 4, 4, 'Combine and serve', 'Toss the pasta through the sauce, loosening with pasta water as needed, and serve immediately.'),
(85, 3, 0, 'Cook the noodles', 'Boil the noodles according to package directions, then drain and set aside.'),
(86, 3, 1, 'Sear the chicken', 'Slice the chicken thin and sear in a hot pan for 5-6 minutes until cooked through.'),
(87, 3, 2, 'Build the sauce', 'Add garlic and ginger to the pan and cook for 30 seconds, then stir in soy sauce.'),
(88, 3, 3, 'Toss it together', 'Add the noodles to the pan and toss to coat evenly in the sauce.'),
(89, 3, 4, 'Finish and serve', 'Top with sliced bell pepper if using, and serve hot.'),
(98, 1, 0, 'Prepare the rice', 'Break up any clumps in your cooked rice. Chilled rice works best, but freshly cooked rice can be spread on a plate to cool.'),
(99, 1, 1, 'Cook the chicken', 'Heat a large pan over medium-high heat. Cook the chicken for 6-7 minutes until golden and fully cooked, then set aside.'),
(100, 1, 2, 'Build the aromatics', 'In the same pan, add garlic and cook for 30 seconds until fragrant.'),
(101, 1, 3, 'Scramble the eggs', 'Push everything aside, add the eggs and gently scramble until just set.'),
(102, 1, 4, 'Bring it together', 'Add rice, chicken and soy sauce. Toss over high heat for 3-4 minutes until evenly combined and hot.'),
(103, 1, 5, 'Serve and enjoy', 'Taste, adjust seasoning and serve immediately while warm.'),
(104, 10, 0, 'Heat the broth', 'Bring chicken broth to a gentle simmer in a pot.'),
(105, 10, 1, 'Thicken', 'Whisk cornstarch with a little water and stir into the simmering broth until slightly thickened.'),
(106, 10, 2, 'Add the egg ribbons', 'Slowly drizzle in beaten eggs while stirring gently to form ribbons.'),
(107, 10, 3, 'Finish and serve', 'Top with green onion and ginger if using, then serve hot.'),
(108, 7, 0, 'Marinate the beef', 'Toss beef strips with garlic and soy sauce; let sit for at least 10 minutes.'),
(109, 7, 1, 'Sear the beef', 'Cook the beef in a hot pan for 3-4 minutes per side until caramelized.'),
(110, 7, 2, 'Fry the eggs', 'In a separate pan, fry the eggs to your liking.'),
(111, 7, 3, 'Warm the rice', 'Warm the cooked rice, optionally frying with a little garlic.'),
(112, 7, 4, 'Assemble the bowl', 'Serve the beef over rice topped with a fried egg and sliced onion if using.'),
(114, 13, 0, 'Fry the Dried Anchovies', 'Heat the cooking oil in a pan. Add the dried anchovies and stir-fry until they start to brown.\r\nTransfer the anchovies to a plate immediately. They will become crispier as they cool.'),
(115, 13, 1, 'Make the Calamansi Dressing', 'Squeeze the calamansi into a bowl, catching the seeds with your hand or a small strainer.\r\nAdd the fish sauce, ground black pepper, and sugar, if using. Stir until well combined.'),
(116, 13, 2, 'Toss and Serve', 'Add the tomatoes and onion to the dressing. Toss gently to coat them.\r\nAdd the fried anchovies.\r\nToss gently until all the ingredients are evenly combined.\r\nTransfer to a serving bowl and serve.'),
(117, 12, 0, 'Season and Fry the Bangus', 'Season the boneless bangus pieces with Maggi Magic Sarap and set aside for a few minutes.\r\nDredge each piece of fish in all purpose flour, making sure it is evenly coated on all sides.\r\nHeat the cooking oil in a pan over medium heat and fry the bangus until both sides turn light to medium brown.\r\nRemove the fried fish from the pan and set aside on a plate'),
(118, 12, 1, 'Stir Fry the String Beans', 'Using about 2 tablespoons of the oil left in the pan, stir fry the string beans for about 90 seconds.\r\nRemove from the pan and set aside.'),
(119, 12, 2, 'Saute the Aromatics and Build the Sauce', 'Add another 2 tablespoons of oil to the same pan and saute the garlic until it starts to brown.\r\nAdd the onion and ginger, then continue cooking until the onion softens.\r\nStir in the shrimp paste and Thai chili peppers, and saute for about 30 seconds.\r\nPour in the coconut milk and bring everything to a gentle boil.'),
(120, 12, 3, 'Simmer and Serve', 'Gently place the fried bangus and stir fried string beans into the coconut milk sauce.\r\nLower the heat and simmer for about 5 minutes, allowing the fish to absorb the flavors of the sauce.\r\nSeason with fish sauce and ground black pepper to taste.\r\nTransfer to a serving plate and serve hot with steamed white rice.'),
(121, 11, 0, 'Marinate the Chicken', 'Crush the garlic using a mortar and pestle.\r\nCombine the chicken, soy sauce, and crushed garlic in a large bowl. Mix well.\r\nMarinate for at least 1 hour. The longer the chicken marinates, the better the flavor.\r\nSeparate the chicken from the garlic and marinade. Set the garlic and marinade aside.'),
(122, 11, 1, 'Pan Fry the Chicken', 'Heat a cooking pot and pour in 3 tablespoons of cooking oil.\r\nOnce the oil gets hot, pan fry the marinated chicken for 2 minutes per side. Remove the chicken from the pot and set it aside.'),
(123, 11, 2, 'Simmer', 'Pour the remaining cooking oil into the same pot.. Add the garlic from the marinade. Sauté until it starts to brown.\r\nPut the chicken back into the pot. Add the remaining marinade, whole peppercorns, and dried bay leaves.\r\nPour in the water and let it boil.\r\nCover the pot and simmer for 30 minutes, or until the chicken becomes tender.'),
(124, 11, 3, 'Add Vinegar and Finish', 'Pour in the vinegar. Let it boil before stirring. Stir and continue simmering for 15 minutes.\r\nAdd the sugar and salt as needed. Stir, then turn the heat off.Transfer to a serving plate. Serve hot with rice.'),
(125, 2, 0, 'Cook the rice', 'Warm the cooked rice in a pan with half the butter until heated through.'),
(126, 2, 1, 'Fry the garlic', 'Push rice aside, add remaining butter and garlic, and fry until golden and fragrant.'),
(127, 2, 2, 'Fry the eggs', 'Push rice to one side of the pan and fry the eggs sunny-side up in the same pan.'),
(128, 2, 3, 'Assemble and serve', 'Drizzle with soy sauce and top the rice with the fried eggs and green onion.');

-- --------------------------------------------------------

--
-- Table structure for table `search_history`
--

CREATE TABLE `search_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ingredients_text` varchar(500) NOT NULL,
  `matched_recipe_ids` text DEFAULT NULL,
  `result_count` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `best_match_percent` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `search_history`
--

INSERT INTO `search_history` (`id`, `user_id`, `ingredients_text`, `matched_recipe_ids`, `result_count`, `best_match_percent`, `created_at`) VALUES
(1, 2, 'Chicken, rice, eggs, garlic', '[1,3,7]', 3, 94, '2026-09-27 21:34:00'),
(2, 2, 'Potatoes, cheese, milk', '[9,4,1,3,7]', 5, 87, '2026-09-27 01:12:00'),
(3, 2, 'Pasta, tomatoes, basil', '[4,6,1,3,5,7,9,10]', 8, 91, '2026-09-24 18:40:00'),
(4, 2, 'Tuna, bread, mayonnaise', '[8,2,1,10]', 4, 82, '2026-09-21 02:18:00'),
(5, 3, 'Pasta, spinach, garlic', '[4,6]', 2, 88, '2026-09-25 16:00:00'),
(6, 2, 'chicken, soy sauce, garlic, vinegar', '[1,3,7,10,5,4,6]', 7, 60, '2026-09-27 23:32:42'),
(7, 2, 'chicken, soy sauce, garlic, vinegar', '[1,3,7,10,5,4,6]', 7, 60, '2026-09-27 23:34:31'),
(8, 2, 'pork, soy sauce, string onions', '[7,1,3,5]', 4, 20, '2026-09-27 23:36:42'),
(9, 2, 'Chicken, Egg, Oil, Soy Sauce, Onion, Garlic', '[1,10,7,3,5,4,6]', 7, 80, '2026-09-27 23:38:16'),
(10, 1, 'pork, rice, soy souce, tinapa, egg', '[7,1,10]', 3, 40, '2026-09-28 00:06:07'),
(11, 1, 'siya', '[]', 0, 0, '2026-09-28 05:50:27'),
(12, 1, 'egg, rice, flour, siya, ako, kami, kung siya man', '[7,1,10]', 3, 40, '2026-09-28 05:51:47'),
(13, 1, 'egg, rice, chicken', '[10,1,7,3]', 4, 67, '2026-09-28 06:09:40'),
(14, 1, 'beef', '[7]', 1, 20, '2026-09-28 06:11:04'),
(15, 1, 'egg, rice, chicken', '[10,1,7,3]', 4, 67, '2026-09-28 06:12:06'),
(16, 1, 'beef', '[7]', 1, 20, '2026-09-28 06:14:07'),
(17, 1, 'elephant', '[]', 0, 0, '2026-09-28 06:14:38'),
(18, 1, 'dog', '[]', 0, 0, '2026-09-28 06:14:57'),
(19, 1, 'batong, soy sauce', '[7,1,3,5]', 4, 20, '2026-10-03 14:24:55'),
(20, 1, 'batong, oyster sauce, string onions', '[]', 0, 0, '2026-10-03 14:52:11'),
(21, 1, 'egg, beef, pork', '[7,10,1]', 3, 40, '2026-10-03 14:53:27'),
(22, 1, 'egg, beef, pork', '[7,10,1]', 3, 40, '2026-10-03 15:06:18'),
(23, 1, 'egg, beef, pork', '[7,10,1]', 3, 40, '2026-10-03 15:09:30'),
(24, 1, 'egg, beef, pork', '[7,10,1]', 3, 40, '2026-10-03 15:11:42'),
(25, 7, 'egg, chicken, soy sauce, magic sarap', '[10,1,7,3,5]', 5, 67, '2026-10-03 16:34:30'),
(26, 7, 'egg, chicken, soy sauce, magic sarap', '[10,1,7,3,5]', 5, 67, '2026-10-03 16:55:01'),
(27, 7, 'Chicken, talong', '[10,1,3]', 3, 33, '2026-10-12 01:09:51'),
(28, 7, 'Chicken, talong, egg, green onion, ginger, noodles', '[10,3,1,7,2]', 5, 67, '2026-10-12 01:18:20'),
(29, 7, 'elephant, dog\\', '[]', 0, 0, '2026-10-12 06:11:25'),
(30, 7, 'Chicken, talong, egg, green onion, ginger, noodles', '[10,3,1,7,2,11]', 6, 67, '2026-10-12 06:33:08'),
(31, 7, 'hotdog, egg', '[10,7,1,2]', 4, 33, '2026-10-12 06:34:24'),
(32, 7, 'Chicken, talong, egg, green onion, ginger, noodles', '[10,3,1,7,2,11]', 6, 67, '2026-10-18 14:37:13'),
(33, 7, 'Chicken, talong, egg, green onion, ginger, noodles', '[10,3,1,7,2,11]', 6, 67, '2026-11-07 00:55:02'),
(34, 7, 'Chicken, talong, egg, green onion, ginger, noodles, Tanglad', '[10,3,1,7,2,11]', 6, 67, '2026-11-07 01:19:36'),
(35, 7, 'Chicken, talong, egg, green onion, ginger, noodles, Tanglad', '[10,3,1,7,2,11]', 6, 67, '2026-11-07 01:40:55'),
(36, 7, 'hotdog', '[]', 0, 0, '2026-11-07 01:44:56'),
(37, 7, 'kalabasa', '[]', 0, 0, '2026-11-07 01:45:36'),
(38, 7, 'kalabasa', '[]', 0, 0, '2026-11-07 02:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password_hash`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Alex Rivera', 'alex@pantrypal.com', '$2y$10$PpC2TTrtEnuU.HAxKbGJiOxY/dmgQQnnyaK63VHpHOywkiyXJOyr6', 'admin', 'inactive', '2026-07-10 16:00:00', '2026-10-03 15:57:33'),
(2, 'Maria Santos', 'maria@example.com', '$2y$10$V0A940NJkFuL1hepe3z4JOdi5MRF4O1DcTpDMQxKFf3JrH9nTocnG', 'user', 'inactive', '2026-09-27 15:15:00', '2026-10-03 15:57:47'),
(3, 'Jamie Lee', 'jamie@example.com', '$2y$10$xlEzM1lnY6c6.IoxzfT53.wU1k/Lo8Ag50Gpb.o0d5Wje78zWuXLq', 'user', 'inactive', '2026-09-25 21:20:00', '2026-10-03 15:57:40'),
(4, 'Chris Tan', 'chris@example.com', '$2y$10$kJu.NaSg00WoT6/oXE.H/ebsxhBztD088hzImSK7u6ala0HR9qnDy', 'user', 'inactive', '2026-09-18 18:05:00', '2026-09-27 23:29:23'),
(5, 'Admin User', 'admin@test.com', '$2y$12$rxNL4YGWBOxbWYid/zjLHOQdm160WdsaKebJSLWHE641fQbA/yGba', 'admin', 'active', '2026-10-03 15:52:40', '2026-10-03 15:52:40'),
(6, 'Alex Rivera', 'alex@test.com', '$2y$12$4oaiXIcoPwGySCOOpDEqqeeB3Jt7DE7dGGuXRG92/lzjRJzox5yve', 'user', 'active', '2026-10-03 15:52:41', '2026-10-03 15:52:41'),
(7, 'Kem Sebios', 'kem@test.com', '$2y$12$RtP4McDDEX2eBBmCE.DiFe9TRSiUyJpgnmizCj4yJ2zT6gfDLG7iC', 'user', 'active', '2026-10-03 15:52:41', '2026-10-03 15:59:47');

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `dietary_preference` varchar(100) NOT NULL DEFAULT 'No preference',
  `favorite_cuisine` varchar(100) NOT NULL DEFAULT 'Asian-inspired',
  `cooking_skill` varchar(50) NOT NULL DEFAULT 'Intermediate',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_preferences`
--

INSERT INTO `user_preferences` (`user_id`, `dietary_preference`, `favorite_cuisine`, `cooking_skill`, `updated_at`) VALUES
(2, 'No preference', 'Asian-inspired', 'Intermediate', '2026-09-27 23:29:23'),
(3, 'Vegetarian', 'Italian-inspired', 'Beginner', '2026-09-27 23:29:23'),
(4, 'No preference', 'American', 'Beginner', '2026-09-27 23:29:23'),
(5, 'No preference', 'Asian-inspired', 'Intermediate', '2026-10-03 15:52:40'),
(6, 'No preference', 'Asian-inspired', 'Intermediate', '2026-10-03 15:52:41'),
(7, 'No preference', 'Asian-inspired', 'Intermediate', '2026-10-03 15:52:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ai_requests`
--
ALTER TABLE `ai_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ai_user` (`user_id`),
  ADD KEY `idx_ai_feature` (`feature`),
  ADD KEY `idx_ai_created` (`created_at`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_category_type` (`type`,`name`),
  ADD UNIQUE KEY `uniq_category_slug` (`type`,`slug`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_user_recipe` (`user_id`,`recipe_id`),
  ADD KEY `fk_fav_recipe` (`recipe_id`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `fk_ingredient_category` (`category_id`),
  ADD KEY `idx_ingredient_name` (`name`);

--
-- Indexes for table `pantry_items`
--
ALTER TABLE `pantry_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pantry_ingredient` (`ingredient_id`),
  ADD KEY `fk_pantry_category` (`category_id`),
  ADD KEY `idx_pantry_user` (`user_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `fk_recipe_category` (`category_id`),
  ADD KEY `fk_recipe_author` (`created_by`),
  ADD KEY `idx_recipe_status` (`status`),
  ADD KEY `idx_recipe_difficulty` (`difficulty`),
  ADD KEY `idx_recipe_community` (`is_community`);
ALTER TABLE `recipes` ADD FULLTEXT KEY `ft_recipe_title` (`title`,`description`);

--
-- Indexes for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_recipe_ingredient` (`recipe_id`,`ingredient_id`),
  ADD KEY `idx_ri_ingredient` (`ingredient_id`),
  ADD KEY `idx_ri_custom_name` (`custom_name`);

--
-- Indexes for table `recipe_steps`
--
ALTER TABLE `recipe_steps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_step_recipe` (`recipe_id`,`step_order`);

--
-- Indexes for table `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_history_user` (`user_id`,`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`status`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ai_requests`
--
ALTER TABLE `ai_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `pantry_items`
--
ALTER TABLE `pantry_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recipe_steps`
--
ALTER TABLE `recipe_steps`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ai_requests`
--
ALTER TABLE `ai_requests`
  ADD CONSTRAINT `fk_ai_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `fk_fav_recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fav_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD CONSTRAINT `fk_ingredient_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `pantry_items`
--
ALTER TABLE `pantry_items`
  ADD CONSTRAINT `fk_pantry_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pantry_ingredient` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pantry_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `recipes`
--
ALTER TABLE `recipes`
  ADD CONSTRAINT `fk_recipe_author` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_recipe_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD CONSTRAINT `fk_ri_ingredient` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ri_recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `recipe_steps`
--
ALTER TABLE `recipe_steps`
  ADD CONSTRAINT `fk_step_recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `search_history`
--
ALTER TABLE `search_history`
  ADD CONSTRAINT `fk_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD CONSTRAINT `fk_prefs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
